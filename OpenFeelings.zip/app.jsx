// app.jsx — canvas of 5 paper-family directions.

const W = 402, H = 874;

function Phone({ children }) {
  return <IOSDevice width={W} height={H}>{children}</IOSDevice>;
}

function Version({ id, title, subtitle, screens }) {
  return (
    <DCSection id={id} title={title} subtitle={subtitle}>
      {screens.map(s => (
        <DCArtboard key={s.id} id={`${id}-${s.id}`} label={s.label} width={W} height={H}>
          <Phone>{s.node}</Phone>
        </DCArtboard>
      ))}
    </DCSection>
  );
}

function App() {
  return (
    <DesignCanvas>
      <Version
        id="v1-paper"
        title="V1 · Paper"
        subtitle="The anchor. Editorial serif (Fraunces), watercolor wheel, warm cream. Closest to today's app, tightened. Soft cards, intention as a journal block."
        screens={[
          { id: 'onb',  label: 'Onboarding',          node: <PaperOnboarding /> },
          { id: 'tod',  label: 'Today',               node: <PaperToday /> },
          { id: 'che',  label: 'Check-in · Wheel',    node: <PaperCheckIn /> },
          { id: 'wiz',  label: 'Wizard · Strength',   node: <PaperWizardStep /> },
          { id: 'ins',  label: 'Insights',            node: <PaperInsights /> },
          { id: 'his',  label: 'History',             node: <PaperHistory /> },
          { id: 'dir',  label: 'Direction',           node: <PaperDirection /> },
          { id: 'set',  label: 'Settings (sheet)',    node: <PaperSettings /> },
        ]}
      />

      <Version
        id="v2-letterpress"
        title="V2 · Letterpress"
        subtitle="Riso / woodcut. Two-color limited palette (cream + ink + ONE accent per spread). Chunky Fraunces italics. Buttons are ink stamps with offset shadows. Section breaks like book chapter dividers. The wheel is a woodblock with hatching."
        screens={[
          { id: 'onb',  label: 'Onboarding · Poster',  node: <LetterpressOnboarding /> },
          { id: 'tod',  label: 'Today · Day-page',     node: <LetterpressToday /> },
          { id: 'che',  label: 'Check-in · Woodcut',   node: <LetterpressCheckIn /> },
          { id: 'wiz',  label: 'Wizard · Strength',    node: <LetterpressWizardStep /> },
          { id: 'ins',  label: 'Insights · Broadside', node: <LetterpressInsights /> },
          { id: 'his',  label: 'History · The Index',  node: <LetterpressHistory /> },
          { id: 'dir',  label: 'Direction',            node: <LetterpressDirection /> },
          { id: 'set',  label: 'Settings (sheet)',     node: <LetterpressSettings /> },
        ]}
      />

      <Version
        id="v3-notebook"
        title="V3 · Notebook"
        subtitle="Ruled paper, hand-annotated. Iowan Old Style + Caveat for marginalia. Pages have visible blue rules and a red margin line. The wheel is a diagram with curly-brace annotations pointing in. Buttons feel hand-drawn; chips are washi-tape strips."
        screens={[
          { id: 'onb',  label: 'Onboarding · Cover',   node: <NotebookOnboarding /> },
          { id: 'tod',  label: 'Today · Page 148',     node: <NotebookToday /> },
          { id: 'che',  label: 'Check-in · Diagram',   node: <NotebookCheckIn /> },
          { id: 'wiz',  label: 'Wizard · Body sketch', node: <NotebookWizardStep /> },
          { id: 'ins',  label: 'Insights · Notes',     node: <NotebookInsights /> },
          { id: 'his',  label: 'History · Earlier',    node: <NotebookHistory /> },
          { id: 'dir',  label: 'Direction · Checklist',node: <NotebookDirection /> },
          { id: 'set',  label: 'Settings (sheet)',     node: <NotebookSettings /> },
        ]}
      />

      <Version
        id="v4-almanac"
        title="V4 · Almanac"
        subtitle="Pocket diary / farmer's almanac. Spectral SC small caps. §-numbered sections, persistent breadcrumb at the top of every screen, dense tabular layouts, dingbats and pilcrows. The wheel is a fine engraving with hatch-shading."
        screens={[
          { id: 'onb',  label: 'Frontispiece',         node: <AlmanacOnboarding /> },
          { id: 'tod',  label: 'Today · Day CXLVIII',  node: <AlmanacToday /> },
          { id: 'che',  label: 'Check-in · Plate I',   node: <AlmanacCheckIn /> },
          { id: 'wiz',  label: 'Wizard · Triggers',    node: <AlmanacWizardStep /> },
          { id: 'ins',  label: 'Insights · Summary',   node: <AlmanacInsights /> },
          { id: 'his',  label: 'History · The Index',  node: <AlmanacHistory /> },
          { id: 'dir',  label: 'Direction',            node: <AlmanacDirection /> },
          { id: 'set',  label: 'Settings · Colophon',  node: <AlmanacSettings /> },
        ]}
      />

      <Version
        id="v5-linen"
        title="V5 · Linen"
        subtitle="Clothbound library book. Linen cloth ground, gilt rules, bookplate centered headings. Content lives on tipped-in paper inserts with photo-corners. Tabs are bookmark ribbons hanging down. Wheel is a marbled medallion."
        screens={[
          { id: 'onb',  label: 'Onboarding · Cover',   node: <LinenOnboarding /> },
          { id: 'tod',  label: 'Today',                node: <LinenToday /> },
          { id: 'che',  label: 'Check-in · Medallion', node: <LinenCheckIn /> },
          { id: 'wiz',  label: 'Wizard · Reflect',     node: <LinenWizardStep /> },
          { id: 'ins',  label: 'Insights',             node: <LinenInsights /> },
          { id: 'his',  label: 'History',              node: <LinenHistory /> },
          { id: 'dir',  label: 'Direction',            node: <LinenDirection /> },
          { id: 'set',  label: 'Settings · Colophon',  node: <LinenSettings /> },
        ]}
      />
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
