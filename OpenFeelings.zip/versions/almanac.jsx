// V4 — ALMANAC
// Paper-family. Old farmer's-almanac / pocket diary aesthetic. Spectral SC
// for centered classical headings, § numbered sections, dense tabular
// layouts, rubric red. Wheel as a fine engraving. Persistent breadcrumb at
// top of every screen.
// Exports Almanac* screens to window.

const A = {
  paper:   '#F1E8D0',          // aged cream
  paper2:  '#E8DDC0',
  ink:     '#1B140F',
  ink2:    '#3A2E22',
  rubric:  '#9F2818',           // rubric red
  pencil:  '#6C6052',
  muted:   '#7C6F5E',
  faint:   '#A89A82',
  divider: '#C7BB9A',
  ruleHeavy: '#1B140F',
  // Muted earthen cores
  cores: {
    happy:     '#B0860D',
    sad:       '#3C6979',
    angry:     '#A23E2D',
    fearful:   '#6A4382',
    disgusted: '#476245',
  },
};
const AF = {
  display: '"Spectral SC", "Source Serif 4", Georgia, serif',
  serif:   '"Source Serif 4", "Iowan Old Style", Georgia, serif',
  italic:  '"Fraunces", "Source Serif 4", Georgia, serif',
  mono:    '"IBM Plex Mono", ui-monospace, monospace',
};

// ─────────────────────────────────────────────────────────────
// Paper ground + aged grain
// ─────────────────────────────────────────────────────────────
function AlmanacPaper({ children, bg = A.paper }) {
  return (
    <div style={{ position: 'absolute', inset: 0, background: bg, overflow: 'hidden' }}>
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.15, mixBlendMode: 'multiply' }}>
        <filter id="noise-a">
          <feTurbulence type="fractalNoise" baseFrequency="0.95" numOctaves="2" seed="11"/>
          <feColorMatrix values="0 0 0 0 0.15  0 0 0 0 0.1  0 0 0 0 0.05  0 0 0 0.12 0"/>
        </filter>
        <rect width="100%" height="100%" filter="url(#noise-a)"/>
      </svg>
      {/* aged corner stains */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: '40%',
        background: 'radial-gradient(ellipse at 50% 0%, rgba(60,40,15,0.04) 0%, transparent 70%)',
        pointerEvents: 'none',
      }}/>
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, height: '30%',
        background: 'radial-gradient(ellipse at 50% 100%, rgba(60,40,15,0.06) 0%, transparent 70%)',
        pointerEvents: 'none',
      }}/>
      {children}
    </div>
  );
}

// Persistent breadcrumb header — appears on every screen
function ABreadcrumb({ section, trail }) {
  return (
    <div style={{
      position: 'absolute', top: 60, left: 22, right: 22,
      paddingBottom: 5, borderBottom: `0.5px solid ${A.ink}`,
      display: 'flex', alignItems: 'center', gap: 8,
      fontFamily: AF.display, fontSize: 10, color: A.ink,
      letterSpacing: 3, fontWeight: 600,
    }}>
      <span style={{ color: A.rubric }}>§</span>
      <span>{section}</span>
      {trail && <span style={{ color: A.faint }}>›</span>}
      {trail && <span style={{ color: A.muted }}>{trail}</span>}
      <span style={{ flex: 1 }}/>
      <span style={{ fontFamily: AF.mono, fontSize: 10, color: A.muted, fontWeight: 400, letterSpacing: 0.5 }}>
        MMXXVI · MAY · XXVIII
      </span>
    </div>
  );
}

// Centered classical heading (above-and-below rule)
function ACenteredHead({ pre, title, post, accent = A.ink }) {
  return (
    <div style={{ textAlign: 'center', padding: '10px 0 12px' }}>
      <div style={{ height: 2, background: accent, marginBottom: 12 }}/>
      {pre && (
        <div style={{
          fontFamily: AF.display, fontSize: 11, color: accent,
          letterSpacing: 4, fontWeight: 600, marginBottom: 6,
        }}>{pre}</div>
      )}
      <div style={{
        fontFamily: AF.display, fontSize: 26, color: A.ink,
        letterSpacing: 4, fontWeight: 600, lineHeight: 1.05,
      }}>{title}</div>
      {post && (
        <div style={{
          marginTop: 6, fontFamily: AF.italic, fontStyle: 'italic',
          fontSize: 13, color: A.muted, lineHeight: 1.4,
        }}>{post}</div>
      )}
      <div style={{ height: 0.5, background: accent, marginTop: 10 }}/>
    </div>
  );
}

// Section heading inside a screen (with § number + dingbat ornament)
function ASectionHead({ num, label, dingbat = '❦' }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8, marginTop: 14, marginBottom: 8,
    }}>
      <span style={{
        fontFamily: AF.display, fontSize: 11, color: A.rubric,
        letterSpacing: 2, fontWeight: 600,
      }}>§ {num}</span>
      <span style={{
        fontFamily: AF.display, fontSize: 11, color: A.ink,
        letterSpacing: 3, fontWeight: 600,
      }}>{label}</span>
      <div style={{ flex: 1, height: 0.5, background: A.ink, opacity: 0.5 }}/>
      <span style={{ color: A.rubric, fontFamily: AF.serif, fontSize: 13 }}>{dingbat}</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Engraved wheel — fine lines, hatched shading, printer's ornament
// ─────────────────────────────────────────────────────────────
function AlmanacWheel({ size = 300, focus = 'fearful' }) {
  const cx = size / 2, cy = size / 2;
  const cores = WHEEL_DATA;
  const n = cores.length;
  const sliceA = 360 / n;
  const polar = (r, deg) => {
    const a = (deg - 90) * Math.PI / 180;
    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
  };
  const sectorPath = (rIn, rOut, a0, a1) => {
    const [x1, y1] = polar(rOut, a0), [x2, y2] = polar(rOut, a1);
    const [x3, y3] = polar(rIn, a1),  [x4, y4] = polar(rIn, a0);
    const large = a1 - a0 > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${rOut} ${rOut} 0 ${large} 1 ${x2} ${y2} L ${x3} ${y3} A ${rIn} ${rIn} 0 ${large} 0 ${x4} ${y4} Z`;
  };
  const rHub = size * 0.10;
  const rCore = size * 0.27;
  const rSec = size * 0.42;
  const rSpec = size * 0.48;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        {/* fine engraving hatch */}
        {cores.map((c, ci) => (
          <pattern key={c.id} id={`engr-${c.id}`} x="0" y="0" width="3" height="3"
            patternUnits="userSpaceOnUse" patternTransform={`rotate(${ci * 36 + 25})`}>
            <line x1="0" y1="0" x2="0" y2="3" stroke={A.ink} strokeWidth="0.5"/>
          </pattern>
        ))}
        <pattern id="engr-focus" x="0" y="0" width="3" height="3"
          patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1="0" y1="0" x2="0" y2="3" stroke={A.rubric} strokeWidth="0.6"/>
        </pattern>
      </defs>

      {/* outer rule (multiple concentric like a coin) */}
      <circle cx={cx} cy={cy} r={(size / 2) - 1} fill={A.paper} stroke={A.ink} strokeWidth="1.5"/>
      <circle cx={cx} cy={cy} r={(size / 2) - 5} fill="none" stroke={A.ink} strokeWidth="0.4"/>

      {/* tick marks (12 outer cardinal-style) */}
      {Array.from({ length: 60 }).map((_, i) => {
        const a = i * 6;
        const [x1, y1] = polar((size / 2) - 1, a);
        const [x2, y2] = polar(i % 5 === 0 ? (size / 2) - 8 : (size / 2) - 4, a);
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
          stroke={A.ink} strokeWidth={i % 5 === 0 ? 0.7 : 0.3}/>;
      })}

      {/* SPECIFIC ring — extra-fine tick band with words */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceA;
        return c.secondaries.flatMap((s, si) => {
          const w = sliceA / c.secondaries.length;
          const subW = w / s.specifics.length;
          return s.specifics.map((sp, spi) => {
            const a0 = baseA + si * w + spi * subW;
            const aMid = a0 + subW / 2;
            const [tx, ty] = polar(rSpec + 4, aMid);
            const rotate = aMid > 90 && aMid < 270 ? aMid + 180 : aMid;
            return (
              <text key={`sp-${c.id}-${si}-${spi}`} x={tx} y={ty}
                textAnchor="middle" dominantBaseline="middle"
                transform={`rotate(${rotate - 90} ${tx} ${ty})`}
                fontFamily={AF.serif} fontSize={size * 0.022}
                fontStyle="italic" fill={A.ink2}>{sp.toLowerCase()}</text>
            );
          });
        });
      })}

      {/* SECONDARY ring — engraved sectors */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceA;
        return c.secondaries.map((s, si) => {
          const w = sliceA / c.secondaries.length;
          const a0 = baseA + si * w;
          const a1 = a0 + w;
          return (
            <path key={`s-${c.id}-${si}`}
              d={sectorPath(rCore, rSec, a0, a1)}
              fill={c.id === focus ? `url(#engr-${c.id})` : 'transparent'}
              stroke={A.ink} strokeWidth="0.5"/>
          );
        });
      })}

      {/* CORE ring — solid plates */}
      {cores.map((c, ci) => {
        const a0 = ci * sliceA, a1 = a0 + sliceA;
        const isFocus = c.id === focus;
        return (
          <g key={`c-${c.id}`}>
            <path d={sectorPath(rHub, rCore, a0, a1)}
              fill={isFocus ? A.cores[c.id] : A.paper2}
              stroke={A.ink} strokeWidth="1"/>
            {!isFocus && (
              <path d={sectorPath(rHub, rCore, a0, a1)}
                fill={`url(#engr-${c.id})`} opacity="0.3"/>
            )}
          </g>
        );
      })}

      {/* SECONDARY labels */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceA;
        return c.secondaries.map((s, si) => {
          const w = sliceA / c.secondaries.length;
          const aMid = baseA + si * w + w / 2;
          const [lx, ly] = polar((rCore + rSec) / 2, aMid);
          return (
            <text key={`sl-${c.id}-${si}`} x={lx} y={ly + 2}
              textAnchor="middle" dominantBaseline="middle"
              fontFamily={AF.display} fontSize={size * 0.025}
              fill={A.ink} style={{ letterSpacing: 0.6, fontWeight: 600 }}>{s.name}</text>
          );
        });
      })}

      {/* CORE labels — small caps centered */}
      {cores.map((c, ci) => {
        const aMid = ci * sliceA + sliceA / 2;
        const [lx, ly] = polar((rHub + rCore) / 2, aMid);
        const isFocus = c.id === focus;
        return (
          <text key={`l-${c.id}`} x={lx} y={ly + 2}
            textAnchor="middle" dominantBaseline="middle"
            fontFamily={AF.display} fontSize={size * 0.04}
            fontWeight="600"
            fill={isFocus ? A.paper : A.ink} style={{ letterSpacing: 1.5 }}>{c.name.toUpperCase()}</text>
        );
      })}

      {/* HUB — printer's flower */}
      <circle cx={cx} cy={cy} r={rHub} fill={A.paper} stroke={A.ink} strokeWidth="1"/>
      <text x={cx} y={cy + rHub * 0.25} textAnchor="middle"
        fontFamily={AF.serif} fontSize={rHub * 0.9} fill={A.rubric}>❦</text>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Tab bar — small caps with dotted leaders
// ─────────────────────────────────────────────────────────────
function AlmanacTabs({ active }) {
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 30,
      paddingBottom: 28, paddingTop: 10,
      background: A.paper2,
      borderTop: `2px solid ${A.ink}`,
      boxShadow: '0 -1px 0 rgba(0,0,0,0.05)',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-around', padding: '0 6px' }}>
        {TAB_DEFS.map(t => {
          const isActive = t.key === active;
          return (
            <div key={t.key} style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
              color: isActive ? A.rubric : A.muted,
            }}>
              <div style={{
                width: 24, height: 24,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {Icons[t.iconName](isActive ? A.rubric : A.ink, isActive ? 2 : 1.3)}
              </div>
              <div style={{
                fontFamily: AF.display, fontSize: 9,
                letterSpacing: 1.5, fontWeight: 600,
              }}>{t.label.toUpperCase()}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

const AGear = () => (
  <button style={{
    position: 'absolute', top: 60, right: 18, zIndex: 7,
    width: 30, height: 30, borderRadius: 0,
    border: `1px solid ${A.ink}`,
    background: A.paper, color: A.ink,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  }}>{Icons.gear(A.ink, 1.4)}</button>
);

// ─────────────────────────────────────────────────────────────
// SCREEN 1 — Onboarding (book frontispiece)
// ─────────────────────────────────────────────────────────────
function AlmanacOnboarding() {
  return (
    <AlmanacPaper>
      <div style={{ position: 'absolute', top: 70, left: 22, right: 22, textAlign: 'center' }}>
        <div style={{ height: 1, background: A.ink, marginBottom: 10 }}/>
        <div style={{ height: 3, background: A.ink, marginBottom: 14 }}/>
        <div style={{
          fontFamily: AF.display, fontSize: 12, color: A.rubric,
          letterSpacing: 5, fontWeight: 600,
        }}>THE</div>
        <div style={{
          marginTop: 4, fontFamily: AF.display, fontSize: 30, color: A.ink,
          letterSpacing: 5, fontWeight: 600, lineHeight: 1,
        }}>OPEN FEELINGS</div>
        <div style={{
          marginTop: 4, fontFamily: AF.italic, fontStyle: 'italic',
          fontSize: 18, color: A.ink, lineHeight: 1.1,
        }}>Almanac</div>
        <div style={{
          marginTop: 6, fontFamily: AF.display, fontSize: 11, color: A.muted,
          letterSpacing: 3,
        }}>—— A.D. MMXXVI · EDITION I ——</div>
        <div style={{ marginTop: 12, height: 0.5, background: A.ink, marginBottom: 6 }}/>
        <div style={{ height: 0.5, background: A.ink }}/>
      </div>

      <div style={{ position: 'absolute', top: 250, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
        <AlmanacWheel size={280}/>
      </div>

      <div style={{
        position: 'absolute', top: 555, left: 22, right: 22, textAlign: 'center',
      }}>
        <div style={{
          fontFamily: AF.italic, fontSize: 17, fontStyle: 'italic',
          color: A.ink2, lineHeight: 1.5,
        }}>
          Containing the engraved Wheel of Feelings,<br/>
          with notes for daily entry, recurring reflection,<br/>
          and durable values.
        </div>
      </div>

      <div style={{ position: 'absolute', bottom: 60, left: 22, right: 22 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <div style={{ flex: 1, height: 0.5, background: A.ink }}/>
          <span style={{
            fontFamily: AF.display, fontSize: 11, color: A.ink, letterSpacing: 4, fontWeight: 600,
          }}>OPEN BY</span>
          <div style={{ flex: 1, height: 0.5, background: A.ink }}/>
        </div>
        <button style={{
          width: '100%', padding: '16px', background: A.ink,
          color: A.paper, border: 'none', borderRadius: 0,
          fontFamily: AF.display, fontSize: 14, letterSpacing: 5, fontWeight: 600,
        }}>BEGIN ¶</button>
      </div>
    </AlmanacPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 2 — Today (almanac day-page)
// ─────────────────────────────────────────────────────────────
function AlmanacToday() {
  return (
    <AlmanacPaper>
      <ABreadcrumb section="TODAY"/>
      <AGear/>
      <div style={{ position: 'absolute', top: 90, left: 22, right: 22, bottom: 90, overflow: 'hidden' }}>
        <ACenteredHead
          pre="THE 28TH DAY OF MAY · THURSDAY"
          title="DAY CXLVIII"
          post="of the year. Late spring. New moon in 4 days."
        />

        {/* dual-column heads */}
        <div style={{ display: 'flex', gap: 14, marginTop: 8 }}>
          <div style={{
            flex: 1, padding: '10px 12px', border: `0.5px solid ${A.ink}`,
            textAlign: 'center',
          }}>
            <div style={{ fontFamily: AF.display, fontSize: 9, color: A.muted, letterSpacing: 2, fontWeight: 600 }}>
              ENTRIES TODAY
            </div>
            <div style={{
              fontFamily: AF.serif, fontSize: 28, color: A.ink, fontVariantNumeric: 'oldstyle-nums', fontWeight: 600,
              lineHeight: 1.1,
            }}>02</div>
          </div>
          <div style={{
            flex: 1, padding: '10px 12px', border: `0.5px solid ${A.ink}`,
            textAlign: 'center',
          }}>
            <div style={{ fontFamily: AF.display, fontSize: 9, color: A.muted, letterSpacing: 2, fontWeight: 600 }}>
              WEEK MOOD
            </div>
            <div style={{
              fontFamily: AF.italic, fontStyle: 'italic',
              fontSize: 20, color: A.cores.fearful, fontWeight: 600,
              lineHeight: 1.2,
            }}>Anxious</div>
          </div>
          <div style={{
            flex: 1, padding: '10px 12px', border: `0.5px solid ${A.ink}`,
            textAlign: 'center',
          }}>
            <div style={{ fontFamily: AF.display, fontSize: 9, color: A.muted, letterSpacing: 2, fontWeight: 600 }}>
              AV. INTENSITY
            </div>
            <div style={{
              fontFamily: AF.serif, fontSize: 28, color: A.ink, fontVariantNumeric: 'oldstyle-nums', fontWeight: 600,
              lineHeight: 1.1,
            }}>3.5</div>
          </div>
        </div>

        {/* § 1 INTENTION */}
        <ASectionHead num="I." label="THE DAY'S INTENTION"/>
        <div style={{
          padding: '12px 14px', background: A.paper2,
          border: `0.5px solid ${A.ink}`, position: 'relative',
        }}>
          <div style={{
            fontFamily: AF.italic, fontStyle: 'italic', fontSize: 18,
            color: A.ink, lineHeight: 1.35,
          }}>"Be slower with replies. Listen first."</div>
        </div>

        {/* § 2 ENTRIES */}
        <ASectionHead num="II." label="THE DAY'S ENTRIES"/>
        <table style={{
          width: '100%', borderCollapse: 'collapse',
          fontFamily: AF.serif, fontSize: 13, color: A.ink,
        }}>
          <thead>
            <tr style={{ borderTop: `1px solid ${A.ink}`, borderBottom: `0.5px solid ${A.ink}` }}>
              <th style={{ padding: '4px 8px', textAlign: 'left', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>TIME</th>
              <th style={{ padding: '4px 8px', textAlign: 'left', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>FELT</th>
              <th style={{ padding: '4px 4px', textAlign: 'left', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>INT.</th>
              <th style={{ padding: '4px 4px', textAlign: 'left', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>BODY</th>
            </tr>
          </thead>
          <tbody>
            {[
              { t: '09 h 14', w: 'Anxious', f: 'Fearful → Anxious → Overwhelmed', i: 4, b: 'chest, hands', c: 'fearful', note: 'Big presentation in an hour.' },
              { t: '12 h 38', w: 'Thankful', f: 'Happy → Peaceful → Thankful', i: 3, b: '—', c: 'happy' },
            ].map((it, i) => (
              <React.Fragment key={i}>
                <tr style={{ borderBottom: it.note ? 'none' : `0.5px dotted ${A.ink}` }}>
                  <td style={{ padding: '8px 8px', verticalAlign: 'top', fontFamily: AF.mono, fontSize: 11, color: A.pencil }}>{it.t}</td>
                  <td style={{ padding: '8px 8px', verticalAlign: 'top' }}>
                    <div style={{
                      fontFamily: AF.italic, fontStyle: 'italic', fontSize: 16,
                      color: A.cores[it.c], fontWeight: 600, lineHeight: 1.1,
                    }}>{it.w}</div>
                    <div style={{ fontFamily: AF.display, fontSize: 9, color: A.muted, letterSpacing: 1.5, fontWeight: 600, marginTop: 2 }}>
                      {it.f}
                    </div>
                  </td>
                  <td style={{ padding: '8px 4px', verticalAlign: 'top' }}>
                    <span style={{ fontFamily: AF.serif, fontVariantNumeric: 'oldstyle-nums', fontSize: 16, color: A.ink, fontWeight: 600 }}>
                      {it.i}/5
                    </span>
                  </td>
                  <td style={{ padding: '8px 4px', verticalAlign: 'top', fontFamily: AF.serif, fontStyle: 'italic', fontSize: 11, color: A.ink2 }}>
                    {it.b}
                  </td>
                </tr>
                {it.note && (
                  <tr style={{ borderBottom: `0.5px dotted ${A.ink}` }}>
                    <td/>
                    <td colSpan="3" style={{
                      padding: '0 8px 8px', fontFamily: AF.italic, fontStyle: 'italic',
                      fontSize: 13, color: A.ink2, lineHeight: 1.4,
                    }}>¶ "{it.note}"</td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
      <AlmanacTabs active="today"/>
    </AlmanacPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 3 — Check-in entry (the engraved wheel)
// ─────────────────────────────────────────────────────────────
function AlmanacCheckIn() {
  return (
    <AlmanacPaper>
      <ABreadcrumb section="CHECK IN" trail="step ii of iv"/>
      <AGear/>
      <div style={{ position: 'absolute', top: 90, left: 22, right: 22 }}>
        <ACenteredHead
          pre="PLATE I · THE WHEEL OF FEELINGS"
          title="NAME IT"
          post="Adapted from Open Emotion Wheel v1.1 · CC BY-SA 4.0"
        />
      </div>

      <div style={{
        position: 'absolute', top: 230, left: 0, right: 0,
        display: 'flex', justifyContent: 'center',
      }}>
        <AlmanacWheel size={340}/>
      </div>

      {/* readout */}
      <div style={{
        position: 'absolute', bottom: 170, left: 22, right: 22,
        padding: '10px 14px',
        border: `2px solid ${A.ink}`, background: A.paper,
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <div style={{ flex: 1 }}>
          <div style={{
            fontFamily: AF.display, fontSize: 9, color: A.rubric,
            letterSpacing: 2, fontWeight: 600,
          }}>YOUR READING</div>
          <div style={{
            marginTop: 3, fontFamily: AF.italic, fontStyle: 'italic',
            fontSize: 18, color: A.ink, fontWeight: 600, lineHeight: 1,
          }}>Fearful · Anxious</div>
        </div>
        <button style={{
          padding: '8px 14px', background: A.ink, color: A.paper,
          border: 'none', borderRadius: 0,
          fontFamily: AF.display, fontSize: 11, fontWeight: 600, letterSpacing: 3,
        }}>SAVE ✦</button>
      </div>

      {/* mode picker — tabular */}
      <div style={{
        position: 'absolute', bottom: 110, left: 22, right: 22,
        display: 'flex', border: `1px solid ${A.ink}`,
      }}>
        {['Wheel', 'Guided', 'Quick'].map((m, i) => (
          <button key={m} style={{
            flex: 1, padding: '8px', border: 'none',
            borderRight: i < 2 ? `1px solid ${A.ink}` : 'none',
            background: i === 0 ? A.ink : A.paper,
            color: i === 0 ? A.paper : A.ink,
            fontFamily: AF.display, fontSize: 10, letterSpacing: 2.5, fontWeight: 600,
          }}>{m.toUpperCase()}</button>
        ))}
      </div>
      <AlmanacTabs active="checkIn"/>
    </AlmanacPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 4 — Wizard step: triggers (tabular)
// ─────────────────────────────────────────────────────────────
function AlmanacWizardStep() {
  return (
    <AlmanacPaper>
      <ABreadcrumb section="CHECK IN" trail="step v · triggers"/>
      <div style={{ position: 'absolute', top: 90, left: 22, right: 22 }}>
        {/* progress */}
        <div style={{
          fontFamily: AF.display, fontSize: 9, color: A.muted, letterSpacing: 2,
          textAlign: 'center', marginBottom: 6, fontWeight: 600,
        }}>
          {Array.from({length: 7}).map((_, i) => (
            <span key={i} style={{ color: i <= 4 ? A.rubric : A.faint, margin: '0 3px' }}>
              {i <= 4 ? '●' : '○'}
            </span>
          ))}
        </div>
        <ACenteredHead pre="OPTIONAL" title="WHAT BROUGHT IT ON" post="Select any that apply."/>

        {/* The selection so far */}
        <div style={{
          marginTop: 10, padding: '8px 12px',
          background: A.paper2, border: `0.5px solid ${A.ink}`,
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <span style={{ width: 9, height: 9, background: A.cores.fearful }}/>
          <span style={{ fontFamily: AF.italic, fontStyle: 'italic', fontSize: 14, color: A.ink, fontWeight: 600 }}>
            Fearful · Anxious · Overwhelmed
          </span>
          <span style={{ flex: 1 }}/>
          <span style={{ fontFamily: AF.mono, fontSize: 11, color: A.muted }}>4 / 5</span>
        </div>

        <ASectionHead num="I." label="THE CAUSES &mdash; PRESENT" dingbat="✦"/>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0 }}>
          {[
            ['Work pressure', true], ['Conflict', false],
            ['Money', false], ['Lost sleep', true],
            ['Health', false], ['News', false],
            ['Social', true], ['Family', false],
            ['Travel', false], ['Decisions', true],
          ].map(([t, sel], i) => (
            <div key={t} style={{
              padding: '8px 10px',
              border: `0.5px solid ${A.ink}`,
              marginTop: -0.5, marginLeft: i % 2 === 0 ? 0 : -0.5,
              background: sel ? A.ink : 'transparent',
              color: sel ? A.paper : A.ink,
              display: 'flex', alignItems: 'center', gap: 8,
              fontFamily: AF.serif, fontSize: 13,
            }}>
              <span style={{
                width: 12, height: 12, border: `1px solid ${sel ? A.paper : A.ink}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 10, fontWeight: 700,
              }}>{sel ? '✓' : ''}</span>
              {t}
            </div>
          ))}
        </div>

        <ASectionHead num="II." label="OR ENTER YOUR OWN" dingbat="¶"/>
        <div style={{
          padding: '10px 14px', border: `0.5px dashed ${A.ink}`,
          fontFamily: AF.italic, fontStyle: 'italic', fontSize: 13, color: A.faint,
        }}>+ add a trigger…</div>
      </div>

      <div style={{
        position: 'absolute', bottom: 100, left: 22, right: 22,
        display: 'flex', gap: 8,
      }}>
        <button style={{
          padding: '12px 18px', background: A.paper,
          border: `1px solid ${A.ink}`, color: A.ink,
          fontFamily: AF.display, fontSize: 10, letterSpacing: 2.5, fontWeight: 600,
        }}>SKIP</button>
        <button style={{
          flex: 1, padding: '12px 18px', background: A.ink, color: A.paper,
          border: 'none', fontFamily: AF.display, fontSize: 11, letterSpacing: 3, fontWeight: 600,
        }}>NEXT ✦</button>
      </div>
      <AlmanacTabs active="checkIn"/>
    </AlmanacPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 5 — Insights (almanac yearly table)
// ─────────────────────────────────────────────────────────────
function AlmanacInsights() {
  return (
    <AlmanacPaper>
      <ABreadcrumb section="INSIGHTS" trail="month of may"/>
      <AGear/>
      <div style={{ position: 'absolute', top: 90, left: 22, right: 22, bottom: 90, overflow: 'hidden' }}>
        <ACenteredHead pre="THE MONTH OF MAY · MMXXVI" title="A SUMMARY" post="Twenty-seven readings · 28 days observed"/>

        {/* big numbers row */}
        <div style={{ marginTop: 6, display: 'flex', gap: 8 }}>
          {[
            { v: '27', l: 'ENTRIES' }, { v: '3.5', l: 'AV. INTENSITY' },
            { v: '14', l: 'WORDS' },   { v: '5', l: 'FAMILIES' },
          ].map(s => (
            <div key={s.l} style={{
              flex: 1, padding: '8px 4px', border: `0.5px solid ${A.ink}`,
              textAlign: 'center',
            }}>
              <div style={{
                fontFamily: AF.serif, fontSize: 26, color: A.ink, fontWeight: 600,
                fontVariantNumeric: 'oldstyle-nums', lineHeight: 1,
              }}>{s.v}</div>
              <div style={{
                marginTop: 2, fontFamily: AF.display, fontSize: 8,
                color: A.muted, letterSpacing: 1.5, fontWeight: 600,
              }}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Table: by family */}
        <ASectionHead num="I." label="BY FAMILY"/>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: AF.serif, fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: `1px solid ${A.ink}` }}>
              <th style={{ padding: '4px 8px', textAlign: 'left', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>FAMILY</th>
              <th style={{ padding: '4px 8px', textAlign: 'right', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>×</th>
              <th style={{ padding: '4px 8px', textAlign: 'right', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>%</th>
              <th style={{ padding: '4px 8px', textAlign: 'left', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>BAR</th>
            </tr>
          </thead>
          <tbody>
            {[
              { n: 'Fearful', c: 'fearful', v: 11, p: 40 },
              { n: 'Happy', c: 'happy', v: 9, p: 33 },
              { n: 'Sad', c: 'sad', v: 4, p: 15 },
              { n: 'Angry', c: 'angry', v: 2, p: 8 },
              { n: 'Disgusted', c: 'disgusted', v: 1, p: 4 },
            ].map(t => (
              <tr key={t.n} style={{ borderBottom: `0.5px dotted ${A.ink}` }}>
                <td style={{ padding: '6px 8px' }}>
                  <span style={{ fontFamily: AF.italic, fontStyle: 'italic', color: A.cores[t.c], fontWeight: 600 }}>
                    {t.n}
                  </span>
                </td>
                <td style={{ padding: '6px 8px', textAlign: 'right', fontVariantNumeric: 'oldstyle-nums' }}>{t.v}</td>
                <td style={{ padding: '6px 8px', textAlign: 'right', fontFamily: AF.mono, fontSize: 11, color: A.muted }}>{t.p}%</td>
                <td style={{ padding: '6px 8px', width: '40%' }}>
                  <div style={{ height: 6, background: A.paper2, position: 'relative' }}>
                    <div style={{
                      position: 'absolute', inset: 0, width: `${t.p}%`,
                      background: A.cores[t.c],
                    }}/>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Hours bar — heat strip */}
        <ASectionHead num="II." label="BY HOUR" dingbat="✦"/>
        <div style={{ display: 'flex', height: 22 }}>
          {Array.from({ length: 24 }).map((_, h) => {
            const v = [0,0,0,0,0,1,2,3,4,3,2,1,2,3,1,1,2,2,1,1,0,0,0,0][h] || 0;
            return (
              <div key={h} style={{
                flex: 1, background: v > 0 ? withAlpha(A.cores.fearful, v / 4 * 0.85 + 0.15) : 'transparent',
                border: `0.5px solid ${A.ink}`,
                marginRight: -0.5,
              }}/>
            );
          })}
        </div>
        <div style={{
          marginTop: 2, display: 'flex', justifyContent: 'space-between',
          fontFamily: AF.mono, fontSize: 9, color: A.muted,
        }}>
          <span>00</span><span>06</span><span>12</span><span>18</span><span>24</span>
        </div>
      </div>
      <AlmanacTabs active="insights"/>
    </AlmanacPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 6 — History (index of entries)
// ─────────────────────────────────────────────────────────────
function AlmanacHistory() {
  return (
    <AlmanacPaper>
      <ABreadcrumb section="HISTORY" trail="the index"/>
      <div style={{ position: 'absolute', top: 90, left: 22, right: 22, bottom: 90, overflow: 'hidden' }}>
        <ACenteredHead pre="INDEX OF ENTRIES" title="THE COMPLETE LOG" post="Sorted by day. Most recent first."/>

        {/* filter row */}
        <div style={{
          marginTop: 4, display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <div style={{
            fontFamily: AF.display, fontSize: 9, color: A.muted, letterSpacing: 2, fontWeight: 600,
          }}>FILTER —</div>
          {['ALL', 'HAPPY', 'SAD', 'ANGRY', 'FEARFUL', 'DISG.'].map((c, i) => (
            <span key={c} style={{
              padding: '2px 7px', border: `0.5px solid ${A.ink}`,
              background: i === 0 ? A.ink : 'transparent',
              color: i === 0 ? A.paper : A.ink,
              fontFamily: AF.display, fontSize: 9, fontWeight: 600, letterSpacing: 1.5,
            }}>{c}</span>
          ))}
        </div>

        {/* Day groupings */}
        {[
          { d: 'THURSDAY · XXVIII MAY · TODAY', items: [
            { t: '12h 38', w: 'Thankful', s: 'Happy · Peaceful', i: 3, c: 'happy', body: '—' },
            { t: '09h 14', w: 'Overwhelmed', s: 'Fearful · Anxious', i: 4, c: 'fearful', body: 'chest, hands', note: 'Big presentation in an hour.' },
          ]},
          { d: 'WEDNESDAY · XXVII', items: [
            { t: '20h 02', w: 'Disappointed', s: 'Sad · Hurt', i: 3, c: 'sad', body: 'stomach' },
            { t: '16h 15', w: 'Confident', s: 'Happy · Proud', i: 4, c: 'happy', body: '—' },
          ]},
          { d: 'TUESDAY · XXVI', items: [
            { t: '18h 30', w: 'Annoyed', s: 'Angry · Frustrated', i: 3, c: 'angry', body: 'jaw, shoulders' },
          ]},
        ].map(g => (
          <div key={g.d} style={{ marginTop: 14 }}>
            <div style={{
              padding: '4px 0', borderTop: `1px solid ${A.ink}`, borderBottom: `0.5px solid ${A.ink}`,
              fontFamily: AF.display, fontSize: 9, color: A.rubric, letterSpacing: 2.5, fontWeight: 600,
              textAlign: 'center',
            }}>{g.d}</div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: AF.serif }}>
              <tbody>
                {g.items.map((it, i) => (
                  <tr key={i} style={{ borderBottom: `0.5px dotted ${A.ink}` }}>
                    <td style={{ padding: '8px 8px', verticalAlign: 'top', width: 56, fontFamily: AF.mono, fontSize: 11, color: A.pencil }}>
                      {it.t}
                    </td>
                    <td style={{ padding: '8px 8px', verticalAlign: 'top' }}>
                      <div style={{ fontFamily: AF.italic, fontStyle: 'italic', fontSize: 16, color: A.cores[it.c], fontWeight: 600, lineHeight: 1.1 }}>
                        {it.w}
                      </div>
                      <div style={{ fontFamily: AF.display, fontSize: 9, color: A.muted, letterSpacing: 1.5, marginTop: 1, fontWeight: 600 }}>
                        {it.s.toUpperCase()}
                      </div>
                      {it.note && (
                        <div style={{ marginTop: 4, fontFamily: AF.italic, fontStyle: 'italic', fontSize: 12, color: A.ink2 }}>
                          ¶ "{it.note}"
                        </div>
                      )}
                    </td>
                    <td style={{ padding: '8px 6px', verticalAlign: 'top', textAlign: 'right' }}>
                      <div style={{ fontFamily: AF.serif, fontVariantNumeric: 'oldstyle-nums', fontSize: 15, color: A.ink, fontWeight: 600 }}>
                        {it.i}/5
                      </div>
                      <div style={{ fontFamily: AF.serif, fontStyle: 'italic', fontSize: 10, color: A.muted, marginTop: 1 }}>
                        {it.body}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
      </div>
      <AlmanacTabs active="today"/>
    </AlmanacPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 7 — Direction
// ─────────────────────────────────────────────────────────────
function AlmanacDirection() {
  return (
    <AlmanacPaper>
      <ABreadcrumb section="DIRECTION" trail="intentions"/>
      <AGear/>
      <div style={{ position: 'absolute', top: 90, left: 22, right: 22, bottom: 90, overflow: 'hidden' }}>
        <ACenteredHead pre="THE GUIDING STARS" title="DIRECTION" post="Intentions, values, and committed acts."/>

        {/* tabbed segmented */}
        <div style={{
          marginTop: 8, display: 'flex', border: `0.5px solid ${A.ink}`,
        }}>
          {['INTENTION', 'VALUES', 'ACTIONS'].map((m, i) => (
            <button key={m} style={{
              flex: 1, padding: '7px', border: 'none',
              borderRight: i < 2 ? `0.5px solid ${A.ink}` : 'none',
              background: i === 0 ? A.ink : 'transparent',
              color: i === 0 ? A.paper : A.ink,
              fontFamily: AF.display, fontSize: 10, letterSpacing: 2, fontWeight: 600,
            }}>{m}</button>
          ))}
        </div>

        {/* Today's intention */}
        <ASectionHead num="I." label="TODAY · 28 MAY"/>
        <div style={{
          padding: '14px 18px', border: `0.5px solid ${A.ink}`,
          background: A.paper2,
        }}>
          <div style={{
            fontFamily: AF.italic, fontStyle: 'italic', fontSize: 18,
            color: A.ink, lineHeight: 1.35, fontWeight: 600,
          }}>"Be slower with replies. Listen first."</div>
          <div style={{
            marginTop: 12, display: 'flex', alignItems: 'center', gap: 4,
          }}>
            <span style={{
              fontFamily: AF.display, fontSize: 9, color: A.muted, letterSpacing: 2, fontWeight: 600,
            }}>LIVED IT?</span>
            <span style={{ flex: 1 }}/>
            {['HARD', 'OK', 'YES'].map(l => (
              <span key={l} style={{
                padding: '3px 8px', border: `0.5px solid ${A.ink}`,
                background: l === 'OK' ? A.ink : 'transparent',
                color: l === 'OK' ? A.paper : A.ink,
                fontFamily: AF.display, fontSize: 9, fontWeight: 600, letterSpacing: 1.5,
              }}>{l}</span>
            ))}
          </div>
        </div>

        {/* This week's intentions table */}
        <ASectionHead num="II." label="THIS WEEK · CHRONICLE" dingbat="✦"/>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: AF.serif, fontSize: 13 }}>
          <thead>
            <tr style={{ borderTop: `1px solid ${A.ink}`, borderBottom: `0.5px solid ${A.ink}` }}>
              <th style={{ padding: '4px 8px', textAlign: 'left', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>DAY</th>
              <th style={{ padding: '4px 8px', textAlign: 'left', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>INTENTION</th>
              <th style={{ padding: '4px 8px', textAlign: 'right', fontFamily: AF.display, fontSize: 9, letterSpacing: 2, fontWeight: 600 }}>LIVED</th>
            </tr>
          </thead>
          <tbody>
            {[
              { d: 'WED', t: 'Eat lunch away from the desk.', r: 'OK' },
              { d: 'TUE', t: "Notice when I'm holding my breath.", r: 'YES' },
              { d: 'MON', t: 'Send the message I keep avoiding.', r: 'HARD' },
              { d: 'SUN', t: 'No phone before coffee.', r: 'YES' },
            ].map(p => (
              <tr key={p.d} style={{ borderBottom: `0.5px dotted ${A.ink}` }}>
                <td style={{ padding: '6px 8px', fontFamily: AF.mono, fontSize: 11, color: A.muted }}>{p.d}</td>
                <td style={{ padding: '6px 8px', fontFamily: AF.italic, fontStyle: 'italic', color: A.ink }}>{p.t}</td>
                <td style={{ padding: '6px 8px', textAlign: 'right', fontFamily: AF.display, fontSize: 9, letterSpacing: 1.5, fontWeight: 600,
                  color: p.r === 'YES' ? A.cores.disgusted : p.r === 'HARD' ? A.cores.angry : A.ink }}>
                  {p.r}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <AlmanacTabs active="direction"/>
    </AlmanacPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 8 — Settings (colophon-style)
// ─────────────────────────────────────────────────────────────
function AlmanacSettings() {
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'rgba(27,20,15,0.55)', overflow: 'hidden' }}>
      <AlmanacPaper>
        <div style={{ opacity: 0.4 }}><ABreadcrumb section="TODAY"/></div>
      </AlmanacPaper>
      <div style={{
        position: 'absolute', top: 56, left: 0, right: 0, bottom: 0,
        background: A.paper, borderTop: `2px solid ${A.ink}`,
        boxShadow: '0 -10px 30px rgba(27,20,15,0.18)', overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '6px 0 4px' }}>
          <div style={{ width: 36, height: 4, background: A.ink }}/>
        </div>
        <div style={{
          padding: '8px 22px 8px',
          display: 'flex', alignItems: 'center', borderBottom: `1px solid ${A.ink}`,
        }}>
          <div style={{
            flex: 1, fontFamily: AF.display, fontSize: 16, color: A.ink,
            letterSpacing: 4, fontWeight: 600,
          }}>§ SETTINGS</div>
          <button style={{
            padding: '4px 12px', background: A.ink, color: A.paper, border: 'none',
            fontFamily: AF.display, fontSize: 10, letterSpacing: 2.5, fontWeight: 600,
          }}>DONE</button>
        </div>

        <div style={{ padding: '12px 22px', overflow: 'auto', maxHeight: 'calc(100% - 60px)' }}>
          {[
            { num: 'I.', h: 'THE READER', rows: [
              { l: 'Display name', d: 'Taylor' },
              { l: 'Appearance', d: 'Match system' },
            ]},
            { num: 'II.', h: 'CHECK-IN', rows: [
              { l: 'Default mode', d: 'Wheel' },
              { l: 'Body region first', toggle: true, on: true },
              { l: 'Show clinical notes', toggle: true, on: true },
              { l: 'Learn from history', toggle: true, on: true },
            ]},
            { num: 'III.', h: 'PRIVACY', rows: [
              { l: 'iCloud sync', d: 'synced 2m ago', good: true },
              { l: 'Face ID lock', toggle: true, on: true },
              { l: 'Apple Health write', toggle: true, on: false },
            ]},
            { num: 'IV.', h: 'EXPORT', rows: [
              { l: 'Local backup', d: '' },
              { l: 'CSV / JSON', d: '' },
              { l: 'Therapy report PDF', d: '' },
            ]},
            { num: 'V.', h: 'TIP THE TYPESETTER', rows: [
              { l: '🥤 Soda', d: '$1.99', donate: true },
              { l: '🥪 Lunch', d: '$4.99', donate: true },
              { l: '🍝 Dinner', d: '$9.99', donate: true },
            ]},
          ].map(sec => (
            <div key={sec.h} style={{ marginBottom: 12 }}>
              <ASectionHead num={sec.num} label={sec.h}/>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: AF.serif, fontSize: 13 }}>
                <tbody>
                  {sec.rows.map((r, i) => (
                    <tr key={i} style={{
                      borderBottom: i < sec.rows.length - 1 ? `0.5px dotted ${A.ink}` : 'none',
                    }}>
                      <td style={{ padding: '8px 4px' }}>{r.l}</td>
                      <td style={{ padding: '8px 4px', textAlign: 'right', width: 110 }}>
                        {r.d && (
                          <span style={{
                            fontFamily: AF.mono, fontSize: 11, color: r.good ? A.cores.disgusted : A.muted,
                          }}>{r.d}</span>
                        )}
                        {r.toggle && (
                          <span style={{
                            display: 'inline-block', width: 30, height: 16,
                            background: r.on ? A.ink : A.paper,
                            border: `0.5px solid ${A.ink}`, position: 'relative',
                          }}>
                            <span style={{
                              position: 'absolute', top: 1, [r.on ? 'right' : 'left']: 1,
                              width: 12, height: 12, background: r.on ? A.paper : A.ink,
                            }}/>
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
          <div style={{
            textAlign: 'center', padding: '14px 0 30px',
            fontFamily: AF.display, fontSize: 10, color: A.muted, letterSpacing: 2.5, fontWeight: 600,
          }}>
            ❦ &nbsp; FINIS &nbsp; ❦<br/>
            <span style={{ fontFamily: AF.mono, fontSize: 9, letterSpacing: 0.5, fontWeight: 400 }}>
              V. 1.4 · MIT · OPEN SOURCE · ANNO MMXXVI
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  AlmanacOnboarding, AlmanacToday, AlmanacCheckIn, AlmanacWizardStep,
  AlmanacInsights, AlmanacHistory, AlmanacDirection, AlmanacSettings,
  AlmanacWheel,
});
