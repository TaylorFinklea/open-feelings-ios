// V5 — LINEN
// Paper-family. Clothbound book / library binding aesthetic. Centered
// bookplate headers, gilt rules, marbled accents, ribbon-bookmark tabs,
// tipped-in modal inserts.
// Exports Linen* screens to window.

const LN = {
  cloth:    '#D8CFB6',          // linen base
  cloth2:   '#C7BB9D',
  paper:    '#F5ECD5',          // tipped-in paper insert
  paperEdge:'#E3D8BD',
  ink:      '#1C1610',
  ink2:     '#3A2E22',
  muted:    '#6E624B',
  faint:    '#988A6F',
  gilt:     '#B89554',           // gold leaf
  giltDk:   '#9C7A38',
  ribbon:   '#7B2922',           // bookmark ribbon red
  ribbonGreen: '#3E5A40',
  // book-cloth muted cores
  cores: {
    happy:     '#A57A1C',
    sad:       '#365D74',
    angry:     '#9D3D2A',
    fearful:   '#6A4480',
    disgusted: '#3E624A',
  },
};
const LNF = {
  serif: '"Source Serif 4", "Iowan Old Style", Georgia, serif',
  sc:    '"Spectral SC", "Source Serif 4", Georgia, serif',
  italic:'"Source Serif 4", Georgia, serif',
  mono:  '"IBM Plex Mono", ui-monospace, monospace',
};

// ─────────────────────────────────────────────────────────────
// Linen cloth ground — woven texture
// ─────────────────────────────────────────────────────────────
function LinenCloth({ children, bg = LN.cloth }) {
  return (
    <div style={{ position: 'absolute', inset: 0, background: bg, overflow: 'hidden' }}>
      {/* woven texture via dual-direction noise */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `repeating-linear-gradient(90deg, transparent, transparent 2px, rgba(110,98,75,0.06) 2px, rgba(110,98,75,0.06) 3px), repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(110,98,75,0.06) 2px, rgba(110,98,75,0.06) 3px)`,
        pointerEvents: 'none',
      }}/>
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.12, mixBlendMode: 'multiply' }}>
        <filter id="linen-noise">
          <feTurbulence type="fractalNoise" baseFrequency="1.2" numOctaves="2" seed="7"/>
          <feColorMatrix values="0 0 0 0 0.1  0 0 0 0 0.08  0 0 0 0 0.05  0 0 0 0.4 0"/>
        </filter>
        <rect width="100%" height="100%" filter="url(#linen-noise)"/>
      </svg>
      {/* corner gilt rules (visible on every screen) */}
      <div style={{
        position: 'absolute', top: 60, left: 16, right: 16,
        height: 1, background: `linear-gradient(90deg, transparent, ${LN.gilt}, ${LN.gilt}, transparent)`,
        opacity: 0.7,
      }}/>
      <div style={{
        position: 'absolute', bottom: 96, left: 16, right: 16,
        height: 1, background: `linear-gradient(90deg, transparent, ${LN.gilt}, ${LN.gilt}, transparent)`,
        opacity: 0.7,
      }}/>
      {children}
    </div>
  );
}

// Paper insert (tipped-in plate) — content lives on a paper card pinned to cloth
function TippedIn({ children, style }) {
  return (
    <div style={{
      background: LN.paper, position: 'relative',
      boxShadow: '0 0 0 0.5px rgba(0,0,0,0.15), 0 4px 12px rgba(0,0,0,0.10), inset 0 0 0 1px rgba(255,255,255,0.4)',
      ...style,
    }}>
      {/* paper edge darkening */}
      <div style={{
        position: 'absolute', inset: 0,
        background: `linear-gradient(180deg, ${LN.paperEdge} 0%, transparent 4%, transparent 96%, ${LN.paperEdge} 100%)`,
        pointerEvents: 'none', opacity: 0.5,
      }}/>
      {/* corner photo-corners */}
      {[[0,0,'l','t'],[1,0,'r','t'],[0,1,'l','b'],[1,1,'r','b']].map(([x,y,a,b]) => (
        <div key={a+b} style={{
          position: 'absolute', [b === 't' ? 'top' : 'bottom']: 0, [a === 'l' ? 'left' : 'right']: 0,
          width: 14, height: 14, background: LN.cloth2, opacity: 0.55,
          clipPath: a === 'l' && b === 't' ? 'polygon(0 0, 100% 0, 0 100%)'
                  : a === 'r' && b === 't' ? 'polygon(100% 0, 100% 100%, 0 0)'
                  : a === 'l' && b === 'b' ? 'polygon(0 0, 0 100%, 100% 100%)'
                  : 'polygon(100% 0, 100% 100%, 0 100%)',
        }}/>
      ))}
      <div style={{ position: 'relative', zIndex: 1 }}>{children}</div>
    </div>
  );
}

// Bookplate header — centered title with double gilt rules
function Bookplate({ pre, title, post, color = LN.ink }) {
  return (
    <div style={{ textAlign: 'center', padding: '0 16px' }}>
      <div style={{ height: 1, background: LN.gilt }}/>
      <div style={{ height: 0.5, background: LN.gilt, marginTop: 3 }}/>
      <div style={{ height: 16 }}/>
      {pre && (
        <div style={{
          fontFamily: LNF.sc, fontSize: 10, color: LN.giltDk,
          letterSpacing: 4, fontWeight: 600, marginBottom: 6,
        }}>{pre}</div>
      )}
      <div style={{
        fontFamily: LNF.sc, fontSize: 26, color: color,
        letterSpacing: 6, fontWeight: 600, lineHeight: 1.05,
      }}>{title}</div>
      {post && (
        <div style={{
          marginTop: 6, fontFamily: LNF.italic, fontStyle: 'italic',
          fontSize: 13, color: LN.muted, lineHeight: 1.4,
        }}>{post}</div>
      )}
      <div style={{ height: 16 }}/>
      <div style={{ height: 0.5, background: LN.gilt, marginBottom: 3 }}/>
      <div style={{ height: 1, background: LN.gilt }}/>
    </div>
  );
}

// Section title (small caps, gilt rule on either side)
function LinenSection({ children }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12, margin: '14px 0 8px',
    }}>
      <div style={{ flex: 1, height: 1, background: LN.gilt, opacity: 0.7 }}/>
      <span style={{
        fontFamily: LNF.sc, fontSize: 11, color: LN.giltDk,
        letterSpacing: 4, fontWeight: 600,
      }}>{children}</span>
      <div style={{ flex: 1, height: 1, background: LN.gilt, opacity: 0.7 }}/>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Bookplate wheel — circular medallion with marbled centre.
// ─────────────────────────────────────────────────────────────
function LinenWheel({ size = 300, focus = 'fearful' }) {
  const cx = size / 2, cy = size / 2;
  const cores = WHEEL_DATA;
  const n = cores.length;
  const sliceA = 360 / n;
  const polar = (r, deg) => {
    const a = (deg - 90) * Math.PI / 180;
    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
  };
  const sectorPath = (rIn, rOut, a0, a1) => {
    const [x1, y1] = polar(rOut, a0), [x2, y2] = polar(rOut, a1);
    const [x3, y3] = polar(rIn, a1),  [x4, y4] = polar(rIn, a0);
    const large = a1 - a0 > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${rOut} ${rOut} 0 ${large} 1 ${x2} ${y2} L ${x3} ${y3} A ${rIn} ${rIn} 0 ${large} 0 ${x4} ${y4} Z`;
  };
  const rHub = size * 0.12;
  const rCore = size * 0.28;
  const rSec = size * 0.44;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        {/* marbled fill for hub — overlapping radial waves */}
        <radialGradient id="ln-marble" cx="50%" cy="50%" r="60%">
          <stop offset="0%" stopColor={LN.paper} stopOpacity="0.95"/>
          <stop offset="40%" stopColor={LN.gilt} stopOpacity="0.4"/>
          <stop offset="70%" stopColor={LN.ribbon} stopOpacity="0.5"/>
          <stop offset="100%" stopColor={LN.ink} stopOpacity="0.6"/>
        </radialGradient>
        <radialGradient id="ln-focus" cx="50%" cy="50%" r="80%">
          <stop offset="0%" stopColor={LN.gilt} stopOpacity="0.4"/>
          <stop offset="100%" stopColor={LN.cores[focus]} stopOpacity="0.9"/>
        </radialGradient>
      </defs>

      {/* outer double-rule */}
      <circle cx={cx} cy={cy} r={(size / 2) - 1} fill={LN.paper} stroke={LN.gilt} strokeWidth="1.2"/>
      <circle cx={cx} cy={cy} r={(size / 2) - 5} fill="none" stroke={LN.gilt} strokeWidth="0.6"/>

      {/* SECONDARY ring */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceA;
        const isF = c.id === focus;
        return c.secondaries.map((s, si) => {
          const w = sliceA / c.secondaries.length;
          const a0 = baseA + si * w;
          const a1 = a0 + w;
          return (
            <path key={`s-${c.id}-${si}`}
              d={sectorPath(rCore, rSec, a0, a1)}
              fill={isF ? withAlpha(LN.cores[c.id], 0.18) : 'transparent'}
              stroke={LN.ink} strokeWidth="0.5"/>
          );
        });
      })}

      {/* CORE ring */}
      {cores.map((c, ci) => {
        const a0 = ci * sliceA, a1 = a0 + sliceA;
        const isF = c.id === focus;
        return (
          <g key={`c-${c.id}`}>
            <path d={sectorPath(rHub, rCore, a0, a1)}
              fill={isF ? 'url(#ln-focus)' : LN.cores[c.id]}
              opacity={isF ? 1 : 0.85}
              stroke={LN.ink} strokeWidth="0.8"/>
          </g>
        );
      })}

      {/* SECONDARY labels */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceA;
        return c.secondaries.map((s, si) => {
          const w = sliceA / c.secondaries.length;
          const aMid = baseA + si * w + w / 2;
          const [lx, ly] = polar((rCore + rSec) / 2, aMid);
          return (
            <text key={`sl-${c.id}-${si}`} x={lx} y={ly + 2}
              textAnchor="middle" dominantBaseline="middle"
              fontFamily={LNF.sc} fontSize={size * 0.026}
              fill={LN.ink} style={{ letterSpacing: 1, fontWeight: 600 }}>{s.name.toUpperCase()}</text>
          );
        });
      })}

      {/* CORE labels */}
      {cores.map((c, ci) => {
        const aMid = ci * sliceA + sliceA / 2;
        const [lx, ly] = polar((rHub + rCore) / 2, aMid);
        return (
          <text key={`l-${c.id}`} x={lx} y={ly + 2}
            textAnchor="middle" dominantBaseline="middle"
            fontFamily={LNF.sc} fontSize={size * 0.04}
            fontWeight="600"
            fill={LN.paper} style={{ letterSpacing: 2 }}>{c.name.toUpperCase()}</text>
        );
      })}

      {/* HUB — marbled centre with monogram */}
      <circle cx={cx} cy={cy} r={rHub} fill="url(#ln-marble)" stroke={LN.gilt} strokeWidth="1.2"/>
      <circle cx={cx} cy={cy} r={rHub - 3} fill="none" stroke={LN.gilt} strokeWidth="0.5" opacity="0.6"/>
      <text x={cx} y={cy + 1} textAnchor="middle" dominantBaseline="middle"
        fontFamily={LNF.sc} fontStyle="italic" fontSize={rHub * 0.7}
        fill={LN.gilt} fontWeight="600">OF</text>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Tab bar — bookmark ribbons hanging down
// ─────────────────────────────────────────────────────────────
function LinenTabs({ active }) {
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 30,
      paddingBottom: 28, paddingTop: 10,
      background: `linear-gradient(180deg, ${LN.cloth2} 0%, ${LN.cloth} 100%)`,
      borderTop: `2px solid ${LN.gilt}`,
    }}>
      <div style={{
        position: 'absolute', top: 0, left: 16, right: 16, height: 0.5, background: LN.gilt, opacity: 0.6,
      }}/>
      <div style={{ display: 'flex', justifyContent: 'space-around', padding: '0 6px' }}>
        {TAB_DEFS.map(t => {
          const isActive = t.key === active;
          return (
            <div key={t.key} style={{
              position: 'relative', display: 'flex', flexDirection: 'column',
              alignItems: 'center', gap: 2,
              color: isActive ? LN.giltDk : LN.muted,
            }}>
              {/* bookmark ribbon */}
              {isActive && (
                <div style={{
                  position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)',
                  width: 28, height: 8, background: LN.ribbon,
                  clipPath: 'polygon(0 0, 100% 0, 100% 60%, 50% 100%, 0 60%)',
                }}/>
              )}
              <div style={{ width: 24, height: 24, marginTop: 4, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {Icons[t.iconName](isActive ? LN.giltDk : LN.muted, isActive ? 1.9 : 1.3)}
              </div>
              <div style={{
                fontFamily: LNF.sc, fontSize: 9, letterSpacing: 1.5, fontWeight: 600,
              }}>{t.label.toUpperCase()}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

const LinenGear = () => (
  <button style={{
    position: 'absolute', top: 64, right: 18, zIndex: 7,
    width: 36, height: 36, borderRadius: 18, border: `1px solid ${LN.gilt}`,
    background: LN.paper, color: LN.giltDk,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    boxShadow: '0 2px 4px rgba(0,0,0,0.08)',
  }}>{Icons.gear(LN.giltDk, 1.6)}</button>
);

// ─────────────────────────────────────────────────────────────
// SCREEN 1 — Onboarding (book cover / title page)
// ─────────────────────────────────────────────────────────────
function LinenOnboarding() {
  return (
    <LinenCloth>
      {/* gilt decorative frame */}
      <div style={{
        position: 'absolute', top: 80, left: 26, right: 26, bottom: 130,
        border: `1.5px solid ${LN.gilt}`,
      }}>
        <div style={{ position: 'absolute', inset: 6, border: `0.5px solid ${LN.gilt}` }}/>
        {/* corner flourishes */}
        {['tl','tr','bl','br'].map(c => (
          <div key={c} style={{
            position: 'absolute',
            [c.includes('t') ? 'top' : 'bottom']: -6,
            [c.includes('l') ? 'left' : 'right']: -6,
            width: 14, height: 14, border: `1.5px solid ${LN.gilt}`,
            background: LN.cloth,
            transform: 'rotate(45deg)',
          }}/>
        ))}
        {/* contents */}
        <div style={{ position: 'absolute', top: 26, left: 16, right: 16, textAlign: 'center' }}>
          <div style={{
            fontFamily: LNF.sc, fontSize: 11, color: LN.giltDk,
            letterSpacing: 5, fontWeight: 600,
          }}>BEING A SMALL BOOK OF</div>
          <div style={{
            marginTop: 14, fontFamily: LNF.serif, fontSize: 26, color: LN.ink,
            fontStyle: 'italic', lineHeight: 1.05,
          }}>Open<br/>Feelings</div>
          <div style={{
            marginTop: 14, fontFamily: LNF.sc, fontSize: 10, color: LN.giltDk,
            letterSpacing: 4, fontWeight: 600,
          }}>·<br/>EDITION I · MMXXVI</div>
        </div>

        {/* the medallion */}
        <div style={{ position: 'absolute', top: 180, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
          <LinenWheel size={240}/>
        </div>

        <div style={{ position: 'absolute', bottom: 30, left: 20, right: 20, textAlign: 'center' }}>
          <div style={{
            fontFamily: LNF.italic, fontStyle: 'italic', fontSize: 14,
            color: LN.ink2, lineHeight: 1.4,
          }}>
            "A private notebook for naming<br/>
            how you feel, and reading it later."
          </div>
        </div>
      </div>

      <div style={{ position: 'absolute', bottom: 50, left: 26, right: 26 }}>
        <button style={{
          width: '100%', padding: '15px', background: LN.ink, color: LN.gilt,
          border: `1.5px solid ${LN.gilt}`, borderRadius: 0,
          fontFamily: LNF.sc, fontSize: 13, letterSpacing: 5, fontWeight: 600,
          boxShadow: 'inset 0 0 0 1px rgba(184,149,84,0.5)',
        }}>OPEN THE BOOK</button>
      </div>
    </LinenCloth>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 2 — Today (a paper insert pinned to the cloth)
// ─────────────────────────────────────────────────────────────
function LinenToday() {
  return (
    <LinenCloth>
      <LinenGear/>
      <div style={{ position: 'absolute', top: 76, left: 18, right: 18, bottom: 100, overflow: 'hidden' }}>
        <TippedIn style={{ padding: '16px 18px', height: '100%', overflow: 'hidden' }}>
          <Bookplate pre="THURSDAY · 28 MAY · MMXXVI" title="TODAY" post="Two entries; the morning was tight."/>

          <LinenSection>I · THE INTENTION</LinenSection>
          <div style={{
            padding: '12px 16px', background: LN.cloth, border: `0.5px solid ${LN.gilt}`,
          }}>
            <div style={{
              fontFamily: LNF.italic, fontStyle: 'italic', fontSize: 17,
              color: LN.ink, lineHeight: 1.35,
            }}>"Be slower with replies. Listen first."</div>
          </div>

          <LinenSection>II · THE DAY'S ENTRIES</LinenSection>
          {[
            { t: '09:14', word: 'Overwhelmed', sub: 'FEARFUL · ANXIOUS', i: 4, note: 'Big presentation in an hour. Hands cold.', c: 'fearful' },
            { t: '12:38', word: 'Thankful', sub: 'HAPPY · PEACEFUL', i: 3, c: 'happy' },
          ].map((it, i) => (
            <div key={i} style={{
              display: 'flex', gap: 12, padding: '12px 0',
              borderBottom: i < 1 ? `0.5px dotted ${LN.gilt}` : 'none',
            }}>
              <div style={{ width: 48, paddingTop: 2 }}>
                <div style={{
                  fontFamily: LNF.mono, fontSize: 11, color: LN.muted, fontVariantNumeric: 'tabular-nums',
                }}>{it.t}</div>
                <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 2 }}>
                  {[1,2,3,4,5].map(n => (
                    <div key={n} style={{
                      width: 16, height: 2,
                      background: n <= it.i ? LN.cores[it.c] : LN.faint, opacity: n <= it.i ? 1 : 0.4,
                    }}/>
                  ))}
                </div>
              </div>
              <div style={{
                width: 2, alignSelf: 'stretch', background: LN.gilt, opacity: 0.5,
              }}/>
              <div style={{ flex: 1 }}>
                <div style={{
                  fontFamily: LNF.serif, fontStyle: 'italic', fontSize: 21,
                  color: LN.cores[it.c], fontWeight: 500, lineHeight: 1, letterSpacing: -0.2,
                }}>{it.word}</div>
                <div style={{
                  marginTop: 4, fontFamily: LNF.sc, fontSize: 9, color: LN.giltDk, letterSpacing: 2.5, fontWeight: 600,
                }}>{it.sub}</div>
                {it.note && (
                  <div style={{
                    marginTop: 6, fontFamily: LNF.italic, fontStyle: 'italic',
                    fontSize: 13, color: LN.ink2, lineHeight: 1.4,
                  }}>"{it.note}"</div>
                )}
              </div>
            </div>
          ))}

          <LinenSection>✦</LinenSection>
          <button style={{
            width: '100%', padding: '11px', background: LN.ink, color: LN.gilt,
            border: 'none', fontFamily: LNF.sc, fontSize: 11, letterSpacing: 3.5, fontWeight: 600,
          }}>SET DOWN ANOTHER ✦</button>
        </TippedIn>
      </div>
      <LinenTabs active="today"/>
    </LinenCloth>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 3 — Check-in entry (the medallion plate)
// ─────────────────────────────────────────────────────────────
function LinenCheckIn() {
  return (
    <LinenCloth>
      <LinenGear/>
      <div style={{ position: 'absolute', top: 76, left: 18, right: 18, bottom: 100, overflow: 'hidden' }}>
        <TippedIn style={{ padding: '16px 18px', height: '100%' }}>
          <Bookplate pre="PLATE I · STEP 2 OF 4" title="NAME IT" post="Adapted from Open Emotion Wheel v1.1"/>
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: 14 }}>
            <LinenWheel size={300}/>
          </div>
          <LinenSection>YOUR PICK</LinenSection>
          <div style={{
            padding: '10px 14px', background: LN.cloth, border: `0.5px solid ${LN.gilt}`,
            display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <span style={{ width: 8, height: 22, background: LN.cores.fearful }}/>
            <div style={{ flex: 1 }}>
              <div style={{
                fontFamily: LNF.serif, fontStyle: 'italic', fontSize: 18, color: LN.ink, fontWeight: 500,
              }}>Fearful · Anxious</div>
              <div style={{
                fontFamily: LNF.sc, fontSize: 9, color: LN.muted, letterSpacing: 2,
              }}>Drill in below, or save as-is.</div>
            </div>
            <button style={{
              padding: '8px 14px', background: LN.ink, color: LN.gilt, border: 'none',
              fontFamily: LNF.sc, fontSize: 10, letterSpacing: 2.5, fontWeight: 600,
            }}>SAVE</button>
          </div>

          {/* mode picker */}
          <div style={{ marginTop: 14, display: 'flex', border: `0.5px solid ${LN.gilt}` }}>
            {['Wheel', 'Guided', 'Quick'].map((m, i) => (
              <button key={m} style={{
                flex: 1, padding: '8px', border: 'none',
                borderRight: i < 2 ? `0.5px solid ${LN.gilt}` : 'none',
                background: i === 0 ? LN.cloth : LN.paper,
                color: i === 0 ? LN.ink : LN.muted,
                fontFamily: LNF.sc, fontSize: 10, letterSpacing: 2.5, fontWeight: 600,
              }}>{m.toUpperCase()}</button>
            ))}
          </div>
        </TippedIn>
      </div>
      <LinenTabs active="checkIn"/>
    </LinenCloth>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 4 — Wizard step (Reflect)
// ─────────────────────────────────────────────────────────────
function LinenWizardStep() {
  return (
    <LinenCloth>
      <div style={{ position: 'absolute', top: 76, left: 18, right: 18, bottom: 100, overflow: 'hidden' }}>
        <TippedIn style={{ padding: '16px 18px', height: '100%' }}>
          {/* progress */}
          <div style={{ display: 'flex', gap: 4, marginBottom: 14 }}>
            {[0,1,2,3,4,5,6].map(i => (
              <div key={i} style={{
                flex: 1, height: 3,
                background: i <= 6 ? LN.gilt : LN.faint,
                opacity: i <= 6 ? 1 : 0.3,
              }}/>
            ))}
          </div>
          <Bookplate pre="STEP 7 OF 7 · FINAL" title="REFLECT" post="Anything you'd like to remember?"/>

          {/* selection summary */}
          <div style={{
            marginTop: 12, padding: '10px 14px', background: LN.cloth, border: `0.5px solid ${LN.gilt}`,
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <span style={{ width: 8, height: 18, background: LN.cores.fearful }}/>
            <div style={{ flex: 1 }}>
              <div style={{
                fontFamily: LNF.serif, fontStyle: 'italic', fontSize: 15,
                color: LN.ink, fontWeight: 500,
              }}>Fearful · Anxious · Overwhelmed</div>
              <div style={{
                fontFamily: LNF.sc, fontSize: 9, color: LN.muted, letterSpacing: 2,
              }}>INTENSITY 4/5 · CHEST · HANDS</div>
            </div>
          </div>

          {/* note */}
          <LinenSection>YOUR NOTE</LinenSection>
          <div style={{
            padding: '14px 16px', background: '#FCF7E4',
            border: `0.5px solid ${LN.gilt}`,
            backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 23px, rgba(184,149,84,0.18) 23px, rgba(184,149,84,0.18) 24px)`,
            minHeight: 140,
          }}>
            <div style={{
              fontFamily: LNF.italic, fontStyle: 'italic', fontSize: 16,
              color: LN.ink, lineHeight: '24px',
            }}>
              "Big presentation in an hour. Hands<br/>
              cold. Keep noticing my jaw clenching.<br/>
              Made it through the first slide."
            </div>
          </div>

          <LinenSection>TAGS</LinenSection>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {['work', 'colleagues', 'morning'].map(t => (
              <span key={t} style={{
                padding: '4px 10px', border: `0.5px solid ${LN.gilt}`,
                background: LN.cloth,
                fontFamily: LNF.sc, fontSize: 10, color: LN.giltDk, letterSpacing: 2, fontWeight: 600,
              }}>+ {t.toUpperCase()}</span>
            ))}
          </div>

          {/* CTA */}
          <div style={{
            position: 'absolute', bottom: 16, left: 18, right: 18,
            display: 'flex', gap: 8,
          }}>
            <button style={{
              padding: '12px 16px', background: 'transparent',
              border: `0.5px solid ${LN.ink}`, color: LN.ink,
              fontFamily: LNF.sc, fontSize: 10, letterSpacing: 2.5, fontWeight: 600,
            }}>← BACK</button>
            <button style={{
              flex: 1, padding: '12px', background: LN.ink, color: LN.gilt,
              border: 'none', fontFamily: LNF.sc, fontSize: 12, letterSpacing: 3, fontWeight: 600,
            }}>SAVE ✦</button>
          </div>
        </TippedIn>
      </div>
      <LinenTabs active="checkIn"/>
    </LinenCloth>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 5 — Insights
// ─────────────────────────────────────────────────────────────
function LinenInsights() {
  return (
    <LinenCloth>
      <LinenGear/>
      <div style={{ position: 'absolute', top: 76, left: 18, right: 18, bottom: 100, overflow: 'hidden' }}>
        <TippedIn style={{ padding: '16px 18px', height: '100%', overflow: 'hidden' }}>
          <Bookplate pre="MAY · MMXXVI" title="INSIGHTS" post="Twenty-seven entries · five families"/>

          {/* big number */}
          <div style={{
            marginTop: 14, textAlign: 'center',
            padding: '8px 0',
            borderTop: `0.5px solid ${LN.gilt}`,
            borderBottom: `0.5px solid ${LN.gilt}`,
          }}>
            <div style={{
              fontFamily: LNF.serif, fontSize: 56, color: LN.cores.fearful,
              fontVariantNumeric: 'oldstyle-nums', lineHeight: 1,
            }}>27</div>
            <div style={{
              marginTop: 2, fontFamily: LNF.sc, fontSize: 11, color: LN.muted,
              letterSpacing: 3.5, fontWeight: 600,
            }}>MOSTLY FEARFUL · INTENSITY 3.5/5</div>
          </div>

          <LinenSection>BY FAMILY</LinenSection>
          {[
            { n: 'Fearful', c: 'fearful', v: 11, p: 40 },
            { n: 'Happy', c: 'happy', v: 9, p: 33 },
            { n: 'Sad', c: 'sad', v: 4, p: 15 },
            { n: 'Angry', c: 'angry', v: 2, p: 8 },
            { n: 'Disgusted', c: 'disgusted', v: 1, p: 4 },
          ].map(t => (
            <div key={t.n} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '7px 0',
              borderBottom: `0.5px dotted ${LN.gilt}`,
            }}>
              <div style={{
                width: 90, fontFamily: LNF.serif, fontStyle: 'italic', fontSize: 16, color: LN.cores[t.c], fontWeight: 500,
              }}>{t.n}</div>
              <div style={{ flex: 1, height: 8, background: LN.cloth, position: 'relative', border: `0.5px solid ${LN.gilt}` }}>
                <div style={{
                  position: 'absolute', inset: 0, width: `${t.p}%`,
                  background: LN.cores[t.c],
                }}/>
              </div>
              <div style={{
                width: 30, textAlign: 'right',
                fontFamily: LNF.mono, fontSize: 11, color: LN.muted, fontVariantNumeric: 'tabular-nums',
              }}>{t.v}×</div>
            </div>
          ))}

          <LinenSection>INTENSITY · LAST FOURTEEN DAYS</LinenSection>
          <svg width="100%" height="64" viewBox="0 0 280 64">
            {[20, 40].map(y => (
              <line key={y} x1="0" y1={y} x2="280" y2={y} stroke={LN.gilt} strokeWidth="0.4" strokeDasharray="2 3"/>
            ))}
            <polyline points={[3,2,4,5,3,4,2,3,5,4,3,2,4,3].map((d, i) => `${(i / 13) * 270 + 5},${60 - (d - 1) * 12}`).join(' ')}
              stroke={LN.giltDk} strokeWidth="1.4" fill="none"/>
            {[3,2,4,5,3,4,2,3,5,4,3,2,4,3].map((d, i) => (
              <circle key={i} cx={(i / 13) * 270 + 5} cy={60 - (d - 1) * 12} r="2.5"
                fill={LN.gilt} stroke={LN.ink} strokeWidth="0.6"/>
            ))}
          </svg>
        </TippedIn>
      </div>
      <LinenTabs active="insights"/>
    </LinenCloth>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 6 — History
// ─────────────────────────────────────────────────────────────
function LinenHistory() {
  return (
    <LinenCloth>
      <div style={{ position: 'absolute', top: 76, left: 18, right: 18, bottom: 100, overflow: 'hidden' }}>
        <TippedIn style={{ padding: '16px 18px', height: '100%', overflow: 'hidden' }}>
          <Bookplate pre="ALL ENTRIES · MOST RECENT FIRST" title="HISTORY"/>

          {/* filter row */}
          <div style={{
            marginTop: 10, display: 'flex', gap: 4, alignItems: 'center', flexWrap: 'wrap',
          }}>
            <span style={{ fontFamily: LNF.sc, fontSize: 9, color: LN.muted, letterSpacing: 2.5, fontWeight: 600, marginRight: 4 }}>
              FILTER
            </span>
            {['ALL', 'HAPPY', 'SAD', 'ANGRY', 'FEARFUL', 'DISG.'].map((c, i) => (
              <span key={c} style={{
                padding: '3px 8px', border: `0.5px solid ${LN.gilt}`,
                background: i === 0 ? LN.ink : LN.cloth,
                color: i === 0 ? LN.gilt : LN.ink,
                fontFamily: LNF.sc, fontSize: 9, letterSpacing: 1.5, fontWeight: 600,
              }}>{c}</span>
            ))}
          </div>

          {[
            { d: 'THURSDAY · 28 MAY · TODAY', items: [
              { t: '12:38', word: 'Thankful', sub: 'HAPPY · PEACEFUL', i: 3, c: 'happy' },
              { t: '09:14', word: 'Overwhelmed', sub: 'FEARFUL · ANXIOUS', i: 4, c: 'fearful', note: 'Big presentation in an hour.' },
            ]},
            { d: 'WEDNESDAY · 27 MAY', items: [
              { t: '20:02', word: 'Disappointed', sub: 'SAD · HURT', i: 3, c: 'sad' },
              { t: '16:15', word: 'Confident', sub: 'HAPPY · PROUD', i: 4, c: 'happy' },
            ]},
            { d: 'TUESDAY · 26 MAY', items: [
              { t: '18:30', word: 'Annoyed', sub: 'ANGRY · FRUSTRATED', i: 3, c: 'angry' },
            ]},
          ].map(g => (
            <div key={g.d} style={{ marginTop: 14 }}>
              <LinenSection>{g.d}</LinenSection>
              {g.items.map((it, i) => (
                <div key={i} style={{
                  display: 'flex', gap: 12, padding: '9px 0',
                  borderBottom: `0.5px dotted ${LN.gilt}`,
                }}>
                  <div style={{
                    width: 44, fontFamily: LNF.mono, fontSize: 11, color: LN.muted,
                    paddingTop: 3, fontVariantNumeric: 'tabular-nums',
                  }}>{it.t}</div>
                  <div style={{ width: 2, background: LN.cores[it.c], alignSelf: 'stretch' }}/>
                  <div style={{ flex: 1 }}>
                    <div style={{
                      fontFamily: LNF.serif, fontStyle: 'italic', fontSize: 18,
                      color: LN.cores[it.c], fontWeight: 500, lineHeight: 1, letterSpacing: -0.2,
                    }}>{it.word}</div>
                    <div style={{
                      marginTop: 3, fontFamily: LNF.sc, fontSize: 9, color: LN.giltDk, letterSpacing: 2, fontWeight: 600,
                    }}>{it.sub} · {it.i}/5</div>
                    {it.note && (
                      <div style={{
                        marginTop: 4, fontFamily: LNF.italic, fontStyle: 'italic', fontSize: 12,
                        color: LN.ink2, lineHeight: 1.4,
                      }}>"{it.note}"</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ))}
        </TippedIn>
      </div>
      <LinenTabs active="today"/>
    </LinenCloth>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 7 — Direction
// ─────────────────────────────────────────────────────────────
function LinenDirection() {
  return (
    <LinenCloth>
      <LinenGear/>
      <div style={{ position: 'absolute', top: 76, left: 18, right: 18, bottom: 100, overflow: 'hidden' }}>
        <TippedIn style={{ padding: '16px 18px', height: '100%' }}>
          <Bookplate pre="INTENTIONS, VALUES, &amp; ACTS" title="DIRECTION"/>

          {/* tabs */}
          <div style={{ marginTop: 12, display: 'flex', border: `0.5px solid ${LN.gilt}` }}>
            {['INTENTION', 'VALUES', 'ACTIONS'].map((m, i) => (
              <button key={m} style={{
                flex: 1, padding: '8px', border: 'none',
                borderRight: i < 2 ? `0.5px solid ${LN.gilt}` : 'none',
                background: i === 0 ? LN.cloth : LN.paper,
                color: i === 0 ? LN.ink : LN.muted,
                fontFamily: LNF.sc, fontSize: 10, letterSpacing: 2.5, fontWeight: 600,
              }}>{m}</button>
            ))}
          </div>

          <LinenSection>TODAY · 28 MAY</LinenSection>
          <div style={{
            padding: '14px 18px', background: LN.cloth,
            border: `0.5px solid ${LN.gilt}`,
          }}>
            <div style={{
              fontFamily: LNF.italic, fontStyle: 'italic', fontSize: 20,
              color: LN.ink, lineHeight: 1.3, fontWeight: 500,
            }}>
              "Be slower with replies.<br/>Listen first."
            </div>
            <div style={{ marginTop: 14, display: 'flex', gap: 6, alignItems: 'center' }}>
              <span style={{ fontFamily: LNF.sc, fontSize: 9, color: LN.muted, letterSpacing: 2, fontWeight: 600 }}>
                LIVED IT?
              </span>
              <span style={{ flex: 1 }}/>
              {['HARD', 'OK', 'YES'].map(l => (
                <button key={l} style={{
                  padding: '4px 10px', border: `0.5px solid ${LN.ink}`,
                  background: l === 'OK' ? LN.ink : 'transparent',
                  color: l === 'OK' ? LN.gilt : LN.ink,
                  fontFamily: LNF.sc, fontSize: 9, letterSpacing: 1.5, fontWeight: 600,
                }}>{l}</button>
              ))}
            </div>
          </div>

          <LinenSection>RECENT DAYS</LinenSection>
          {[
            { d: 'WED', t: 'Eat lunch away from the desk.', r: 'OK' },
            { d: 'TUE', t: "Notice when I'm holding my breath.", r: 'YES' },
            { d: 'MON', t: 'Send the message I keep avoiding.', r: 'HARD' },
            { d: 'SUN', t: 'No phone before coffee.', r: 'YES' },
          ].map(p => (
            <div key={p.d} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '9px 0',
              borderBottom: `0.5px dotted ${LN.gilt}`,
            }}>
              <span style={{
                width: 34, fontFamily: LNF.sc, fontSize: 9, color: LN.muted, letterSpacing: 1.5, fontWeight: 600,
              }}>{p.d}</span>
              <span style={{
                flex: 1, fontFamily: LNF.italic, fontStyle: 'italic', fontSize: 14, color: LN.ink,
              }}>{p.t}</span>
              <span style={{
                padding: '2px 8px', fontFamily: LNF.sc, fontSize: 9, letterSpacing: 1.5, fontWeight: 600,
                color: p.r === 'YES' ? LN.cores.disgusted : p.r === 'HARD' ? LN.cores.angry : LN.ink,
                border: `0.5px solid ${p.r === 'YES' ? LN.cores.disgusted : p.r === 'HARD' ? LN.cores.angry : LN.ink}`,
              }}>{p.r}</span>
            </div>
          ))}
        </TippedIn>
      </div>
      <LinenTabs active="direction"/>
    </LinenCloth>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 8 — Settings (as a tipped-in insert)
// ─────────────────────────────────────────────────────────────
function LinenSettings() {
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'rgba(28,22,16,0.55)', overflow: 'hidden' }}>
      <LinenCloth>
        <div style={{ opacity: 0.4 }}/>
      </LinenCloth>
      <div style={{
        position: 'absolute', top: 56, left: 0, right: 0, bottom: 0,
        background: LN.cloth,
        borderTop: `2px solid ${LN.gilt}`,
        boxShadow: '0 -10px 30px rgba(28,22,16,0.18)',
        overflow: 'hidden', paddingTop: 8,
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '4px 0 6px' }}>
          <div style={{ width: 36, height: 4, background: LN.giltDk }}/>
        </div>
        <div style={{ padding: '0 14px 8px' }}>
          <TippedIn style={{ padding: '12px 18px 18px' }}>
            <div style={{
              display: 'flex', alignItems: 'center', paddingBottom: 8,
              borderBottom: `1px solid ${LN.gilt}`,
            }}>
              <div style={{ flex: 1 }}>
                <div style={{
                  fontFamily: LNF.sc, fontSize: 10, color: LN.giltDk, letterSpacing: 4, fontWeight: 600,
                }}>SETTINGS &amp; COLOPHON</div>
              </div>
              <button style={{
                padding: '4px 12px', background: LN.ink, color: LN.gilt, border: 'none',
                fontFamily: LNF.sc, fontSize: 10, letterSpacing: 2.5, fontWeight: 600,
              }}>DONE</button>
            </div>

            <div style={{ overflow: 'auto', maxHeight: 600, marginTop: 6 }}>
              {[
                { h: 'I · YOU', rows: [
                  { l: 'Display name', d: 'Taylor' },
                  { l: 'Appearance', d: 'Auto' },
                ]},
                { h: 'II · CHECK-IN', rows: [
                  { l: 'Default mode', d: 'Wheel' },
                  { l: 'Body region first', toggle: true, on: true },
                  { l: 'Show clinical notes', toggle: true, on: true },
                ]},
                { h: 'III · PRIVACY', rows: [
                  { l: 'iCloud sync', d: 'synced 2m ago', good: true },
                  { l: 'Face ID lock', toggle: true, on: true },
                  { l: 'Apple Health write', toggle: true, on: false },
                ]},
                { h: 'IV · EXPORT', rows: [
                  { l: 'Local backup', d: '' },
                  { l: 'CSV / JSON', d: '' },
                  { l: 'Therapy report PDF', d: '' },
                ]},
                { h: 'V · TIP THE BINDER', rows: [
                  { l: '🥤 Soda', d: '$1.99', donate: true },
                  { l: '🥪 Lunch', d: '$4.99', donate: true },
                  { l: '🍝 Dinner', d: '$9.99', donate: true },
                ]},
              ].map(sec => (
                <div key={sec.h} style={{ marginBottom: 14 }}>
                  <LinenSection>{sec.h}</LinenSection>
                  {sec.rows.map((r, i) => (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'center', padding: '9px 0',
                      borderBottom: i < sec.rows.length - 1 ? `0.5px dotted ${LN.gilt}` : 'none',
                    }}>
                      <div style={{
                        flex: 1, fontFamily: LNF.italic, fontStyle: 'italic', fontSize: 15, color: LN.ink,
                      }}>{r.l}</div>
                      {r.d && (
                        <div style={{
                          marginRight: 10, fontFamily: LNF.mono, fontSize: 11,
                          color: r.good ? LN.cores.disgusted : LN.muted, fontVariantNumeric: 'tabular-nums',
                        }}>{r.d}</div>
                      )}
                      {r.toggle && (
                        <div style={{
                          width: 36, height: 20, border: `0.5px solid ${LN.ink}`,
                          background: r.on ? LN.ink : LN.cloth,
                          display: 'flex', padding: 1,
                          justifyContent: r.on ? 'flex-end' : 'flex-start',
                        }}>
                          <div style={{ width: 14, height: 14, background: r.on ? LN.gilt : LN.ink }}/>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ))}
              <div style={{
                textAlign: 'center', padding: '8px 0 24px',
                fontFamily: LNF.sc, fontSize: 9, color: LN.muted, letterSpacing: 2.5, fontWeight: 600,
              }}>
                BOUND BY HAND · MIT · MMXXVI<br/>
                <span style={{ fontFamily: LNF.italic, fontStyle: 'italic', letterSpacing: 0.5, fontWeight: 400, color: LN.giltDk }}>
                  github.com/TaylorFinklea
                </span>
              </div>
            </div>
          </TippedIn>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  LinenOnboarding, LinenToday, LinenCheckIn, LinenWizardStep,
  LinenInsights, LinenHistory, LinenDirection, LinenSettings,
  LinenWheel,
});
