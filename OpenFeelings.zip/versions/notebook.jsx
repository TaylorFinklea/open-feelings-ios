// V3 — NOTEBOOK
// Paper-family. Ruled notebook paper feel. Hand-drawn diagrams. Caveat
// handwriting for margin annotations. Pages turn. Wheel rendered as a
// diagram with curly-brace annotations pointing in.
// Exports Notebook* screens to window.

const N = {
  paper:   '#FAF6E8',         // off-cream
  ruleBlue: '#9DBED1',
  ruleBlueSoft: 'rgba(157, 190, 209, 0.5)',
  marginRed: '#D9655A',
  ink:     '#1F2C3A',          // pen ink
  ink2:    '#3D4A5A',
  pencil:  '#5C5852',
  muted:   '#7C7569',
  highlight: '#F5E48C',
  faint:   '#A8A294',
  divider: '#D8D0BD',
  // Slightly muted cores (felt-tip pens)
  cores: {
    happy:     '#C18A1D',
    sad:       '#3C7397',
    angry:     '#C24E36',
    fearful:   '#7E4E9B',
    disgusted: '#4E7B4A',
  },
  // Highlighter washes
  hi: {
    happy:     'rgba(245, 228, 140, 0.6)',
    sad:       'rgba(173, 209, 230, 0.6)',
    angry:     'rgba(238, 167, 153, 0.55)',
    fearful:   'rgba(206, 184, 222, 0.55)',
    disgusted: 'rgba(189, 218, 184, 0.55)',
  },
};
const NF = {
  serif: '"Iowan Old Style", "Source Serif 4", Georgia, serif',
  hand:  '"Caveat", "Bradley Hand", cursive',
  sans:  '"IBM Plex Sans", -apple-system, system-ui, sans-serif',
  mono:  '"IBM Plex Mono", ui-monospace, monospace',
};

// ─────────────────────────────────────────────────────────────
// Ruled-paper background
// ─────────────────────────────────────────────────────────────
function NotebookPaper({ children, bg = N.paper, rule = true, margin = true }) {
  return (
    <div style={{ position: 'absolute', inset: 0, background: bg, overflow: 'hidden' }}>
      {/* horizontal ruling */}
      {rule && (
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: `linear-gradient(to bottom, transparent calc(28px - 1px), ${N.ruleBlueSoft} calc(28px - 1px), ${N.ruleBlueSoft} 28px)`,
          backgroundSize: '100% 28px',
          backgroundPosition: '0 56px',
          pointerEvents: 'none',
        }}/>
      )}
      {/* red margin line at left */}
      {margin && (
        <div style={{
          position: 'absolute', top: 0, bottom: 0, left: 44,
          width: 1, background: N.marginRed, opacity: 0.6,
        }}/>
      )}
      {/* paper grain */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.07, mixBlendMode: 'multiply' }}>
        <filter id="noise-n">
          <feTurbulence type="fractalNoise" baseFrequency="0.7" numOctaves="2" seed="5"/>
          <feColorMatrix values="0 0 0 0 0.2  0 0 0 0 0.18  0 0 0 0 0.1  0 0 0 0.2 0"/>
        </filter>
        <rect width="100%" height="100%" filter="url(#noise-n)"/>
      </svg>
      {children}
    </div>
  );
}

// "Doodle" arrow — hand-drawn SVG
function DoodleArrow({ from, to, color = N.ink, curve = 0, label }) {
  const [x1, y1] = from;
  const [x2, y2] = to;
  const mx = (x1 + x2) / 2 + curve;
  const my = (y1 + y2) / 2 - Math.abs(curve) * 0.3;
  const dx = x2 - mx, dy = y2 - my;
  const ang = Math.atan2(dy, dx);
  const ax = x2 - Math.cos(ang) * 6;
  const ay = y2 - Math.sin(ang) * 6;
  const a1x = ax + Math.cos(ang + 2.6) * 6;
  const a1y = ay + Math.sin(ang + 2.6) * 6;
  const a2x = ax + Math.cos(ang - 2.6) * 6;
  const a2y = ay + Math.sin(ang - 2.6) * 6;
  return (
    <g>
      <path d={`M ${x1} ${y1} Q ${mx} ${my}, ${x2} ${y2}`}
        stroke={color} strokeWidth="1.4" fill="none" strokeLinecap="round"/>
      <path d={`M ${a1x} ${a1y} L ${x2} ${y2} L ${a2x} ${a2y}`}
        stroke={color} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
      {label && (
        <text x={mx} y={my - 6} textAnchor="middle"
          fontFamily={NF.hand} fontSize="14" fill={color}>{label}</text>
      )}
    </g>
  );
}

// Underline doodle — wavy line beneath a heading
function Underline({ color = N.ink, w = 120, style }) {
  return (
    <svg width={w} height="6" viewBox={`0 0 ${w} 6`} style={{ display: 'block', ...style }}>
      <path d={`M 2 4 Q ${w * 0.25} 1, ${w * 0.5} 4 T ${w - 2} 3`}
        stroke={color} strokeWidth="1.5" fill="none" strokeLinecap="round"/>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Hand-drawn wheel — loose ink circles with handwritten labels
// ─────────────────────────────────────────────────────────────
function NotebookWheel({ size = 300, focus = 'fearful' }) {
  const cx = size / 2, cy = size / 2;
  const cores = WHEEL_DATA;
  const n = cores.length;
  const sliceA = 360 / n;
  const polar = (r, deg) => {
    const a = (deg - 90) * Math.PI / 180;
    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
  };
  const sectorPath = (rIn, rOut, a0, a1) => {
    const [x1, y1] = polar(rOut, a0), [x2, y2] = polar(rOut, a1);
    const [x3, y3] = polar(rIn, a1),  [x4, y4] = polar(rIn, a0);
    const large = a1 - a0 > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${rOut} ${rOut} 0 ${large} 1 ${x2} ${y2} L ${x3} ${y3} A ${rIn} ${rIn} 0 ${large} 0 ${x4} ${y4} Z`;
  };
  const rHub = size * 0.12;
  const rCore = size * 0.30;
  const rSec = size * 0.46;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        {/* wavy/rough stroke filter — slight displacement */}
        <filter id="rough">
          <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="2"/>
          <feDisplacementMap in="SourceGraphic" scale="1.2"/>
        </filter>
      </defs>

      {/* outer hand-drawn circle */}
      <circle cx={cx} cy={cy} r={rSec + 6} fill="none" stroke={N.ink} strokeWidth="1.2"
        strokeDasharray="0.5 4" opacity="0.5"/>

      {/* SECONDARY ring — highlighter wash for each family */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceA;
        const isFocusFam = c.id === focus;
        return c.secondaries.map((s, si) => {
          const w = sliceA / c.secondaries.length;
          const a0 = baseA + si * w;
          const a1 = a0 + w;
          return (
            <path key={`s-${c.id}-${si}`}
              d={sectorPath(rCore, rSec, a0, a1)}
              fill={isFocusFam ? N.hi[c.id] : 'transparent'}
              stroke={N.ink} strokeWidth="0.8" opacity={isFocusFam ? 1 : 0.6}/>
          );
        });
      })}

      {/* CORE ring — hand-drawn pen */}
      {cores.map((c, ci) => {
        const a0 = ci * sliceA, a1 = a0 + sliceA;
        const isFocus = c.id === focus;
        return (
          <path key={`c-${c.id}`}
            d={sectorPath(rHub, rCore, a0, a1)}
            fill={isFocus ? N.hi[c.id] : 'transparent'}
            stroke={N.cores[c.id]} strokeWidth="1.6"/>
        );
      })}

      {/* SECONDARY labels — handwritten */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceA;
        return c.secondaries.map((s, si) => {
          const w = sliceA / c.secondaries.length;
          const aMid = baseA + si * w + w / 2;
          const [lx, ly] = polar((rCore + rSec) / 2, aMid);
          return (
            <text key={`sl-${c.id}-${si}`} x={lx} y={ly + 2}
              textAnchor="middle" dominantBaseline="middle"
              fontFamily={NF.hand} fontSize={size * 0.05}
              fill={N.ink}>{s.name.toLowerCase()}</text>
          );
        });
      })}

      {/* CORE labels — handwritten, larger */}
      {cores.map((c, ci) => {
        const aMid = ci * sliceA + sliceA / 2;
        const [lx, ly] = polar((rHub + rCore) / 2, aMid);
        return (
          <text key={`l-${c.id}`} x={lx} y={ly + 3}
            textAnchor="middle" dominantBaseline="middle"
            fontFamily={NF.hand} fontSize={size * 0.072}
            fill={N.cores[c.id]} fontWeight="600">{c.name.toLowerCase()}</text>
        );
      })}

      {/* HUB — circled "feel" */}
      <circle cx={cx} cy={cy} r={rHub} fill={N.paper} stroke={N.ink} strokeWidth="1.6"/>
      <text x={cx} y={cy + 2} textAnchor="middle" dominantBaseline="middle"
        fontFamily={NF.hand} fontSize={rHub * 0.55} fill={N.ink}>feel?</text>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Notebook tab bar
// ─────────────────────────────────────────────────────────────
function NotebookTabs({ active }) {
  return (
    <TabBar
      tabs={tabsForActive(active, N.ink)}
      active={active}
      bg={N.paper} fg={N.ink}
      muted={N.faint} accent={N.ink}
      border={N.ruleBlue} blur={false}
    />
  );
}

const HandLabel = ({ children, size = 22, color = N.ink, style }) => (
  <div style={{
    fontFamily: NF.hand, fontSize: size, color,
    letterSpacing: 0.2, lineHeight: 1.1, ...style,
  }}>{children}</div>
);

const NGear = () => (
  <button style={{
    position: 'absolute', top: 64, right: 18, zIndex: 6,
    width: 36, height: 36, borderRadius: 18, border: `1.5px dashed ${N.ink}`,
    background: N.paper, color: N.ink,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  }}>{Icons.gear(N.ink, 1.6)}</button>
);

// Sticky note / washi tape strip
const WashiTape = ({ color, text, style }) => (
  <div style={{
    padding: '5px 14px', background: color,
    fontFamily: NF.hand, fontSize: 16, color: N.ink,
    transform: 'rotate(-2deg)', boxShadow: '1px 2px 2px rgba(0,0,0,0.08)',
    ...style,
  }}>{text}</div>
);

// ─────────────────────────────────────────────────────────────
// SCREEN 1 — Onboarding (the inside-cover page)
// ─────────────────────────────────────────────────────────────
function NotebookOnboarding() {
  return (
    <NotebookPaper>
      <WashiTape color={N.highlight} text="open feelings" style={{
        position: 'absolute', top: 70, left: 60, transform: 'rotate(-3deg)',
      }}/>
      <div style={{
        position: 'absolute', top: 130, left: 60, right: 20,
        fontFamily: NF.serif, fontSize: 13, color: N.muted, letterSpacing: 0.3, fontStyle: 'italic',
      }}>this notebook belongs to —</div>
      <div style={{
        position: 'absolute', top: 150, left: 60, right: 20,
        fontFamily: NF.hand, fontSize: 32, color: N.ink,
      }}>____________</div>

      <div style={{ position: 'absolute', top: 200, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
        <NotebookWheel size={280} focus="fearful"/>
      </div>

      {/* Hand-drawn arrow w/ label */}
      <svg style={{ position: 'absolute', top: 240, left: 30, width: 120, height: 100, pointerEvents: 'none' }}
        viewBox="0 0 120 100">
        <DoodleArrow from={[18, 70]} to={[88, 36]} curve={28} label="5 families ↗"/>
      </svg>

      <div style={{ position: 'absolute', top: 500, left: 60, right: 20 }}>
        <div style={{
          fontFamily: NF.serif, fontSize: 26, color: N.ink, lineHeight: 1.2, fontStyle: 'italic',
        }}>
          A small place to put down<br/>how you feel.
        </div>
        <Underline w={150} color={N.marginRed} style={{ marginTop: 2 }}/>
        <HandLabel size={18} color={N.muted} style={{ marginTop: 14 }}>
          ✦ stays on your phone ✦<br/>
          ✦ no accounts, no ads ✦<br/>
          ✦ free, open source ✦
        </HandLabel>
      </div>

      <div style={{ position: 'absolute', bottom: 60, left: 60, right: 20 }}>
        <button style={{
          width: '100%', padding: '16px', background: N.paper,
          border: `2px solid ${N.ink}`, borderRadius: 14,
          fontFamily: NF.hand, fontSize: 26, color: N.ink,
          boxShadow: `3px 3px 0 ${N.marginRed}`,
        }}>begin →</button>
      </div>
    </NotebookPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 2 — Today (a notebook page for today)
// ─────────────────────────────────────────────────────────────
function NotebookToday() {
  return (
    <NotebookPaper>
      <NGear/>
      <div style={{ position: 'absolute', top: 60, left: 60, right: 20, bottom: 88, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <HandLabel size={18} color={N.muted}>thu · 28 may</HandLabel>
          <HandLabel size={14} color={N.marginRed}>page 148.</HandLabel>
        </div>

        <div style={{
          marginTop: 4, fontFamily: NF.serif, fontSize: 30, color: N.ink,
          fontStyle: 'italic', lineHeight: 1.05,
        }}>Today,</div>
        <Underline w={80} color={N.ink}/>

        {/* intention block — handwritten in margin */}
        <div style={{ marginTop: 18, position: 'relative' }}>
          <HandLabel size={16} color={N.marginRed} style={{ position: 'absolute', left: -56, top: 4 }}>
            ✦ intention
          </HandLabel>
          <div style={{
            fontFamily: NF.hand, fontSize: 22, color: N.ink, lineHeight: 1.3,
            background: N.highlight, padding: '2px 8px', display: 'inline',
            boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone',
          }}>
            "Be slower with replies. Listen first."
          </div>
        </div>

        {/* entries */}
        <div style={{
          marginTop: 28, fontFamily: NF.serif, fontSize: 18, color: N.ink,
          fontStyle: 'italic',
        }}>2 check-ins today</div>
        <Underline w={140} color={N.marginRed}/>

        <div style={{ marginTop: 12 }}>
          {[
            { t: '9:14a', word: 'anxious', full: 'Fearful · Anxious · Overwhelmed', i: 4, note: 'big presentation in an hour. hands cold!', c: 'fearful' },
            { t: '12:38p', word: 'thankful', full: 'Happy · Peaceful · Thankful', i: 3, c: 'happy' },
          ].map((it, i) => (
            <div key={i} style={{ position: 'relative', marginBottom: 16 }}>
              <HandLabel size={15} color={N.pencil} style={{
                position: 'absolute', left: -56, top: 0,
              }}>
                {it.t}
              </HandLabel>
              {/* "felt-tip" entry */}
              <div style={{
                fontFamily: NF.serif, fontSize: 20, color: N.cores[it.c],
                fontStyle: 'italic', fontWeight: 500, lineHeight: 1.1,
              }}>{it.word}.</div>
              <HandLabel size={14} color={N.muted} style={{ marginTop: 2 }}>
                {it.full} <span style={{ marginLeft: 4, color: N.pencil }}>
                  ({it.i}/5)
                </span>
              </HandLabel>
              {/* intensity tally — hand drawn tick marks */}
              <div style={{ marginTop: 4, display: 'flex', gap: 3 }}>
                {[1,2,3,4,5].map(n => (
                  <div key={n} style={{
                    width: 8, height: 14, borderLeft: `2px solid ${n <= it.i ? N.cores[it.c] : N.faint}`,
                    transform: `rotate(${(n - 3) * 4}deg)`,
                  }}/>
                ))}
              </div>
              {it.note && (
                <div style={{
                  marginTop: 6, fontFamily: NF.hand, fontSize: 17, color: N.ink2,
                  lineHeight: 1.4,
                }}>
                  ↳ {it.note}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* week sticker */}
        <div style={{ marginTop: 18 }}>
          <WashiTape color="rgba(173, 209, 230, 0.7)" text="this week · 9 check-ins · mostly happy"
            style={{ display: 'inline-block', transform: 'rotate(-1.5deg)' }}/>
        </div>
      </div>
      <NotebookTabs active="today"/>
    </NotebookPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 3 — Check-in entry (wheel as diagram with annotations)
// ─────────────────────────────────────────────────────────────
function NotebookCheckIn() {
  return (
    <NotebookPaper>
      <NGear/>
      <div style={{ position: 'absolute', top: 64, left: 60, right: 20 }}>
        <HandLabel size={16} color={N.muted}>step 2 of 4</HandLabel>
        <div style={{
          marginTop: 2, fontFamily: NF.serif, fontSize: 26, color: N.ink, fontStyle: 'italic',
        }}>How are you feeling?</div>
        <Underline w={220} color={N.ink}/>
      </div>

      {/* the wheel + hand-drawn annotations around it */}
      <div style={{ position: 'absolute', top: 170, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
        <div style={{ position: 'relative', width: 360, height: 340 }}>
          <NotebookWheel size={340}/>
          {/* annotations overlay */}
          <svg style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} viewBox="0 0 340 340">
            <DoodleArrow from={[20, 80]} to={[80, 70]} curve={-15} color={N.marginRed} label="5 families"/>
            <DoodleArrow from={[330, 70]} to={[256, 75]} curve={10} color={N.marginRed} label="tap inner"/>
            <DoodleArrow from={[10, 280]} to={[80, 245]} curve={20} color={N.marginRed} label="or stop here"/>
            <DoodleArrow from={[330, 280]} to={[270, 250]} curve={-20} color={N.marginRed} label="outer = specific"/>
          </svg>
        </div>
      </div>

      {/* selection readout */}
      <div style={{
        position: 'absolute', bottom: 168, left: 22, right: 22,
        padding: '12px 16px', background: N.paper,
        border: `1.5px dashed ${N.ink}`, borderRadius: 12,
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <span style={{
          padding: '2px 6px', background: N.hi.fearful,
          fontFamily: NF.hand, fontSize: 18, color: N.ink,
        }}>Fearful · Anxious</span>
        <span style={{ flex: 1 }}/>
        <button style={{
          padding: '8px 14px', background: N.ink, color: N.paper,
          border: 'none', borderRadius: 14, fontFamily: NF.hand, fontSize: 16,
        }}>save it ✓</button>
      </div>

      {/* mode picker — tabbed */}
      <div style={{
        position: 'absolute', bottom: 110, left: 22, right: 22,
        display: 'flex', gap: 6,
      }}>
        {['wheel', 'guided', 'quick'].map((m, i) => (
          <div key={m} style={{
            flex: 1, padding: '8px', textAlign: 'center',
            background: i === 0 ? N.paper : 'transparent',
            border: `1.5px solid ${i === 0 ? N.ink : N.faint}`,
            borderRadius: '14px 14px 0 0',
            fontFamily: NF.hand, fontSize: 18, color: i === 0 ? N.ink : N.muted,
          }}>{m}</div>
        ))}
      </div>
      <NotebookTabs active="checkIn"/>
    </NotebookPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 4 — Wizard (Body region) — diagram with notes
// ─────────────────────────────────────────────────────────────
function NotebookWizardStep() {
  return (
    <NotebookPaper>
      <div style={{ position: 'absolute', top: 60, left: 60, right: 20 }}>
        {/* progress tick marks */}
        <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
          {[0,1,2,3,4,5,6].map(i => (
            <div key={i} style={{
              flex: 1, height: 4, borderRadius: 2,
              background: i === 0 ? N.ink : N.faint,
            }}/>
          ))}
        </div>
        <HandLabel size={16} color={N.muted}>step 1 of 7 · optional</HandLabel>
        <div style={{
          marginTop: 2, fontFamily: NF.serif, fontSize: 24, color: N.ink, fontStyle: 'italic',
        }}>Where do you feel it?</div>
        <Underline w={210} color={N.ink}/>

        {/* body silhouette diagram with annotations */}
        <div style={{ marginTop: 14, position: 'relative', height: 320 }}>
          <svg width="100%" height="320" viewBox="0 0 240 320">
            {/* simplified body, slightly wobbly */}
            <path d="M120 14 a18 18 0 0 1 0 36 c11 0 18 6 20 16 l8 50 c0 8 -4 12 -8 14 v45 c0 6 4 10 8 10 v40 a6 6 0 0 1 -6 6 l-8 -2 v-40 q-14 8 -28 0 v40 l-8 2 a6 6 0 0 1 -6 -6 v-40 c4 0 8 -4 8 -10 v-45 c-4 -2 -8 -6 -8 -14 l8 -50 c2 -10 9 -16 20 -16 v-6"
              fill="none" stroke={N.ink} strokeWidth="1.4"/>
            {/* selected: chest */}
            <ellipse cx="120" cy="100" rx="22" ry="16" fill={N.hi.fearful} stroke={N.cores.fearful} strokeWidth="1.4"/>
            {/* hands */}
            <circle cx="60" cy="170" r="12" fill="none" stroke={N.ink} strokeWidth="1.2" strokeDasharray="2 3"/>
            <circle cx="180" cy="170" r="12" fill="none" stroke={N.ink} strokeWidth="1.2" strokeDasharray="2 3"/>
            <DoodleArrow from={[200, 90]} to={[148, 100]} curve={-15} color={N.marginRed} label="here ✓"/>
            <DoodleArrow from={[36, 200]} to={[58, 178]} curve={5} color={N.muted} label="maybe?"/>
          </svg>
        </div>

        {/* chip list */}
        <HandLabel size={16} color={N.muted}>or pick from a list ↓</HandLabel>
        <div style={{ marginTop: 6, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {['head','throat','chest ✓','stomach','shoulders','hands','back','legs','whole'].map(r => {
            const sel = r.includes('✓');
            return (
              <span key={r} style={{
                padding: '5px 10px',
                background: sel ? N.hi.fearful : 'transparent',
                border: `1.5px solid ${sel ? N.cores.fearful : N.faint}`,
                borderRadius: 14, fontFamily: NF.hand, fontSize: 17,
                color: sel ? N.ink : N.ink2,
              }}>{r}</span>
            );
          })}
        </div>
      </div>

      <div style={{
        position: 'absolute', bottom: 100, left: 22, right: 22,
        display: 'flex', gap: 10,
      }}>
        <button style={{
          padding: '12px 16px', border: `1.5px solid ${N.faint}`, borderRadius: 14,
          background: 'transparent', fontFamily: NF.hand, fontSize: 18, color: N.muted,
        }}>skip ↷</button>
        <button style={{
          flex: 1, padding: '12px 16px', border: `2px solid ${N.ink}`, borderRadius: 14,
          background: N.ink, color: N.paper, fontFamily: NF.hand, fontSize: 20,
          boxShadow: `3px 3px 0 ${N.marginRed}`,
        }}>next →</button>
      </div>
      <NotebookTabs active="checkIn"/>
    </NotebookPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 5 — Insights (hand-drawn chart spread)
// ─────────────────────────────────────────────────────────────
function NotebookInsights() {
  const tops = [
    { n: 'anxious', c: 'fearful', v: 8 },
    { n: 'peaceful', c: 'happy', v: 6 },
    { n: 'hopeful', c: 'happy', v: 3 },
    { n: 'disappointed', c: 'sad', v: 3 },
    { n: 'annoyed', c: 'angry', v: 2 },
  ];
  return (
    <NotebookPaper>
      <NGear/>
      <div style={{ position: 'absolute', top: 64, left: 60, right: 20, bottom: 88, overflow: 'hidden' }}>
        <HandLabel size={16} color={N.muted}>may · 27 readings</HandLabel>
        <div style={{
          marginTop: 2, fontFamily: NF.serif, fontSize: 28, color: N.ink, fontStyle: 'italic',
        }}>Notes on the month —</div>
        <Underline w={250} color={N.ink}/>

        {/* big number */}
        <div style={{ marginTop: 14, display: 'flex', alignItems: 'flex-end', gap: 10 }}>
          <div style={{
            fontFamily: NF.hand, fontSize: 80, color: N.cores.fearful,
            lineHeight: 0.8,
          }}>27</div>
          <HandLabel size={20} color={N.ink} style={{ marginBottom: 8 }}>
            check-ins.<br/>mostly anxious.
          </HandLabel>
        </div>

        {/* Hand-drawn bar chart */}
        <HandLabel size={16} color={N.marginRed} style={{ marginTop: 22 }}>
          ⌗ top words
        </HandLabel>
        <div style={{ marginTop: 8 }}>
          {tops.map((t, i) => (
            <div key={t.n} style={{
              display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0',
            }}>
              <div style={{
                width: 90, fontFamily: NF.hand, fontSize: 18, color: N.cores[t.c],
              }}>{t.n}</div>
              <div style={{
                flex: 1, height: 18, position: 'relative',
              }}>
                {/* hand-drawn bar — wavy outline */}
                <svg width="100%" height="20" viewBox={`0 0 200 20`} preserveAspectRatio="none">
                  <rect x="0" y="3" width={t.v / 8 * 200} height="14"
                    fill={N.hi[t.c]} stroke={N.cores[t.c]} strokeWidth="1.4"/>
                </svg>
              </div>
              <div style={{
                width: 24, textAlign: 'right',
                fontFamily: NF.hand, fontSize: 18, color: N.pencil,
              }}>×{t.v}</div>
            </div>
          ))}
        </div>

        {/* sparkline */}
        <HandLabel size={16} color={N.marginRed} style={{ marginTop: 14 }}>
          ⌗ intensity, last 14 days
        </HandLabel>
        <svg width="100%" height="70" viewBox="0 0 280 70" style={{ marginTop: 6 }}>
          {/* graph paper grid */}
          {[0, 20, 40, 60].map(y => (
            <line key={y} x1="0" y1={y} x2="280" y2={y} stroke={N.ruleBlue} strokeWidth="0.5" opacity="0.5"/>
          ))}
          <polyline points={[3,2,4,5,3,4,2,3,5,4,3,2,4,3].map((d, i) => `${(i / 13) * 270 + 5},${68 - (d - 1) * 14}`).join(' ')}
            stroke={N.cores.fearful} strokeWidth="2" fill="none" strokeLinejoin="round" strokeLinecap="round"/>
          {[3,2,4,5,3,4,2,3,5,4,3,2,4,3].map((d, i) => (
            <circle key={i} cx={(i / 13) * 270 + 5} cy={68 - (d - 1) * 14} r="3"
              fill={N.cores.fearful} stroke={N.paper} strokeWidth="1.5"/>
          ))}
        </svg>

        {/* margin note */}
        <div style={{ marginTop: 12, position: 'relative' }}>
          <HandLabel size={17} color={N.marginRed} style={{
            position: 'absolute', left: -50, top: 0,
          }}>note —</HandLabel>
          <HandLabel size={17} color={N.ink}>
            mornings get harder.<br/>walks make it better.
          </HandLabel>
        </div>
      </div>
      <NotebookTabs active="insights"/>
    </NotebookPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 6 — History (older pages, dog-eared)
// ─────────────────────────────────────────────────────────────
function NotebookHistory() {
  return (
    <NotebookPaper>
      <div style={{ position: 'absolute', top: 60, left: 60, right: 20, bottom: 88, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <button style={{
            background: 'transparent', border: 'none', padding: 0, color: N.ink,
            fontFamily: NF.hand, fontSize: 22, marginLeft: -8,
          }}>←</button>
          <HandLabel size={16} color={N.muted}>back to today</HandLabel>
        </div>
        <div style={{
          marginTop: 2, fontFamily: NF.serif, fontSize: 28, color: N.ink, fontStyle: 'italic',
        }}>Earlier pages —</div>
        <Underline w={200} color={N.ink}/>

        {/* filter chips */}
        <div style={{ marginTop: 12, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {['all', 'happy', 'sad', 'angry', 'fearful', 'disgusted'].map((c, i) => (
            <span key={c} style={{
              padding: '3px 9px',
              background: i === 0 ? N.ink : 'transparent',
              color: i === 0 ? N.paper : N.ink,
              border: `1.5px solid ${N.ink}`, borderRadius: 14,
              fontFamily: NF.hand, fontSize: 15,
            }}>{c}</span>
          ))}
        </div>

        {[
          { d: 'thursday · today', items: [
            { t: '12:38p', w: 'thankful', s: 'Happy · Peaceful', i: 3, c: 'happy' },
            { t: '9:14a', w: 'overwhelmed', s: 'Fearful · Anxious', i: 4, note: 'big presentation in an hour. hands cold.', c: 'fearful' },
          ]},
          { d: 'wednesday', items: [
            { t: '8:02p', w: 'disappointed', s: 'Sad · Hurt', i: 3, c: 'sad' },
            { t: '4:15p', w: 'confident', s: 'Happy · Proud', i: 4, c: 'happy', note: 'finished the deck.' },
          ]},
          { d: 'tuesday, 26 may', items: [
            { t: '6:30p', w: 'annoyed', s: 'Angry · Frustrated', i: 3, c: 'angry' },
          ]},
        ].map(g => (
          <div key={g.d} style={{ marginTop: 18 }}>
            <HandLabel size={17} color={N.marginRed}>{g.d}.</HandLabel>
            <div style={{ marginTop: 6 }}>
              {g.items.map((it, i) => (
                <div key={i} style={{
                  display: 'flex', gap: 12, padding: '8px 0',
                  borderBottom: `1px dashed ${N.faint}`,
                  position: 'relative',
                }}>
                  <HandLabel size={14} color={N.pencil} style={{ width: 50, paddingTop: 2 }}>{it.t}</HandLabel>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                      <span style={{
                        fontFamily: NF.serif, fontSize: 18, fontStyle: 'italic',
                        color: N.cores[it.c], fontWeight: 500,
                      }}>{it.w}.</span>
                      <span style={{ fontFamily: NF.hand, fontSize: 14, color: N.pencil }}>
                        ({it.s} · {it.i}/5)
                      </span>
                    </div>
                    {it.note && (
                      <HandLabel size={16} color={N.ink2} style={{ marginTop: 2 }}>
                        ↳ {it.note}
                      </HandLabel>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      <NotebookTabs active="today"/>
    </NotebookPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 7 — Direction
// ─────────────────────────────────────────────────────────────
function NotebookDirection() {
  return (
    <NotebookPaper>
      <NGear/>
      <div style={{ position: 'absolute', top: 64, left: 60, right: 20, bottom: 88, overflow: 'hidden' }}>
        <HandLabel size={16} color={N.muted}>thu · 28 may</HandLabel>
        <div style={{
          marginTop: 2, fontFamily: NF.serif, fontSize: 28, color: N.ink, fontStyle: 'italic',
        }}>Direction.</div>
        <Underline w={130} color={N.ink}/>

        {/* tabs feel like dividers */}
        <div style={{
          marginTop: 14, display: 'flex', gap: 6,
        }}>
          {['intention ✓', 'values', 'actions'].map((m, i) => (
            <div key={m} style={{
              flex: 1, padding: '6px 10px', textAlign: 'center',
              border: `1.5px solid ${i === 0 ? N.ink : N.faint}`,
              borderRadius: '14px 14px 0 0',
              background: i === 0 ? N.paper : 'transparent',
              fontFamily: NF.hand, fontSize: 17, color: i === 0 ? N.ink : N.muted,
            }}>{m}</div>
          ))}
        </div>

        {/* today's intention as highlighted */}
        <div style={{
          marginTop: 0, padding: '16px 18px', borderTop: 'none',
          border: `1.5px solid ${N.ink}`,
        }}>
          <HandLabel size={15} color={N.muted}>today —</HandLabel>
          <div style={{
            marginTop: 4, fontFamily: NF.hand, fontSize: 24, color: N.ink, lineHeight: 1.3,
          }}>
            <span style={{ background: N.highlight, padding: '2px 6px',
              boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone' }}>
              "Be slower with replies. Listen first."
            </span>
          </div>
          <div style={{ marginTop: 14, display: 'flex', gap: 6, alignItems: 'center' }}>
            <HandLabel size={14} color={N.muted}>how did it go?</HandLabel>
            <span style={{ flex: 1 }}/>
            {['hard', 'ok ✓', 'yes!'].map(l => (
              <span key={l} style={{
                padding: '4px 10px',
                background: l.includes('✓') ? N.ink : 'transparent',
                color: l.includes('✓') ? N.paper : N.ink,
                border: `1.5px solid ${N.ink}`, borderRadius: 14,
                fontFamily: NF.hand, fontSize: 15,
              }}>{l}</span>
            ))}
          </div>
        </div>

        {/* This week's intentions — checklist */}
        <HandLabel size={18} color={N.marginRed} style={{ marginTop: 22 }}>
          ⌗ this week's list
        </HandLabel>
        <div style={{ marginTop: 6 }}>
          {[
            { d: 'wed', t: 'eat lunch away from the desk', r: '⌬' },
            { d: 'tue', t: "notice when I'm holding my breath", r: '✓' },
            { d: 'mon', t: 'send the message I keep avoiding', r: '✗' },
            { d: 'sun', t: 'no phone before coffee', r: '✓' },
          ].map((p, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0',
              borderBottom: `1px dashed ${N.faint}`,
            }}>
              <span style={{
                width: 22, height: 22, border: `1.5px solid ${N.ink}`, borderRadius: 4,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: NF.hand, fontSize: 17,
                color: p.r === '✓' ? N.cores.disgusted : p.r === '✗' ? N.cores.angry : N.muted,
              }}>{p.r}</span>
              <HandLabel size={15} color={N.muted} style={{ width: 36 }}>{p.d}.</HandLabel>
              <div style={{
                flex: 1, fontFamily: NF.serif, fontSize: 15, color: N.ink, fontStyle: 'italic',
              }}>{p.t}</div>
            </div>
          ))}
        </div>
      </div>
      <NotebookTabs active="direction"/>
    </NotebookPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 8 — Settings (folded insert)
// ─────────────────────────────────────────────────────────────
function NotebookSettings() {
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'rgba(31,44,58,0.45)', overflow: 'hidden' }}>
      <NotebookPaper>
        <div style={{ opacity: 0.4 }}>
          <HandLabel size={28} color={N.ink} style={{ position: 'absolute', top: 84, left: 60 }}>
            Today,
          </HandLabel>
        </div>
      </NotebookPaper>
      <div style={{
        position: 'absolute', top: 56, left: 0, right: 0, bottom: 0,
        background: N.paper,
        borderTop: `2px solid ${N.ink}`,
        boxShadow: '0 -10px 30px rgba(31,44,58,0.18)',
        overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '8px 0 4px' }}>
          <div style={{ width: 48, height: 4, background: N.ink, borderRadius: 2 }}/>
        </div>
        <div style={{ padding: '4px 22px 8px', display: 'flex', alignItems: 'center' }}>
          <div style={{
            flex: 1, fontFamily: NF.serif, fontSize: 24, color: N.ink, fontStyle: 'italic',
          }}>Settings.</div>
          <button style={{
            padding: '4px 12px', background: N.ink, color: N.paper,
            border: 'none', borderRadius: 12, fontFamily: NF.hand, fontSize: 17,
          }}>done ✓</button>
        </div>
        <div style={{
          padding: '8px 22px 0',
        }}>
          <Underline w={300} color={N.ink}/>
        </div>

        <div style={{ padding: '12px 22px', overflow: 'auto', maxHeight: 'calc(100% - 80px)' }}>
          {[
            { h: 'you', rows: [
              { l: 'your name', d: 'Taylor' },
              { l: 'appearance', d: 'auto' },
            ]},
            { h: 'check-in', rows: [
              { l: 'default mode', d: 'wheel' },
              { l: 'body region first', toggle: true, on: true },
              { l: 'show clinical notes', toggle: true, on: true },
            ]},
            { h: 'privacy', rows: [
              { l: 'iCloud sync', d: '✓ 2m ago', good: true },
              { l: 'Face ID lock', toggle: true, on: true },
              { l: 'Apple Health write', toggle: true, on: false },
            ]},
            { h: 'export', rows: [
              { l: 'local backup', d: '' },
              { l: 'CSV / JSON', d: '' },
              { l: 'therapy PDF', d: '' },
            ]},
            { h: 'tip jar', rows: [
              { l: '🥤 soda', d: '$1.99', donate: true },
              { l: '🥪 lunch', d: '$4.99', donate: true },
              { l: '🍝 dinner', d: '$9.99', donate: true },
            ]},
          ].map((sec, si) => (
            <div key={sec.h} style={{ marginBottom: 14 }}>
              <HandLabel size={18} color={N.marginRed}>⌗ {sec.h}.</HandLabel>
              <div style={{ marginTop: 4 }}>
                {sec.rows.map((r, i) => (
                  <div key={i} style={{
                    display: 'flex', alignItems: 'center', padding: '10px 0',
                    borderBottom: i < sec.rows.length - 1 ? `1px dashed ${N.faint}` : 'none',
                  }}>
                    <div style={{
                      flex: 1, fontFamily: NF.serif, fontSize: 16, color: N.ink, fontStyle: 'italic',
                    }}>{r.l}</div>
                    {r.d && (
                      <div style={{
                        marginRight: 10, fontFamily: NF.hand, fontSize: 16,
                        color: r.good ? N.cores.disgusted : N.pencil,
                      }}>{r.d}</div>
                    )}
                    {r.toggle && (
                      <div style={{
                        width: 38, height: 22, border: `1.5px solid ${N.ink}`, borderRadius: 11,
                        background: r.on ? N.ink : N.paper,
                        display: 'flex', padding: 1,
                        justifyContent: r.on ? 'flex-end' : 'flex-start',
                      }}>
                        <div style={{ width: 16, height: 16, borderRadius: 8, background: r.on ? N.paper : N.ink }}/>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
          <div style={{ textAlign: 'center', padding: '14px 0 30px' }}>
            <HandLabel size={16} color={N.muted}>
              ★ free + open source ★<br/>
              <span style={{ fontFamily: NF.mono, fontSize: 11 }}>v1.4 · MIT</span>
            </HandLabel>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  NotebookOnboarding, NotebookToday, NotebookCheckIn, NotebookWizardStep,
  NotebookInsights, NotebookHistory, NotebookDirection, NotebookSettings,
  NotebookWheel,
});
