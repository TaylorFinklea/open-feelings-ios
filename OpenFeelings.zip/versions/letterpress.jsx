// V2 — LETTERPRESS
// Paper-family refinement, riso/woodcut aesthetic. Two-color limited palette
// (cream + ink + ONE accent per spread). Chunky type, stamped buttons,
// hand-cut woodblock wheel, book section dividers with dingbats.
// Exports L* screens to window.

const L = {
  paper:   '#F2EAD3',   // raw cream
  paper2:  '#E8DFC4',
  ink:     '#1D1611',
  ink2:    '#2E251D',
  muted:   '#7C7160',
  faint:   '#A89A82',
  rule:    '#1D1611',
  divider: '#C7BB9A',
  // Each row pairs cream + ink + ONE color. The accent on Today shifts to the
  // dominant feeling (riso 2nd-pass spot color).
  vermilion: '#C24820',
  teal:      '#21576A',
  ochre:     '#A77A1A',
  plum:      '#6B345C',
  moss:      '#3E5A30',
  cores: {
    happy:     '#A77A1A',
    sad:       '#21576A',
    angry:     '#C24820',
    fearful:   '#6B345C',
    disgusted: '#3E5A30',
  },
};
const LF = {
  display: '"Fraunces", "Source Serif 4", "Iowan Old Style", Georgia, serif',
  sans:    '"IBM Plex Sans", -apple-system, system-ui, sans-serif',
  mono:    '"IBM Plex Mono", ui-monospace, "SF Mono", monospace',
  sc:      '"Spectral SC", "Source Serif 4", Georgia, serif',
};

// ─────────────────────────────────────────────────────────────
// Paper ground with subtle riso speckle and ink-spread vignette
// ─────────────────────────────────────────────────────────────
function LPaper({ children, bg = L.paper }) {
  return (
    <div style={{ position: 'absolute', inset: 0, background: bg, overflow: 'hidden' }}>
      {/* paper grain — a static SVG noise pattern as background overlay */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.18, mixBlendMode: 'multiply' }}>
        <filter id="noise-l">
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed="3"/>
          <feColorMatrix values="0 0 0 0 0.11  0 0 0 0 0.085  0 0 0 0 0.067  0 0 0 0.08 0"/>
        </filter>
        <rect width="100%" height="100%" filter="url(#noise-l)"/>
      </svg>
      {/* tiny ink dots scattered (riso misregistration feel) */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.4 }}>
        {Array.from({ length: 22 }).map((_, i) => {
          const x = ((Math.sin(i * 7.1) + 1) / 2) * 100;
          const y = ((Math.cos(i * 4.9) + 1) / 2) * 100;
          return <circle key={i} cx={`${x}%`} cy={`${y}%`} r={Math.random() > 0.7 ? 0.6 : 0.35} fill={L.ink} opacity={0.5}/>;
        })}
      </svg>
      {children}
    </div>
  );
}

// Ink-stamp wash — a riso second-pass blob behind something
function InkStamp({ color, style }) {
  return (
    <div style={{
      position: 'absolute', borderRadius: '50%',
      background: color, filter: 'blur(20px)', opacity: 0.4, ...style,
    }}/>
  );
}

// ─────────────────────────────────────────────────────────────
// Letterpress wheel — fat woodblock, cross-hatched, 2-color
// ─────────────────────────────────────────────────────────────
function LetterpressWheel({ size = 320, focus = 'fearful', accent = L.vermilion }) {
  const cx = size / 2, cy = size / 2;
  const cores = WHEEL_DATA;
  const n = cores.length;
  const sliceA = 360 / n;
  const polar = (r, deg) => {
    const a = (deg - 90) * Math.PI / 180;
    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
  };
  const sectorPath = (rIn, rOut, a0, a1) => {
    const [x1, y1] = polar(rOut, a0), [x2, y2] = polar(rOut, a1);
    const [x3, y3] = polar(rIn, a1),  [x4, y4] = polar(rIn, a0);
    const large = a1 - a0 > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${rOut} ${rOut} 0 ${large} 1 ${x2} ${y2} L ${x3} ${y3} A ${rIn} ${rIn} 0 ${large} 0 ${x4} ${y4} Z`;
  };
  const rHub = size * 0.13;
  const rCore = size * 0.30;
  const rSec = size * 0.46;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        {/* hatching patterns at different orientations per family */}
        {cores.map((c, ci) => {
          const angle = (ci * 36) % 90 + 25;
          return (
            <pattern key={c.id} id={`hatch-${c.id}`} x="0" y="0" width="6" height="6"
              patternUnits="userSpaceOnUse" patternTransform={`rotate(${angle})`}>
              <line x1="0" y1="0" x2="0" y2="6" stroke={L.ink} strokeWidth="2.2"/>
            </pattern>
          );
        })}
        <pattern id="hatch-accent" x="0" y="0" width="5" height="5"
          patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1="0" y1="0" x2="0" y2="5" stroke={accent} strokeWidth="2"/>
        </pattern>
      </defs>

      {/* heavy outer ring (the wood block edge) */}
      <circle cx={cx} cy={cy} r={(size / 2) - 1} fill={L.paper} stroke={L.ink} strokeWidth="3.5"/>

      {/* SECONDARY ring — hatched */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceA;
        return c.secondaries.map((s, si) => {
          const w = sliceA / c.secondaries.length;
          const a0 = baseA + si * w;
          const a1 = a0 + w;
          const isFocusSlice = c.id === focus;
          return (
            <path key={`s-${c.id}-${si}`}
              d={sectorPath(rCore, rSec, a0, a1)}
              fill={isFocusSlice ? `url(#hatch-${c.id})` : L.paper}
              stroke={L.ink} strokeWidth="1.4"/>
          );
        });
      })}

      {/* CORE ring — solid ink wedges */}
      {cores.map((c, ci) => {
        const a0 = ci * sliceA, a1 = a0 + sliceA;
        const isFocus = c.id === focus;
        return (
          <path key={`c-${c.id}`}
            d={sectorPath(rHub, rCore, a0, a1)}
            fill={isFocus ? accent : L.ink}
            stroke={L.ink} strokeWidth="2"/>
        );
      })}

      {/* SECONDARY labels */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceA;
        return c.secondaries.map((s, si) => {
          const w = sliceA / c.secondaries.length;
          const aMid = baseA + si * w + w / 2;
          const [lx, ly] = polar((rCore + rSec) / 2, aMid);
          return (
            <text key={`sl-${c.id}-${si}`} x={lx} y={ly + 2}
              textAnchor="middle" dominantBaseline="middle"
              fontFamily={LF.sans} fontSize={size * 0.026} fontWeight="700"
              fill={L.ink}
              style={{ letterSpacing: 0.6, textTransform: 'uppercase', mixBlendMode: 'multiply' }}>
              {s.name}
            </text>
          );
        });
      })}

      {/* CORE labels — chunky italic in cream */}
      {cores.map((c, ci) => {
        const aMid = ci * sliceA + sliceA / 2;
        const [lx, ly] = polar((rHub + rCore) / 2, aMid);
        return (
          <text key={`l-${c.id}`} x={lx} y={ly + 2}
            textAnchor="middle" dominantBaseline="middle"
            fontFamily={LF.display} fontSize={size * 0.052}
            fontWeight="800" fontStyle="italic"
            fill={L.paper}
            style={{ letterSpacing: 0.2 }}>{c.name}</text>
        );
      })}

      {/* HUB — solid ink medallion with ornament */}
      <circle cx={cx} cy={cy} r={rHub} fill={L.ink}/>
      <text x={cx} y={cy + 2} textAnchor="middle" dominantBaseline="middle"
        fontFamily={LF.display} fontStyle="italic" fontSize={rHub * 0.55}
        fill={L.paper}>❦</text>

      {/* slight register-shift on accent (riso vibe) */}
      <g transform="translate(1.5 0.8)" opacity="0.35">
        <circle cx={cx} cy={cy} r={rHub} fill="none" stroke={accent} strokeWidth="1"/>
      </g>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Letterpress tab bar — flat ink, no chrome blur, dingbat icons
// ─────────────────────────────────────────────────────────────
function LetterpressTabs({ active, accent = L.ink }) {
  return (
    <TabBar
      tabs={tabsForActive(active, accent)}
      active={active}
      bg={L.paper2} fg={L.ink}
      muted={L.muted} accent={accent}
      border={L.ink} blur={false}
    />
  );
}

// Small caps eyebrow with rule
const LRule = ({ children, accent = L.ink }) => (
  <div style={{
    display: 'flex', alignItems: 'center', gap: 10,
    fontFamily: LF.sc, fontSize: 11, color: accent,
    letterSpacing: 3, fontWeight: 600,
  }}>
    {children}
  </div>
);

// Section divider (chapter break)
const LBreak = ({ dingbat = '* * *', color = L.ink }) => (
  <div style={{
    margin: '18px 0', display: 'flex', justifyContent: 'center',
    fontFamily: LF.display, fontSize: 18, color, letterSpacing: 6, opacity: 0.7,
  }}>{dingbat}</div>
);

// Ink-stamped button
const LStamp = ({ children, color = L.ink, inverse = false, style }) => (
  <button style={{
    padding: '14px 22px', borderRadius: 0,
    background: inverse ? color : L.paper, color: inverse ? L.paper : color,
    border: `2px solid ${color}`,
    fontFamily: LF.display, fontSize: 16, fontStyle: 'italic', fontWeight: 700,
    letterSpacing: 0.3,
    boxShadow: `3px 3px 0 ${color}`,
    cursor: 'pointer',
    ...style,
  }}>{children}</button>
);

const LGear = ({ color = L.ink }) => (
  <button style={{
    position: 'absolute', top: 64, right: 18, zIndex: 6,
    width: 38, height: 38, borderRadius: 0,
    border: `2px solid ${color}`, background: L.paper, color,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    boxShadow: `2px 2px 0 ${color}`,
  }}>{Icons.gear(color, 1.8)}</button>
);

// Heading with rules above/below (book-page style)
const LBookHead = ({ chapter, title, accent = L.ink }) => (
  <div style={{ textAlign: 'center', padding: '4px 0' }}>
    <div style={{ height: 2, background: accent, marginBottom: 8 }}/>
    <div style={{
      fontFamily: LF.sc, fontSize: 11, color: accent,
      letterSpacing: 5, fontWeight: 600,
    }}>{chapter}</div>
    <div style={{
      marginTop: 2, fontFamily: LF.display, fontSize: 36,
      fontStyle: 'italic', fontWeight: 700, color: L.ink, letterSpacing: -0.5,
      lineHeight: 1.0,
    }}>{title}</div>
    <div style={{ height: 0.5, background: accent, marginTop: 8 }}/>
  </div>
);

// ─────────────────────────────────────────────────────────────
// SCREEN 1 — Onboarding (riso poster)
// ─────────────────────────────────────────────────────────────
function LetterpressOnboarding() {
  return (
    <LPaper>
      {/* riso color swatch behind wheel */}
      <InkStamp color={L.vermilion} style={{ top: 100, left: 50, width: 280, height: 280 }}/>

      <div style={{ position: 'absolute', top: 70, left: 24, right: 24 }}>
        <LRule><span>OPEN&nbsp;·&nbsp;FEELINGS</span><div style={{ flex: 1, height: 1, background: L.ink }}/><span>EDITION&nbsp;ONE</span></LRule>
      </div>

      <div style={{ position: 'absolute', top: 138, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
        <LetterpressWheel size={300} focus="fearful" accent={L.vermilion}/>
      </div>

      <div style={{ position: 'absolute', top: 470, left: 26, right: 26, textAlign: 'center' }}>
        <div style={{
          fontFamily: LF.display, fontSize: 50, fontWeight: 800, fontStyle: 'italic',
          color: L.ink, letterSpacing: -1.5, lineHeight: 0.95,
        }}>
          Name<br/>what is.
        </div>
        <div style={{
          marginTop: 18, fontFamily: LF.display, fontSize: 16,
          fontStyle: 'italic', color: L.ink2, lineHeight: 1.5,
        }}>
          A small private place to set down<br/>
          how you feel, and read it later.
        </div>
      </div>

      <div style={{ position: 'absolute', bottom: 60, left: 26, right: 26 }}>
        <LStamp inverse color={L.ink} style={{ width: '100%', padding: '16px' }}>
          BEGIN ✦
        </LStamp>
        <div style={{
          marginTop: 14, textAlign: 'center', fontFamily: LF.sc, fontSize: 10,
          color: L.muted, letterSpacing: 3, fontWeight: 600,
        }}>STAYS ON YOUR PHONE · FREE · OPEN SOURCE</div>
      </div>
    </LPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 2 — Today (book opened to today's page)
// ─────────────────────────────────────────────────────────────
function LetterpressToday() {
  const accent = L.cores.fearful;
  return (
    <LPaper>
      <LGear/>
      <InkStamp color={accent} style={{ top: -40, right: -40, width: 180, height: 180, opacity: 0.18 }}/>

      <div style={{ position: 'absolute', top: 68, left: 22, right: 22, bottom: 88, overflow: 'hidden' }}>
        <LBookHead chapter="THURSDAY · 28 MAY · CHAPTER LXXIV" title="Today" accent={L.ink}/>

        {/* intention */}
        <div style={{ marginTop: 14 }}>
          <div style={{
            fontFamily: LF.sc, fontSize: 10, color: L.muted,
            letterSpacing: 3, fontWeight: 600, textAlign: 'center',
          }}>§ 1 — THE INTENTION</div>
          <div style={{
            marginTop: 6, padding: '14px 18px',
            background: L.paper2, border: `2px solid ${L.ink}`,
            boxShadow: `3px 3px 0 ${L.ink}`,
            position: 'relative',
          }}>
            <div style={{
              fontFamily: LF.display, fontStyle: 'italic', fontSize: 18,
              color: L.ink, lineHeight: 1.35, fontWeight: 600,
            }}>
              "Be slower with replies. Listen first."
            </div>
            <div style={{
              position: 'absolute', top: 10, right: 12,
              fontFamily: LF.sc, fontSize: 9, color: L.muted, letterSpacing: 2,
            }}>EDIT</div>
          </div>
        </div>

        <LBreak dingbat="❦"/>

        {/* the day's entries */}
        <div style={{
          fontFamily: LF.sc, fontSize: 10, color: L.muted,
          letterSpacing: 3, fontWeight: 600, textAlign: 'center',
        }}>§ 2 — THE DAY'S READINGS · TWO ENTRIES</div>

        <div style={{ marginTop: 12 }}>
          {[
            { t: '9:14', word: 'Anxious', full: 'Fearful · Anxious · Overwhelmed', i: 4, note: 'Big presentation in an hour. Hands cold.', c: 'fearful' },
            { t: '12:38', word: 'Thankful', full: 'Happy · Peaceful · Thankful', i: 3, c: 'happy' },
          ].map((it, i) => (
            <div key={i} style={{
              display: 'flex', gap: 14, paddingBottom: 12, marginBottom: 12,
              borderBottom: `1px dashed ${L.ink}`,
            }}>
              <div style={{ width: 50, paddingTop: 4 }}>
                <div style={{
                  fontFamily: LF.mono, fontSize: 12, color: L.ink, fontWeight: 700,
                  letterSpacing: 0.5,
                }}>{it.t}</div>
                <div style={{
                  marginTop: 6, display: 'flex', flexDirection: 'column', gap: 2,
                }}>
                  {[1,2,3,4,5].map(n => (
                    <span key={n} style={{
                      width: 14, height: 3,
                      background: n <= it.i ? L.cores[it.c] : 'transparent',
                      border: `0.5px solid ${L.cores[it.c]}`,
                    }}/>
                  ))}
                </div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{
                  fontFamily: LF.display, fontStyle: 'italic', fontWeight: 700,
                  fontSize: 28, color: L.cores[it.c], letterSpacing: -0.5, lineHeight: 1,
                }}>{it.word}.</div>
                <div style={{
                  marginTop: 4, fontFamily: LF.sc, fontSize: 10, color: L.muted,
                  letterSpacing: 2, fontWeight: 600,
                }}>{it.full}</div>
                {it.note && (
                  <div style={{
                    marginTop: 8, fontFamily: LF.display, fontStyle: 'italic',
                    fontSize: 14, color: L.ink2, lineHeight: 1.4,
                  }}>"{it.note}"</div>
                )}
              </div>
            </div>
          ))}
        </div>

        <LStamp color={L.ink} style={{ width: '100%', marginTop: 4, padding: '12px', fontSize: 14 }}>
          ✦ &nbsp; SET DOWN ANOTHER &nbsp; ✦
        </LStamp>
      </div>
      <LetterpressTabs active="today" accent={L.ink}/>
    </LPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 3 — Check-in entry (the woodcut wheel)
// ─────────────────────────────────────────────────────────────
function LetterpressCheckIn() {
  return (
    <LPaper>
      <LGear/>
      <InkStamp color={L.vermilion} style={{ top: 130, left: 30, width: 320, height: 320, opacity: 0.16 }}/>

      <div style={{ position: 'absolute', top: 68, left: 22, right: 22 }}>
        <LRule><span>STEP 02 OF 04</span><div style={{ flex: 1, height: 1, background: L.ink }}/><span>NAME IT</span></LRule>
        <div style={{
          marginTop: 12, fontFamily: LF.display, fontSize: 36,
          fontWeight: 700, fontStyle: 'italic', color: L.ink,
          letterSpacing: -0.5, lineHeight: 1.0,
        }}>What is it?</div>
      </div>

      <div style={{
        position: 'absolute', top: 195, left: 0, right: 0,
        display: 'flex', justifyContent: 'center',
      }}>
        <LetterpressWheel size={340} focus="fearful" accent={L.vermilion}/>
      </div>

      {/* readout */}
      <div style={{
        position: 'absolute', bottom: 168, left: 22, right: 22,
        padding: '12px 16px', background: L.paper2,
        border: `2px solid ${L.ink}`, boxShadow: `3px 3px 0 ${L.ink}`,
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <div style={{ flex: 1 }}>
          <div style={{
            fontFamily: LF.sc, fontSize: 10, color: L.muted,
            letterSpacing: 2.5, fontWeight: 600,
          }}>YOUR PICK</div>
          <div style={{
            marginTop: 4, fontFamily: LF.display, fontSize: 22,
            fontStyle: 'italic', fontWeight: 700, color: L.vermilion,
            letterSpacing: -0.3, lineHeight: 1,
          }}>Fearful → Anxious</div>
        </div>
        <LStamp color={L.vermilion} inverse style={{ padding: '10px 14px', fontSize: 13 }}>SAVE</LStamp>
      </div>

      {/* mode picker */}
      <div style={{
        position: 'absolute', bottom: 108, left: 22, right: 22,
        display: 'flex', border: `2px solid ${L.ink}`,
      }}>
        {['Wheel', 'Guided', 'Quick'].map((m, i) => (
          <button key={m} style={{
            flex: 1, padding: '10px', border: 'none',
            borderRight: i < 2 ? `2px solid ${L.ink}` : 'none',
            background: i === 0 ? L.ink : L.paper,
            color: i === 0 ? L.paper : L.ink,
            fontFamily: LF.sc, fontSize: 11, fontWeight: 600, letterSpacing: 2,
          }}>{m.toUpperCase()}</button>
        ))}
      </div>
      <LetterpressTabs active="checkIn" accent={L.ink}/>
    </LPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 4 — Wizard step (Strength) — chunky stamps
// ─────────────────────────────────────────────────────────────
function LetterpressWizardStep() {
  const accent = L.cores.fearful;
  return (
    <LPaper>
      <div style={{ position: 'absolute', top: 64, left: 22, right: 22 }}>
        {/* progress as ink dots */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginBottom: 12 }}>
          {[0,1,2,3,4,5,6].map(i => (
            <span key={i} style={{
              width: 12, height: 12, borderRadius: '50%',
              background: i <= 2 ? L.ink : L.paper,
              border: `2px solid ${L.ink}`,
            }}/>
          ))}
        </div>
        <LRule><span>STEP 03 OF 07</span><div style={{ flex: 1, height: 1, background: L.ink }}/><span>OPTIONAL</span></LRule>
        <div style={{
          marginTop: 8, fontFamily: LF.display, fontSize: 32,
          fontWeight: 700, fontStyle: 'italic', color: L.ink,
          letterSpacing: -0.5, lineHeight: 1.0,
        }}>How strong?</div>

        {/* selected feeling stamp */}
        <div style={{
          marginTop: 16, display: 'inline-block', padding: '6px 14px',
          background: accent, color: L.paper,
          border: `2px solid ${L.ink}`, boxShadow: `2px 2px 0 ${L.ink}`,
          fontFamily: LF.display, fontSize: 14, fontStyle: 'italic', fontWeight: 700,
        }}>
          Fearful · Anxious
        </div>

        {/* 5 numbered stamp tiles */}
        <div style={{
          marginTop: 30, display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8,
        }}>
          {[1,2,3,4,5].map(n => {
            const sel = n === 4;
            return (
              <div key={n} style={{
                padding: '14px 0', textAlign: 'center',
                background: sel ? accent : L.paper,
                color: sel ? L.paper : L.ink,
                border: `2px solid ${L.ink}`,
                boxShadow: sel ? `3px 3px 0 ${L.ink}` : 'none',
                transform: sel ? 'translate(-1px, -1px)' : 'none',
              }}>
                <div style={{
                  fontFamily: LF.display, fontSize: 26, fontWeight: 800, fontStyle: 'italic',
                  lineHeight: 1,
                }}>{n}</div>
                <div style={{
                  marginTop: 2, fontFamily: LF.sc, fontSize: 8, letterSpacing: 1.5, fontWeight: 600,
                  opacity: 0.7,
                }}>{['BARELY','MILD','SOME','STRONG','MOST'][n-1]}</div>
              </div>
            );
          })}
        </div>

        {/* note about the feeling */}
        <LBreak dingbat="❧ ❦ ❧"/>

        <div style={{
          padding: '14px 18px', background: L.paper2,
          border: `2px solid ${accent}`, position: 'relative',
        }}>
          <div style={{
            fontFamily: LF.sc, fontSize: 10, color: accent,
            letterSpacing: 2.5, fontWeight: 600,
          }}>NOTE ON ANXIOUS</div>
          <div style={{
            marginTop: 6, fontFamily: LF.display, fontStyle: 'italic',
            fontSize: 15, color: L.ink, lineHeight: 1.45,
          }}>
            A future-facing unease, often paired with bodily activation —
            tight chest, restless thoughts. Common; treatable.
          </div>
        </div>
      </div>

      <div style={{
        position: 'absolute', bottom: 100, left: 22, right: 22,
        display: 'flex', gap: 10,
      }}>
        <LStamp color={L.ink} style={{ padding: '12px 18px', fontSize: 14 }}>← BACK</LStamp>
        <LStamp inverse color={L.ink} style={{ flex: 1, padding: '12px 18px', fontSize: 14 }}>NEXT →</LStamp>
      </div>
      <LetterpressTabs active="checkIn" accent={L.ink}/>
    </LPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 5 — Insights (broadside chart)
// ─────────────────────────────────────────────────────────────
function LetterpressInsights() {
  return (
    <LPaper>
      <LGear/>
      <div style={{ position: 'absolute', top: 70, left: 22, right: 22, bottom: 88, overflow: 'hidden' }}>
        <LBookHead chapter="MAY · TWENTY-SEVEN READINGS" title="Insights" accent={L.ink}/>

        {/* headline number */}
        <div style={{ marginTop: 16, textAlign: 'center' }}>
          <div style={{
            fontFamily: LF.display, fontSize: 100, fontWeight: 800, fontStyle: 'italic',
            color: L.vermilion, letterSpacing: -3, lineHeight: 0.9,
          }}>27</div>
          <div style={{
            fontFamily: LF.sc, fontSize: 11, color: L.ink,
            letterSpacing: 3, fontWeight: 600, marginTop: 2,
          }}>CHECK-INS · MOSTLY FEARFUL</div>
        </div>

        <LBreak dingbat="* * *"/>

        {/* By family — woodcut bars */}
        <div style={{ fontFamily: LF.sc, fontSize: 10, color: L.muted, letterSpacing: 3, fontWeight: 600 }}>§ BY FAMILY</div>
        <div style={{ marginTop: 10 }}>
          {[
            { n: 'Fearful', c: 'fearful', v: 11, p: 40 },
            { n: 'Happy', c: 'happy', v: 9, p: 33 },
            { n: 'Sad', c: 'sad', v: 4, p: 15 },
            { n: 'Angry', c: 'angry', v: 2, p: 8 },
            { n: 'Disgusted', c: 'disgusted', v: 1, p: 4 },
          ].map(t => (
            <div key={t.n} style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0',
              borderBottom: `1px dashed ${L.ink}`,
            }}>
              <div style={{
                width: 80, fontFamily: LF.display, fontStyle: 'italic',
                fontWeight: 700, fontSize: 17, color: L.cores[t.c],
              }}>{t.n}</div>
              <div style={{ flex: 1, position: 'relative', height: 18 }}>
                <div style={{
                  position: 'absolute', inset: 0, width: `${t.p}%`,
                  background: L.cores[t.c],
                  boxShadow: `2px 2px 0 ${L.ink}`,
                }}/>
              </div>
              <div style={{
                width: 36, textAlign: 'right',
                fontFamily: LF.mono, fontSize: 13, color: L.ink, fontWeight: 700,
              }}>{t.v}×</div>
            </div>
          ))}
        </div>

        <LBreak dingbat="❦"/>

        {/* Intensity sparkline */}
        <div style={{ fontFamily: LF.sc, fontSize: 10, color: L.muted, letterSpacing: 3, fontWeight: 600 }}>§ INTENSITY · 14 DAYS</div>
        <div style={{ marginTop: 10, position: 'relative', height: 56 }}>
          <svg width="100%" height="56" viewBox="0 0 280 56" preserveAspectRatio="none">
            {[20, 36, 52].map(y => (
              <line key={y} x1="0" y1={y} x2="280" y2={y} stroke={L.ink} strokeWidth="0.5" strokeDasharray="2 4" opacity="0.5"/>
            ))}
            <polyline points={[3,2,4,5,3,4,2,3,5,4,3,2,4,3].map((d, i) => `${(i / 13) * 280},${56 - (d - 1) * 12}`).join(' ')}
              stroke={L.vermilion} strokeWidth="2" fill="none"/>
            {[3,2,4,5,3,4,2,3,5,4,3,2,4,3].map((d, i) => (
              <rect key={i} x={(i / 13) * 280 - 3} y={56 - (d - 1) * 12 - 3} width="6" height="6" fill={L.ink}/>
            ))}
          </svg>
        </div>
      </div>
      <LetterpressTabs active="insights" accent={L.ink}/>
    </LPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 6 — History (book index / contents)
// ─────────────────────────────────────────────────────────────
function LetterpressHistory() {
  return (
    <LPaper>
      <div style={{ position: 'absolute', top: 62, left: 22, right: 22, bottom: 88, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <button style={{
            background: 'transparent', border: 'none', padding: 0, color: L.ink,
            fontFamily: LF.display, fontSize: 22, fontStyle: 'italic', fontWeight: 700,
          }}>‹</button>
          <LRule><span>TODAY</span></LRule>
        </div>
        <div style={{
          marginTop: 2, fontFamily: LF.display, fontSize: 38,
          fontStyle: 'italic', fontWeight: 700, color: L.ink, letterSpacing: -0.6, lineHeight: 1,
        }}>The Index</div>
        <div style={{ height: 2, background: L.ink, margin: '8px 0 6px' }}/>
        <div style={{ height: 0.5, background: L.ink }}/>

        {/* filter chips */}
        <div style={{ marginTop: 14, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {['ALL', 'HAPPY', 'SAD', 'ANGRY', 'FEARFUL', 'DISGUSTED'].map((c, i) => (
            <span key={c} style={{
              padding: '4px 9px', border: `1.5px solid ${L.ink}`,
              background: i === 0 ? L.ink : 'transparent',
              color: i === 0 ? L.paper : L.ink,
              fontFamily: LF.sc, fontSize: 10, fontWeight: 600, letterSpacing: 2,
            }}>{c}</span>
          ))}
        </div>

        {/* Day groups */}
        {[
          { d: 'THURSDAY, 28 MAY · TODAY', items: [
            { t: '12:38', word: 'Thankful', sub: 'Happy · Peaceful', i: 3, c: 'happy' },
            { t: '09:14', word: 'Overwhelmed', sub: 'Fearful · Anxious', i: 4, c: 'fearful', note: 'Big presentation in an hour. Hands cold.' },
          ]},
          { d: 'WEDNESDAY, 27 MAY', items: [
            { t: '20:02', word: 'Disappointed', sub: 'Sad · Hurt', i: 3, c: 'sad' },
            { t: '16:15', word: 'Confident', sub: 'Happy · Proud', i: 4, c: 'happy' },
          ]},
          { d: 'TUESDAY, 26 MAY', items: [
            { t: '18:30', word: 'Annoyed', sub: 'Angry · Frustrated', i: 3, c: 'angry' },
          ]},
        ].map((g, gi) => (
          <div key={g.d} style={{ marginTop: 16 }}>
            <div style={{
              fontFamily: LF.sc, fontSize: 10, color: L.muted,
              letterSpacing: 3, fontWeight: 600,
              borderBottom: `1px solid ${L.ink}`, paddingBottom: 4,
            }}>{g.d}</div>
            {g.items.map((it, i) => (
              <div key={i} style={{
                display: 'flex', gap: 12, padding: '10px 0',
                borderBottom: `1px dotted ${L.divider}`,
              }}>
                <div style={{ width: 44, paddingTop: 2 }}>
                  <div style={{ fontFamily: LF.mono, fontSize: 11, color: L.ink, fontWeight: 700 }}>{it.t}</div>
                </div>
                <div style={{
                  width: 5, background: L.cores[it.c], border: `0.5px solid ${L.ink}`,
                }}/>
                <div style={{ flex: 1 }}>
                  <div style={{
                    fontFamily: LF.display, fontStyle: 'italic', fontSize: 22,
                    fontWeight: 700, color: L.cores[it.c], letterSpacing: -0.3, lineHeight: 1,
                  }}>{it.word}.</div>
                  <div style={{
                    marginTop: 3, fontFamily: LF.sc, fontSize: 9, color: L.muted,
                    letterSpacing: 2, fontWeight: 600,
                  }}>{it.sub} · {it.i}/5</div>
                  {it.note && (
                    <div style={{
                      marginTop: 5, fontFamily: LF.display, fontStyle: 'italic',
                      fontSize: 13, color: L.ink2, lineHeight: 1.4,
                    }}>"{it.note}"</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
      <LetterpressTabs active="today" accent={L.ink}/>
    </LPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 7 — Direction
// ─────────────────────────────────────────────────────────────
function LetterpressDirection() {
  return (
    <LPaper>
      <LGear/>
      <div style={{ position: 'absolute', top: 70, left: 22, right: 22, bottom: 88, overflow: 'hidden' }}>
        <LBookHead chapter="MAY · INTENTIONS &amp; VALUES" title="Direction" accent={L.ink}/>

        {/* Today's intention as a colophon block */}
        <div style={{ marginTop: 16 }}>
          <LRule><span>I. TODAY</span></LRule>
          <div style={{
            marginTop: 6, padding: '20px 22px',
            background: L.paper2, border: `2px solid ${L.ink}`, boxShadow: `3px 3px 0 ${L.ink}`,
          }}>
            <div style={{
              fontFamily: LF.display, fontStyle: 'italic', fontSize: 24,
              fontWeight: 700, color: L.ink, lineHeight: 1.25, letterSpacing: -0.4,
            }}>
              "Be slower with replies.<br/>Listen first."
            </div>
            <div style={{ marginTop: 14, display: 'flex', gap: 6 }}>
              {['HARD', 'OK', 'YES'].map((l, i) => (
                <span key={l} style={{
                  padding: '5px 10px', border: `1.5px solid ${L.ink}`,
                  background: l === 'OK' ? L.ink : 'transparent',
                  color: l === 'OK' ? L.paper : L.ink,
                  fontFamily: LF.sc, fontSize: 10, fontWeight: 600, letterSpacing: 2,
                }}>{l}</span>
              ))}
            </div>
          </div>
        </div>

        <LBreak dingbat="❦"/>

        {/* Values ranked — book table */}
        <LRule><span>II. WHAT I TEND TOWARD &middot; TOP 5</span></LRule>
        <div style={{
          marginTop: 8, border: `2px solid ${L.ink}`,
        }}>
          {[
            { n: 'Honesty', d: '↑ 3' },
            { n: 'Curiosity', d: '—' },
            { n: 'Family', d: '↑ 6' },
            { n: 'Quiet', d: '↓ 2' },
            { n: 'Health', d: 'new' },
          ].map((v, i) => (
            <div key={v.n} style={{
              display: 'flex', alignItems: 'center', gap: 14, padding: '12px 16px',
              borderBottom: i < 4 ? `1px solid ${L.ink}` : 'none',
              background: i === 0 ? L.paper2 : L.paper,
            }}>
              <div style={{
                fontFamily: LF.mono, fontSize: 12, color: L.muted, width: 22, fontWeight: 700,
              }}>0{i + 1}</div>
              <div style={{
                flex: 1, fontFamily: LF.display, fontStyle: 'italic', fontWeight: 700,
                fontSize: 22, color: L.ink, letterSpacing: -0.3, lineHeight: 1,
              }}>{v.n}</div>
              <div style={{
                fontFamily: LF.sc, fontSize: 10, color: L.muted, letterSpacing: 2, fontWeight: 600,
              }}>{v.d}</div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
          <LStamp color={L.ink} style={{ flex: 1, padding: '10px', fontSize: 13 }}>RE-SORT</LStamp>
          <LStamp color={L.ink} style={{ flex: 1, padding: '10px', fontSize: 13 }}>PAST</LStamp>
        </div>
      </div>
      <LetterpressTabs active="direction" accent={L.ink}/>
    </LPaper>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 8 — Settings (modal book interior)
// ─────────────────────────────────────────────────────────────
function LetterpressSettings() {
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'rgba(28,22,17,0.55)', overflow: 'hidden' }}>
      <LPaper bg={L.paper}>
        <div style={{ opacity: 0.35 }}>
          <LBookHead chapter="TODAY" title="Today" accent={L.ink}/>
        </div>
      </LPaper>
      <div style={{
        position: 'absolute', top: 56, left: 0, right: 0, bottom: 0,
        background: L.paper, borderTop: `3px solid ${L.ink}`,
        boxShadow: '0 -10px 30px rgba(28,22,17,0.25)', overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '8px 0 4px' }}>
          <div style={{ width: 48, height: 5, background: L.ink }}/>
        </div>
        <div style={{
          padding: '12px 22px 12px', display: 'flex', alignItems: 'center',
          borderBottom: `2px solid ${L.ink}`,
        }}>
          <div style={{
            flex: 1, fontFamily: LF.display, fontStyle: 'italic', fontWeight: 700,
            fontSize: 28, color: L.ink, letterSpacing: -0.4,
          }}>Settings.</div>
          <LStamp color={L.ink} style={{ padding: '6px 14px', fontSize: 12 }}>DONE</LStamp>
        </div>

        <div style={{ padding: '14px 18px', overflow: 'auto', maxHeight: 'calc(100% - 70px)' }}>
          {[
            { h: 'I. AUTHOR', rows: [
              { l: 'Display name', d: 'Taylor' }, { l: 'Appearance', d: 'Auto' },
            ]},
            { h: 'II. CHECK-IN', rows: [
              { l: 'Default mode', d: 'Wheel' },
              { l: 'Body region first', toggle: true, on: true },
              { l: 'Show clinical notes', toggle: true, on: true },
              { l: 'Learn from history', toggle: true, on: true },
            ]},
            { h: 'III. PRIVACY', rows: [
              { l: 'iCloud sync', d: 'synced 2m ago', good: true },
              { l: 'Face ID lock', toggle: true, on: true },
              { l: 'Apple Health write', toggle: true, on: false },
            ]},
            { h: 'IV. EXPORT', rows: [
              { l: 'Local backup', d: '' },
              { l: 'Export CSV / JSON', d: '' },
              { l: 'Therapy report PDF', d: '' },
            ]},
            { h: 'V. SUPPORT', rows: [
              { l: '🥤 Soda', d: '$1.99', donate: true },
              { l: '🥪 Lunch', d: '$4.99', donate: true },
              { l: '🍝 Dinner', d: '$9.99', donate: true },
            ]},
          ].map(sec => (
            <div key={sec.h} style={{ marginBottom: 14 }}>
              <div style={{
                fontFamily: LF.sc, fontSize: 10, color: L.ink,
                letterSpacing: 3, fontWeight: 600, paddingBottom: 4,
                borderBottom: `1px solid ${L.ink}`,
              }}>{sec.h}</div>
              {sec.rows.map((r, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', padding: '11px 0',
                  borderBottom: i < sec.rows.length - 1 ? `1px dotted ${L.divider}` : 'none',
                }}>
                  <div style={{
                    flex: 1, fontFamily: LF.display, fontStyle: 'italic',
                    fontSize: 16, color: L.ink, fontWeight: 500,
                  }}>{r.l}</div>
                  {r.d && (
                    <div style={{
                      marginRight: 10, fontFamily: LF.mono, fontSize: 11,
                      color: r.good ? L.moss : L.muted, fontWeight: 600,
                    }}>{r.d}</div>
                  )}
                  {r.toggle && (
                    <div style={{
                      width: 38, height: 22,
                      background: r.on ? L.ink : L.paper,
                      border: `2px solid ${L.ink}`,
                      display: 'flex', padding: 1,
                      justifyContent: r.on ? 'flex-end' : 'flex-start',
                    }}>
                      <div style={{ width: 16, height: 16, background: r.on ? L.paper : L.ink }}/>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ))}
          <div style={{
            textAlign: 'center', padding: '12px 0 30px',
            fontFamily: LF.sc, fontSize: 10, color: L.muted, letterSpacing: 3, fontWeight: 600,
          }}>
            ❦ &nbsp; SET IN FRAUNCES &amp; PLEX &nbsp; ❦<br/>
            <span style={{ fontFamily: LF.mono, fontSize: 10, letterSpacing: 0.5, fontWeight: 400 }}>
              V. 1.4 &middot; MIT &middot; FREE
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  LetterpressOnboarding, LetterpressToday, LetterpressCheckIn, LetterpressWizardStep,
  LetterpressInsights, LetterpressHistory, LetterpressDirection, LetterpressSettings,
  LetterpressWheel,
});
