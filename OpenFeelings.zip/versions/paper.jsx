// V1 — PAPER
// Refinement of current app. Editorial serif (Fraunces), watercolor wash for
// the wheel, warm paper-cream background. Exports PaperPack to window.
//
// Palette
const P = {
  bg:        '#FAF6F0',
  surface:   '#FFFFFF',
  surface2:  '#F4ECDF',
  divider:   '#E8DFD3',
  text:      '#2B2520',
  muted:     '#6B6259',
  accent:    '#8E4F2C',
  accentSoft:'#EFD5C2',
  ink:       '#1F1A16',
  // Watercolor rebalanced cores (light scheme)
  cores: {
    happy:     { ink: '#9E741F', mid: '#D8B57A', wash: '#F2DDB8' },
    sad:       { ink: '#6F8FA8', mid: '#A8C0D2', wash: '#D6E3EE' },
    angry:     { ink: '#C46A55', mid: '#E4A593', wash: '#F2D2C7' },
    fearful:   { ink: '#A07FB1', mid: '#C7B0D2', wash: '#E2D4E7' },
    disgusted: { ink: '#4F785D', mid: '#9CBAA6', wash: '#D2E0D7' },
  },
};
const PaperFont = {
  // Loaded via index.html: Fraunces (serif), Source Serif 4 (fallback), Inter not allowed → IBM Plex Sans
  serif: '"Fraunces", "Source Serif 4", "Iowan Old Style", Georgia, serif',
  sans:  '"IBM Plex Sans", -apple-system, system-ui, sans-serif',
  mono:  '"IBM Plex Mono", ui-monospace, "SF Mono", monospace',
};

// ─────────────────────────────────────────────────────────────
// Helper: paper texture (subtle noise + warm vignette)
// ─────────────────────────────────────────────────────────────
function PaperGround({ children, bg = P.bg }) {
  return (
    <div style={{
      position: 'absolute', inset: 0, background: bg, overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse at 50% 0%, rgba(255,255,255,0.6) 0%, transparent 55%), radial-gradient(ellipse at 50% 100%, rgba(0,0,0,0.04) 0%, transparent 60%)',
        pointerEvents: 'none',
      }} />
      {children}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// The watercolor wheel — 3 concentric petal-rings using SVG.
// 5 cores × 5 secondaries each = 25 petal slices; specific is shown when zoomed.
// ─────────────────────────────────────────────────────────────
function WatercolorWheel({ size = 280, ringStops = [0.42, 0.72, 1.0], showLabels = true, dimAll = false, focus = null }) {
  const cx = size / 2, cy = size / 2;
  const r0 = size * 0.16; // hub
  const r1 = (size / 2) * ringStops[0]; // core ring outer
  const r2 = (size / 2) * ringStops[1]; // secondary ring outer
  const r3 = (size / 2) * ringStops[2]; // specific ring outer

  const cores = WHEEL_DATA;
  const sliceAngle = 360 / cores.length;

  const polar = (r, deg) => {
    const a = (deg - 90) * Math.PI / 180;
    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
  };
  const sectorPath = (rIn, rOut, a0, a1) => {
    const [x1, y1] = polar(rOut, a0);
    const [x2, y2] = polar(rOut, a1);
    const [x3, y3] = polar(rIn, a1);
    const [x4, y4] = polar(rIn, a0);
    const large = a1 - a0 > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${rOut} ${rOut} 0 ${large} 1 ${x2} ${y2} L ${x3} ${y3} A ${rIn} ${rIn} 0 ${large} 0 ${x4} ${y4} Z`;
  };

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ display: 'block' }}>
      <defs>
        {cores.map(c => (
          <radialGradient id={`pw-${c.id}`} key={c.id} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={P.cores[c.id].mid} stopOpacity="0.95"/>
            <stop offset="100%" stopColor={P.cores[c.id].wash} stopOpacity="0.65"/>
          </radialGradient>
        ))}
        <filter id="pw-paper">
          <feTurbulence type="fractalNoise" baseFrequency="1.4" numOctaves="2" seed="3"/>
          <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.04 0"/>
          <feComposite operator="in" in2="SourceGraphic"/>
        </filter>
      </defs>

      {/* outermost ring: specifics — softest wash */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceAngle;
        return c.secondaries.flatMap((s, si) => {
          const sliceW = sliceAngle / c.secondaries.length;
          return s.specifics.map((sp, spi) => {
            const subW = sliceW / s.specifics.length;
            const a0 = baseA + si * sliceW + spi * subW;
            const a1 = a0 + subW;
            const isDim = dimAll || (focus && focus !== c.id);
            return (
              <path key={`sp-${c.id}-${si}-${spi}`}
                d={sectorPath(r2, r3, a0, a1)}
                fill={P.cores[c.id].wash}
                opacity={isDim ? 0.18 : 0.55}
                stroke={P.bg} strokeWidth="0.8"/>
            );
          });
        });
      })}

      {/* middle ring: secondaries — mid wash */}
      {cores.map((c, ci) => {
        const baseA = ci * sliceAngle;
        return c.secondaries.map((s, si) => {
          const sliceW = sliceAngle / c.secondaries.length;
          const a0 = baseA + si * sliceW;
          const a1 = a0 + sliceW;
          const isDim = dimAll || (focus && focus !== c.id);
          return (
            <path key={`s-${c.id}-${si}`}
              d={sectorPath(r1, r2, a0, a1)}
              fill={P.cores[c.id].mid}
              opacity={isDim ? 0.22 : 0.62}
              stroke={P.bg} strokeWidth="1"/>
          );
        });
      })}

      {/* inner ring: cores — ink wash */}
      {cores.map((c, ci) => {
        const a0 = ci * sliceAngle;
        const a1 = a0 + sliceAngle;
        const isDim = dimAll || (focus && focus !== c.id);
        return (
          <path key={`c-${c.id}`}
            d={sectorPath(r0, r1, a0, a1)}
            fill={`url(#pw-${c.id})`}
            opacity={isDim ? 0.35 : 1}
            stroke={P.bg} strokeWidth="1.2"/>
        );
      })}

      {/* hub */}
      <circle cx={cx} cy={cy} r={r0} fill={P.surface} stroke={P.divider} strokeWidth="0.8"/>
      <text x={cx} y={cy + 2} textAnchor="middle" dominantBaseline="middle"
        fontFamily={PaperFont.serif} fontSize={r0 * 0.34} fill={P.muted}
        style={{ letterSpacing: 1, fontStyle: 'italic' }}>feel</text>

      {/* core labels around the ring */}
      {showLabels && cores.map((c, ci) => {
        const aMid = ci * sliceAngle + sliceAngle / 2;
        const lr = (r0 + r1) / 2;
        const [lx, ly] = polar(lr, aMid);
        return (
          <text key={`lbl-${c.id}`} x={lx} y={ly + 2}
            textAnchor="middle" dominantBaseline="middle"
            fontFamily={PaperFont.serif} fontSize={r0 * 0.28}
            fill={P.ink}
            style={{ fontStyle: 'italic', letterSpacing: 0.3 }}>{c.name.toLowerCase()}</text>
        );
      })}

      {/* outer-ring secondary labels at the wash band */}
      {showLabels && cores.map((c, ci) => {
        const baseA = ci * sliceAngle;
        return c.secondaries.map((s, si) => {
          const sliceW = sliceAngle / c.secondaries.length;
          const aMid = baseA + si * sliceW + sliceW / 2;
          const lr = (r1 + r2) / 2;
          const [lx, ly] = polar(lr, aMid);
          const isDim = dimAll || (focus && focus !== c.id);
          return (
            <text key={`slbl-${c.id}-${si}`} x={lx} y={ly + 2}
              textAnchor="middle" dominantBaseline="middle"
              fontFamily={PaperFont.sans} fontSize={size * 0.025}
              fill={P.ink} opacity={isDim ? 0.3 : 0.78}
              style={{ letterSpacing: 0.1 }}>{s.name}</text>
          );
        });
      })}
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Paper tab bar — cream + ink, no glass blur (this is paper)
// ─────────────────────────────────────────────────────────────
function PaperTabs({ active }) {
  return (
    <TabBar
      tabs={tabsForActive(active, P.accent)}
      active={active}
      bg={withAlpha(P.bg, 0.93)}
      fg={P.text} muted={withAlpha(P.text, 0.4)} accent={P.accent}
      border={P.divider}
      blur={false}
    />
  );
}

// ─────────────────────────────────────────────────────────────
// Reusable bits
// ─────────────────────────────────────────────────────────────
const PaperCard = ({ children, style }) => (
  <div style={{
    background: P.surface,
    borderRadius: 12,
    padding: '16px 18px',
    boxShadow: '0 1px 0 rgba(46,32,18,0.04), 0 1px 3px rgba(46,32,18,0.04)',
    ...style,
  }}>{children}</div>
);

const Caption = ({ children, style }) => (
  <div style={{
    fontFamily: PaperFont.sans, fontSize: 11, color: P.muted,
    textTransform: 'uppercase', letterSpacing: 1.3, fontWeight: 500, ...style,
  }}>{children}</div>
);

const SerifTitle = ({ size = 28, children, style }) => (
  <div style={{
    fontFamily: PaperFont.serif, fontSize: size, lineHeight: 1.1,
    color: P.text, fontWeight: 400, letterSpacing: -0.5,
    fontVariationSettings: '"SOFT" 60, "WONK" 0', ...style,
  }}>{children}</div>
);

// Gear button at top right
const PaperGear = ({ style }) => (
  <button style={{
    position: 'absolute', top: 68, right: 18, zIndex: 6,
    width: 36, height: 36, borderRadius: 18, border: 'none',
    background: withAlpha(P.surface, 0.85),
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    boxShadow: '0 1px 4px rgba(0,0,0,0.06)', color: P.muted,
    ...style,
  }}>{Icons.gear(P.muted, 1.6)}</button>
);

// ─────────────────────────────────────────────────────────────
// SCREEN 1: Onboarding
// ─────────────────────────────────────────────────────────────
function PaperOnboarding() {
  return (
    <PaperGround>
      <div style={{ position: 'absolute', top: 80, left: 0, right: 0, textAlign: 'center' }}>
        <Caption>Private by default · No accounts</Caption>
      </div>
      <div style={{ position: 'absolute', top: 110, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
        <WatercolorWheel size={320} dimAll={false} showLabels={false} />
      </div>
      <div style={{ position: 'absolute', top: 446, left: 32, right: 32, textAlign: 'center' }}>
        <SerifTitle size={42} style={{ lineHeight: 1.0 }}>
          Open<br/>Feelings
        </SerifTitle>
        <div style={{
          marginTop: 18, fontFamily: PaperFont.serif, fontSize: 19, color: P.muted,
          fontStyle: 'italic', lineHeight: 1.4, letterSpacing: 0.1,
        }}>
          Name how you feel.<br/>That's the whole app.
        </div>
      </div>
      <div style={{ position: 'absolute', bottom: 100, left: 32, right: 32 }}>
        <button style={{
          width: '100%', padding: '17px 24px', borderRadius: 100, border: 'none',
          background: P.ink, color: P.bg,
          fontFamily: PaperFont.serif, fontSize: 18, fontStyle: 'italic',
          letterSpacing: 0.3,
        }}>Begin →</button>
        <div style={{
          marginTop: 16, textAlign: 'center', fontFamily: PaperFont.sans,
          fontSize: 12, color: P.muted, letterSpacing: 0.3,
        }}>
          Free · Open source · Stays on your phone
        </div>
      </div>
    </PaperGround>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 2: Today
// ─────────────────────────────────────────────────────────────
function PaperToday() {
  return (
    <PaperGround>
      <PaperGear />
      <div style={{ position: 'absolute', top: 70, left: 22, right: 22, bottom: 88, overflow: 'hidden' }}>
        <Caption>Thursday, May 28</Caption>
        <SerifTitle size={36} style={{ marginTop: 6 }}>
          Good morning,<br/><em style={{ color: P.accent, fontStyle: 'italic' }}>Taylor</em>.
        </SerifTitle>

        {/* Intention */}
        <PaperCard style={{ marginTop: 22 }}>
          <Caption>Today's intention</Caption>
          <div style={{
            marginTop: 8, fontFamily: PaperFont.serif, fontStyle: 'italic',
            fontSize: 18, color: P.text, lineHeight: 1.35,
          }}>
            "Be slower with replies. Listen first."
          </div>
        </PaperCard>

        {/* Today section header */}
        <div style={{ marginTop: 22, display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <SerifTitle size={20}>2 check-ins today</SerifTitle>
          <span style={{ fontFamily: PaperFont.sans, fontSize: 12, color: P.muted }}>so far</span>
        </div>

        {/* Check-in cards */}
        <PaperCard style={{ marginTop: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{
              width: 10, height: 10, borderRadius: 5, background: P.cores.fearful.mid,
            }}/>
            <span style={{ fontFamily: PaperFont.serif, fontSize: 18, color: P.text }}>
              Fearful <span style={{ color: P.muted }}>· Anxious · Overwhelmed</span>
            </span>
          </div>
          <div style={{
            marginTop: 8, display: 'flex', alignItems: 'center', gap: 8,
            fontFamily: PaperFont.mono, fontSize: 12, color: P.muted,
          }}>
            <span style={{ display: 'inline-flex', gap: 3 }}>
              {[1,2,3,4,5].map(i => (
                <span key={i} style={{
                  width: 6, height: 6, borderRadius: 3,
                  background: i <= 4 ? P.accent : P.divider,
                }}/>
              ))}
            </span>
            <span>9:14 AM</span>
            <span>· chest · racing</span>
          </div>
          <div style={{
            marginTop: 10, fontFamily: PaperFont.serif, fontStyle: 'italic',
            fontSize: 15, color: P.muted, lineHeight: 1.4,
          }}>"Big presentation in an hour. Hands cold."</div>
        </PaperCard>

        <PaperCard style={{ marginTop: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{
              width: 10, height: 10, borderRadius: 5, background: P.cores.happy.mid,
            }}/>
            <span style={{ fontFamily: PaperFont.serif, fontSize: 18, color: P.text }}>
              Happy <span style={{ color: P.muted }}>· Peaceful · Thankful</span>
            </span>
          </div>
          <div style={{
            marginTop: 8, display: 'flex', alignItems: 'center', gap: 8,
            fontFamily: PaperFont.mono, fontSize: 12, color: P.muted,
          }}>
            <span style={{ display: 'inline-flex', gap: 3 }}>
              {[1,2,3,4,5].map(i => (
                <span key={i} style={{
                  width: 6, height: 6, borderRadius: 3,
                  background: i <= 3 ? P.accent : P.divider,
                }}/>
              ))}
            </span>
            <span>12:38 PM</span>
            <span>· walked at noon</span>
          </div>
        </PaperCard>

        {/* Week summary */}
        <div style={{ marginTop: 22 }}>
          <Caption>This week</Caption>
          <div style={{
            marginTop: 6, fontFamily: PaperFont.serif, fontSize: 17, color: P.text,
            fontStyle: 'italic',
          }}>
            Mostly <span style={{ color: P.cores.happy.ink }}>happy</span> · 9 check-ins
          </div>
        </div>
      </div>

      <PaperTabs active="today" />
    </PaperGround>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 3: Check-in entry (the wheel)
// ─────────────────────────────────────────────────────────────
function PaperCheckIn() {
  return (
    <PaperGround>
      <PaperGear />
      <div style={{ position: 'absolute', top: 72, left: 22, right: 22 }}>
        <Caption>Step 2 of 4</Caption>
        <SerifTitle size={32} style={{ marginTop: 8 }}>
          How are you feeling?
        </SerifTitle>
        <div style={{
          marginTop: 6, fontFamily: PaperFont.serif, fontStyle: 'italic',
          fontSize: 16, color: P.muted,
        }}>Tap a slice. Pinch to zoom.</div>
      </div>

      <div style={{
        position: 'absolute', top: 200, left: 0, right: 0,
        display: 'flex', justifyContent: 'center',
      }}>
        <WatercolorWheel size={350} />
      </div>

      {/* Segmented "Wheel · Guided" picker */}
      <div style={{
        position: 'absolute', bottom: 110, left: 22, right: 22,
        display: 'flex', gap: 0, padding: 4, borderRadius: 100,
        background: P.surface2, border: `0.5px solid ${P.divider}`,
      }}>
        <button style={{
          flex: 1, padding: '10px 16px', borderRadius: 100, border: 'none',
          background: P.ink, color: P.bg,
          fontFamily: PaperFont.serif, fontStyle: 'italic', fontSize: 15,
        }}>Wheel</button>
        <button style={{
          flex: 1, padding: '10px 16px', borderRadius: 100, border: 'none',
          background: 'transparent', color: P.muted,
          fontFamily: PaperFont.serif, fontStyle: 'italic', fontSize: 15,
        }}>Guided</button>
      </div>

      <PaperTabs active="checkIn" />
    </PaperGround>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 4: Wizard step — "How strong?"
// ─────────────────────────────────────────────────────────────
function PaperWizardStep() {
  return (
    <PaperGround>
      <div style={{ position: 'absolute', top: 64, left: 22, right: 22 }}>
        {/* progress dots */}
        <div style={{ display: 'flex', gap: 5, marginBottom: 18 }}>
          {[0,1,2,3,4,5].map(i => (
            <div key={i} style={{
              flex: 1, height: 3, borderRadius: 1.5,
              background: i <= 2 ? P.accent : P.divider,
            }} />
          ))}
        </div>
        <Caption>Step 3 · Optional</Caption>
        <SerifTitle size={30} style={{ marginTop: 6 }}>How strong?</SerifTitle>

        {/* selected feeling badge */}
        <div style={{
          marginTop: 14, display: 'inline-flex', alignItems: 'center', gap: 8,
          padding: '6px 12px', borderRadius: 100,
          background: P.cores.fearful.wash,
        }}>
          <span style={{ width: 8, height: 8, borderRadius: 4, background: P.cores.fearful.ink }}/>
          <span style={{ fontFamily: PaperFont.serif, fontSize: 14, color: P.cores.fearful.ink }}>
            Fearful · Anxious
          </span>
        </div>

        {/* intensity scale: 5 stones */}
        <div style={{
          marginTop: 38, display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          {[1,2,3,4,5].map(i => {
            const selected = i === 4;
            const size = 36 + i * 6;
            return (
              <div key={i} style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
              }}>
                <div style={{
                  width: size, height: size, borderRadius: '50%',
                  background: selected ? P.cores.fearful.mid : P.surface,
                  border: `1.5px solid ${selected ? P.cores.fearful.ink : P.divider}`,
                  boxShadow: selected ? `0 0 0 4px ${P.cores.fearful.wash}` : 'none',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: PaperFont.serif, fontStyle: 'italic',
                  fontSize: 14, color: selected ? P.ink : P.muted,
                }}>{i}</div>
              </div>
            );
          })}
        </div>
        <div style={{
          marginTop: 14, display: 'flex', justifyContent: 'space-between',
          fontFamily: PaperFont.sans, fontSize: 11, color: P.muted, letterSpacing: 0.5,
        }}>
          <span>barely</span>
          <span>strong</span>
        </div>

        {/* Word description for selection */}
        <div style={{
          marginTop: 32, padding: '18px 20px', borderRadius: 12,
          background: P.cores.fearful.wash,
          border: `0.5px solid ${P.cores.fearful.mid}`,
        }}>
          <Caption style={{ color: P.cores.fearful.ink }}>Anxious — clinical note</Caption>
          <div style={{
            marginTop: 8, fontFamily: PaperFont.serif, fontSize: 16,
            color: P.ink, lineHeight: 1.45, fontStyle: 'italic',
          }}>
            "A future-facing unease, often paired with bodily activation
            (tight chest, restless thoughts). Common, treatable."
          </div>
        </div>
      </div>

      {/* Nav */}
      <div style={{
        position: 'absolute', bottom: 105, left: 22, right: 22,
        display: 'flex', gap: 12,
      }}>
        <button style={{
          flex: '0 0 auto', padding: '14px 22px', borderRadius: 100,
          background: 'transparent', border: `1px solid ${P.divider}`,
          fontFamily: PaperFont.serif, fontStyle: 'italic', fontSize: 15, color: P.muted,
        }}>← Back</button>
        <button style={{
          flex: 1, padding: '14px 22px', borderRadius: 100, border: 'none',
          background: P.ink, color: P.bg,
          fontFamily: PaperFont.serif, fontStyle: 'italic', fontSize: 15,
        }}>Next →</button>
      </div>

      <PaperTabs active="checkIn" />
    </PaperGround>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 5: Insights
// ─────────────────────────────────────────────────────────────
function PaperInsights() {
  // Top feelings horizontal bar chart
  const tops = [
    { name: 'Anxious',  core: 'fearful', count: 8 },
    { name: 'Peaceful', core: 'happy',   count: 6 },
    { name: 'Tired',    core: 'sad',     count: 4 },
    { name: 'Hopeful',  core: 'happy',   count: 3 },
    { name: 'Annoyed',  core: 'angry',   count: 2 },
  ];
  const max = 8;

  return (
    <PaperGround>
      <PaperGear />
      <div style={{ position: 'absolute', top: 70, left: 22, right: 22, bottom: 88, overflow: 'hidden' }}>
        <Caption>This month</Caption>
        <SerifTitle size={34} style={{ marginTop: 4 }}>Insights</SerifTitle>

        {/* Range tabs */}
        <div style={{
          marginTop: 18, display: 'flex', gap: 0, padding: 3,
          background: P.surface2, borderRadius: 100,
          border: `0.5px solid ${P.divider}`,
        }}>
          {['Week', 'Month', 'Year'].map((r, i) => (
            <button key={r} style={{
              flex: 1, padding: '8px 12px', borderRadius: 100, border: 'none',
              background: i === 1 ? P.surface : 'transparent',
              fontFamily: PaperFont.serif, fontSize: 14, color: i === 1 ? P.text : P.muted,
              fontStyle: 'italic',
              boxShadow: i === 1 ? '0 1px 3px rgba(0,0,0,0.06)' : 'none',
            }}>{r}</button>
          ))}
        </div>

        {/* Top feelings */}
        <div style={{ marginTop: 22 }}>
          <Caption>Top feelings</Caption>
          <div style={{ marginTop: 10 }}>
            {tops.map(t => (
              <div key={t.name} style={{
                display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10,
              }}>
                <div style={{
                  width: 78, fontFamily: PaperFont.serif, fontSize: 15,
                  color: P.text,
                }}>{t.name}</div>
                <div style={{ flex: 1, height: 22, background: P.surface2, borderRadius: 4, position: 'relative', overflow: 'hidden' }}>
                  <div style={{
                    height: '100%', width: `${(t.count / max) * 100}%`,
                    background: `linear-gradient(90deg, ${P.cores[t.core].mid}, ${P.cores[t.core].wash})`,
                    opacity: 0.85,
                  }} />
                </div>
                <div style={{
                  width: 20, textAlign: 'right',
                  fontFamily: PaperFont.mono, fontSize: 12, color: P.muted,
                }}>{t.count}</div>
              </div>
            ))}
          </div>
        </div>

        {/* By core — soft watercolor donut */}
        <div style={{ marginTop: 26, display: 'flex', alignItems: 'center', gap: 18 }}>
          <svg width="120" height="120" viewBox="0 0 120 120">
            {(() => {
              const values = [
                { id: 'fearful', v: 11 },
                { id: 'happy', v: 9 },
                { id: 'sad', v: 4 },
                { id: 'angry', v: 2 },
                { id: 'disgusted', v: 1 },
              ];
              const total = values.reduce((a, x) => a + x.v, 0);
              let cum = 0;
              const cx = 60, cy = 60, rOut = 54, rIn = 30;
              return values.map(v => {
                const a0 = cum / total * Math.PI * 2 - Math.PI / 2;
                cum += v.v;
                const a1 = cum / total * Math.PI * 2 - Math.PI / 2;
                const large = a1 - a0 > Math.PI ? 1 : 0;
                const x1 = cx + Math.cos(a0) * rOut, y1 = cy + Math.sin(a0) * rOut;
                const x2 = cx + Math.cos(a1) * rOut, y2 = cy + Math.sin(a1) * rOut;
                const x3 = cx + Math.cos(a1) * rIn,  y3 = cy + Math.sin(a1) * rIn;
                const x4 = cx + Math.cos(a0) * rIn,  y4 = cy + Math.sin(a0) * rIn;
                return (
                  <path key={v.id}
                    d={`M ${x1} ${y1} A ${rOut} ${rOut} 0 ${large} 1 ${x2} ${y2} L ${x3} ${y3} A ${rIn} ${rIn} 0 ${large} 0 ${x4} ${y4} Z`}
                    fill={P.cores[v.id].mid} opacity="0.78" stroke={P.bg} strokeWidth="1.5"/>
                );
              });
            })()}
          </svg>
          <div style={{ flex: 1 }}>
            <Caption>By family</Caption>
            <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 4 }}>
              {[['fearful','Fearful','40%'],['happy','Happy','33%'],['sad','Sad','15%']].map(([k,n,p]) => (
                <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 8, height: 8, borderRadius: 4, background: P.cores[k].mid }}/>
                  <span style={{ flex: 1, fontFamily: PaperFont.serif, fontSize: 14, color: P.text }}>{n}</span>
                  <span style={{ fontFamily: PaperFont.mono, fontSize: 12, color: P.muted }}>{p}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Intensity dot scatter — line by day */}
        <div style={{ marginTop: 22 }}>
          <Caption>Intensity · last 14 days</Caption>
          <div style={{ marginTop: 10, height: 60, position: 'relative' }}>
            {Array.from({ length: 14 }).map((_, i) => {
              const v = [3,2,4,5,3,4,2,3,5,4,3,2,4,3][i];
              return (
                <div key={i} style={{
                  position: 'absolute', left: `${(i / 13) * 100}%`,
                  bottom: `${(v - 1) * 14}%`, transform: 'translateX(-50%)',
                  width: 10, height: 10, borderRadius: 5,
                  background: P.cores[['fearful','happy','sad','angry','happy','fearful','happy','sad','happy','fearful','happy','sad','happy','fearful'][i]].mid,
                  opacity: 0.85,
                }} />
              );
            })}
          </div>
        </div>
      </div>
      <PaperTabs active="insights" />
    </PaperGround>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 6: History
// ─────────────────────────────────────────────────────────────
function PaperHistory() {
  const entries = [
    { day: 'Today · Thursday', items: [
      { feel: 'Happy · Peaceful · Thankful', core: 'happy', t: '12:38 PM', i: 3 },
      { feel: 'Fearful · Anxious · Overwhelmed', core: 'fearful', t: '9:14 AM', i: 4, note: 'Big presentation in an hour.' },
    ]},
    { day: 'Yesterday', items: [
      { feel: 'Sad · Hurt · Disappointed', core: 'sad', t: '8:02 PM', i: 3, note: 'Plans canceled, again.' },
      { feel: 'Happy · Proud · Confident', core: 'happy', t: '4:15 PM', i: 4 },
    ]},
    { day: 'Tue, May 26', items: [
      { feel: 'Angry · Frustrated · Annoyed', core: 'angry', t: '6:30 PM', i: 3 },
    ]},
  ];
  return (
    <PaperGround>
      <div style={{ position: 'absolute', top: 64, left: 22, right: 22, bottom: 88, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button style={{
            background: 'transparent', border: 'none', padding: 0, color: P.muted,
            display: 'flex', alignItems: 'center',
          }}>
            <svg width="20" height="20" viewBox="0 0 20 20"><path d="M13 4l-6 6 6 6" stroke={P.muted} strokeWidth="1.5" fill="none" strokeLinecap="round"/></svg>
          </button>
          <Caption>Today</Caption>
        </div>
        <SerifTitle size={34} style={{ marginTop: 6 }}>History</SerifTitle>

        {/* Filter chip strip */}
        <div style={{ marginTop: 14, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {['All', 'Happy', 'Sad', 'Angry', 'Fearful', 'Disgusted'].map((c, i) => (
            <span key={c} style={{
              padding: '5px 12px', borderRadius: 100,
              border: `1px solid ${i === 0 ? P.ink : P.divider}`,
              background: i === 0 ? P.ink : 'transparent',
              color: i === 0 ? P.bg : P.muted,
              fontFamily: PaperFont.sans, fontSize: 12, letterSpacing: 0.2,
            }}>{c}</span>
          ))}
        </div>

        <div style={{ marginTop: 18 }}>
          {entries.map((e, idx) => (
            <div key={e.day} style={{ marginBottom: 16 }}>
              <Caption style={{ marginBottom: 8 }}>{e.day}</Caption>
              {e.items.map((it, i) => (
                <div key={i} style={{
                  display: 'flex', gap: 10, padding: '12px 14px',
                  borderBottom: `0.5px solid ${P.divider}`,
                }}>
                  <div style={{
                    width: 4, alignSelf: 'stretch', borderRadius: 2,
                    background: P.cores[it.core].mid,
                  }} />
                  <div style={{ flex: 1 }}>
                    <div style={{
                      fontFamily: PaperFont.serif, fontSize: 15, color: P.text,
                    }}>{it.feel}</div>
                    <div style={{
                      marginTop: 4, fontFamily: PaperFont.mono, fontSize: 11,
                      color: P.muted, display: 'flex', gap: 8, alignItems: 'center',
                    }}>
                      <span>{it.t}</span>
                      <span style={{ display: 'inline-flex', gap: 2 }}>
                        {[1,2,3,4,5].map(n => (
                          <span key={n} style={{
                            width: 4, height: 4, borderRadius: 2,
                            background: n <= it.i ? P.cores[it.core].ink : P.divider,
                          }}/>
                        ))}
                      </span>
                    </div>
                    {it.note && (
                      <div style={{
                        marginTop: 6, fontFamily: PaperFont.serif, fontStyle: 'italic',
                        fontSize: 13, color: P.muted, lineHeight: 1.4,
                      }}>"{it.note}"</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
      <PaperTabs active="today" />
    </PaperGround>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 7: Direction — Intentions
// ─────────────────────────────────────────────────────────────
function PaperDirection() {
  return (
    <PaperGround>
      <PaperGear />
      <div style={{ position: 'absolute', top: 70, left: 22, right: 22, bottom: 88, overflow: 'hidden' }}>
        <Caption>Thursday, May 28</Caption>
        <SerifTitle size={34} style={{ marginTop: 4 }}>Direction</SerifTitle>

        {/* Segmented control */}
        <div style={{
          marginTop: 14, display: 'flex', gap: 0, padding: 3,
          background: P.surface2, borderRadius: 100, border: `0.5px solid ${P.divider}`,
        }}>
          {['Intentions', 'Values'].map((r, i) => (
            <button key={r} style={{
              flex: 1, padding: '8px 12px', borderRadius: 100, border: 'none',
              background: i === 0 ? P.surface : 'transparent',
              fontFamily: PaperFont.serif, fontSize: 14, color: i === 0 ? P.text : P.muted,
              fontStyle: 'italic',
              boxShadow: i === 0 ? '0 1px 3px rgba(0,0,0,0.06)' : 'none',
            }}>{r}</button>
          ))}
        </div>

        <Caption style={{ marginTop: 20 }}>Today's intention</Caption>
        <PaperCard style={{ marginTop: 8, background: P.cores.happy.wash }}>
          <div style={{
            fontFamily: PaperFont.serif, fontStyle: 'italic', fontSize: 20,
            color: P.ink, lineHeight: 1.35,
          }}>
            "Be slower with replies. Listen first."
          </div>
          <div style={{
            marginTop: 14, display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <button style={{
              padding: '7px 16px', borderRadius: 100, border: `1px solid ${P.ink}`,
              background: 'transparent', color: P.ink,
              fontFamily: PaperFont.sans, fontSize: 12, fontWeight: 500,
            }}>Edit</button>
            <span style={{ flex: 1 }} />
            <span style={{ fontFamily: PaperFont.sans, fontSize: 11, color: P.muted }}>
              How did it feel?
            </span>
            <div style={{ display: 'flex', gap: 4 }}>
              {['Hard','OK','Yes'].map((l, i) => (
                <span key={l} style={{
                  padding: '4px 8px', borderRadius: 100,
                  background: P.surface, border: `0.5px solid ${P.divider}`,
                  fontFamily: PaperFont.sans, fontSize: 11, color: P.muted,
                }}>{l}</span>
              ))}
            </div>
          </div>
        </PaperCard>

        <Caption style={{ marginTop: 22 }}>Past intentions</Caption>
        <div style={{ marginTop: 8 }}>
          {[
            { d: 'Wed', t: 'Eat lunch away from the desk.', f: 'OK' },
            { d: 'Tue', t: 'Notice when I\'m holding my breath.', f: 'Yes' },
            { d: 'Mon', t: 'Send the message I keep avoiding.', f: 'Hard' },
            { d: 'Sun', t: 'No phone before coffee.', f: 'Yes' },
          ].map((p, i) => (
            <div key={i} style={{
              display: 'flex', gap: 12, padding: '12px 0',
              borderBottom: `0.5px solid ${P.divider}`,
            }}>
              <div style={{
                width: 36, fontFamily: PaperFont.serif, fontSize: 13,
                color: P.muted, fontStyle: 'italic', paddingTop: 2,
              }}>{p.d}</div>
              <div style={{ flex: 1, fontFamily: PaperFont.serif, fontSize: 15, color: P.text }}>
                {p.t}
              </div>
              <div style={{
                fontFamily: PaperFont.sans, fontSize: 11, color: P.muted,
                padding: '3px 8px', borderRadius: 100, background: P.surface,
                border: `0.5px solid ${P.divider}`, height: 'fit-content',
              }}>{p.f}</div>
            </div>
          ))}
        </div>
      </div>
      <PaperTabs active="direction" />
    </PaperGround>
  );
}

// ─────────────────────────────────────────────────────────────
// SCREEN 8: Settings (modal sheet — dragged up over Today)
// ─────────────────────────────────────────────────────────────
function PaperSettings() {
  return (
    <PaperGround bg="#1F1A16">
      {/* Today behind, dim */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
        opacity: 0.25,
      }}>
        <PaperGround />
      </div>
      <div style={{
        position: 'absolute', top: 64, left: 0, right: 0, bottom: 0,
        background: P.bg, borderRadius: '24px 24px 0 0',
        boxShadow: '0 -8px 30px rgba(0,0,0,0.15)',
        overflow: 'hidden',
      }}>
        {/* Drag handle */}
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 8 }}>
          <div style={{ width: 36, height: 5, borderRadius: 3, background: P.divider }}/>
        </div>

        {/* Sheet header */}
        <div style={{
          display: 'flex', alignItems: 'center', padding: '12px 20px 8px',
        }}>
          <SerifTitle size={26} style={{ flex: 1 }}>Settings</SerifTitle>
          <button style={{
            padding: '6px 14px', borderRadius: 100, border: 'none',
            background: P.surface2, color: P.text,
            fontFamily: PaperFont.serif, fontSize: 14, fontStyle: 'italic',
          }}>Done</button>
        </div>

        <div style={{ padding: '8px 16px', overflow: 'auto', maxHeight: 'calc(100% - 60px)' }}>
          {[
            { h: 'You', rows: [
              { l: 'Your name', d: 'Taylor', s: '🪴' },
              { l: 'Appearance', d: 'Automatic', s: '🌓' },
              { l: 'Today greeting style', d: 'Warm', s: '✦' },
            ]},
            { h: 'Check-in', rows: [
              { l: 'Default mode', d: 'Wheel', s: '◐' },
              { l: 'Body region first', d: 'On', s: '☉' },
              { l: 'Show clinical notes', d: 'On', s: '✎' },
            ]},
            { h: 'Privacy', rows: [
              { l: 'iCloud sync', d: 'On · synced 2m ago', s: '☁︎', dot: P.cores.disgusted.ink },
              { l: 'App lock (Face ID)', d: 'On', s: '◉' },
              { l: 'Apple Health write', d: 'Off', s: '♡' },
              { l: 'Privacy policy', d: '', s: '§' },
            ]},
            { h: 'Backup & Export', rows: [
              { l: 'Local backup', d: '', s: '⤓' },
              { l: 'Export CSV / JSON', d: '', s: '↗' },
              { l: 'Therapy report (PDF)', d: '', s: '⌬' },
            ]},
            { h: 'Support Open Feelings', rows: [
              { l: '🥤 Soda', d: '$1.99', s: '·', tip: true },
              { l: '🥪 Lunch', d: '$4.99', s: '·', tip: true },
              { l: '🍝 Dinner', d: '$9.99', s: '·', tip: true },
            ]},
          ].map((sec, i) => (
            <div key={sec.h} style={{ marginBottom: 14 }}>
              <Caption style={{ marginBottom: 6, padding: '0 6px' }}>{sec.h}</Caption>
              <div style={{
                background: P.surface, borderRadius: 12, overflow: 'hidden',
              }}>
                {sec.rows.map((r, ri) => (
                  <div key={ri} style={{
                    display: 'flex', alignItems: 'center', padding: '12px 14px',
                    borderBottom: ri < sec.rows.length - 1 ? `0.5px solid ${P.divider}` : 'none',
                  }}>
                    {!r.tip && (
                      <div style={{
                        width: 22, height: 22, borderRadius: 5,
                        background: P.surface2, marginRight: 12,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontFamily: PaperFont.serif, fontSize: 13, color: P.muted,
                      }}>{r.s}</div>
                    )}
                    <div style={{ flex: 1, fontFamily: PaperFont.serif, fontSize: 15, color: P.text }}>
                      {r.l}
                    </div>
                    {r.d && (
                      <div style={{ fontFamily: PaperFont.sans, fontSize: 13, color: P.muted, marginRight: 6 }}>
                        {r.d}
                      </div>
                    )}
                    {!r.tip && Icons.chevR(P.muted, 1.5)}
                  </div>
                ))}
              </div>
            </div>
          ))}

          <div style={{
            textAlign: 'center', padding: '14px 8px 28px',
            fontFamily: PaperFont.serif, fontStyle: 'italic',
            fontSize: 13, color: P.muted, lineHeight: 1.5,
          }}>
            Open Feelings is free and open source.<br/>
            Source: github.com/TaylorFinklea/open-feelings-ios
          </div>
        </div>
      </div>
    </PaperGround>
  );
}

Object.assign(window, {
  PaperOnboarding, PaperToday, PaperCheckIn, PaperWizardStep,
  PaperInsights, PaperHistory, PaperDirection, PaperSettings,
  WatercolorWheel, PaperPalette: P, PaperFont,
});
